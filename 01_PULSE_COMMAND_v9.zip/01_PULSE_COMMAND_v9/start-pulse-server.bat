@echo off
title PULSE v8 Server
node server.js
pause
