/* PULSE final internal offline server - no npm required.
   Default teams are configured in sampleState() below.
   To add more teams later: add another { id, name } object to DEFAULT_TEAMS, then either delete storage/pulse-db.json before first run or update the teams/weeks sections in that file as described in docs/ADMIN_GUIDE.md. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const PORT = process.env.PULSE_PORT || 8787;
const STORAGE_DIR = path.join(ROOT, 'storage');
const DB_FILE = path.join(STORAGE_DIR, 'pulse-db.json');
const BACKUP_DIR = path.join(STORAGE_DIR, 'backups');

function ensureDirs(){
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function nowIso(){ return new Date().toISOString(); }
function stamp(){ return new Date().toISOString().replace(/[:.]/g,'-'); }
function uid(prefix='id'){ return prefix + '-' + crypto.randomBytes(4).toString('hex'); }

function defaultTeam(name){
  const teamId = uid('team');
  return { id: teamId, name };
}


const DEFAULT_LABELS = {
  planner:{ text:'Task details', owner:'Owner', due:'Due date', status:'Status', priority:'Priority', blocker:'Blocker note' },
  people:{ id:'ID', name:'Name', role:'Role' },
  leave:{ person:'Person', type:'Type', from:'From', to:'To', backup:'Backup / Coverage', notes:'Notes' },
  operations:{ item:'Item', status:'Status', owner:'Owner', priority:'Priority', due:'Due', notes:'Notes' },
  notes:{ update:'Weekly update', wins:'Wins', risks:'Risks / blockers', decisions:'Decisions needed', next:'Next week focus' }
};
function clone(obj){ return JSON.parse(JSON.stringify(obj)); }
function ensureLabels(team){
  if(!team.labels) team.labels = clone(DEFAULT_LABELS);
  Object.keys(DEFAULT_LABELS).forEach(section => {
    if(!team.labels[section]) team.labels[section] = {};
    Object.keys(DEFAULT_LABELS[section]).forEach(key => {
      if(!team.labels[section][key]) team.labels[section][key] = DEFAULT_LABELS[section][key];
    });
  });
}

function emptyTeamWeek(teamName){
  return {
    name: teamName,
    lastUpdated: nowIso(),
    planner: { Sun: [], Mon: [], Tue: [], Wed: [], Thu: [], Fri: [], Sat: [] },
    people: [],
    leave: [],
    operations: [],
    notes: { update: '', wins: '', risks: '', decisions: '', next: '' },
    datasets: [],
    charts: [],
    labels: clone(DEFAULT_LABELS)
  };
}


const DEFAULT_TEAMS = [
  { id: 'team-technology', name: 'Technology' },
  { id: 'team-operations', name: 'Operations' },
  { id: 'team-people', name: 'People' }
];

function sampleState(){
  const teams = clone(DEFAULT_TEAMS);
  const weekId = '2026-W26';
  const weeks = { [weekId]: { teams: {} } };
  teams.forEach(t => weeks[weekId].teams[t.id] = emptyTeamWeek(t.name));

  const tech = weeks[weekId].teams['team-technology'];
  tech.people = [
    { id: uid('person'), staffId: '', name: 'Aisha', role: 'Platform Lead' },
    { id: uid('person'), staffId: '', name: 'Khaled', role: 'Engineer' },
    { id: uid('person'), staffId: '', name: 'Mariam', role: 'Analyst' }
  ];
  tech.planner.Mon.push({ id: uid('task'), text: 'Finalize weekly release checklist', owner: 'Aisha', status: 'Doing', priority: 'High', blocker: '', due: '' });
  tech.planner.Tue.push({ id: uid('task'), text: 'Review access requests', owner: 'Khaled', status: 'To-do', priority: 'Med', blocker: '', due: '' });
  tech.planner.Wed.push({ id: uid('task'), text: 'Close dashboard feedback items', owner: 'Aisha', status: 'Done', priority: 'High', blocker: '', due: '' });
  tech.planner.Thu.push({ id: uid('task'), text: 'Resolve blocked integration follow-up', owner: 'Khaled', status: 'Blocked', priority: 'High', blocker: 'Waiting vendor confirmation', due: '' });
  tech.leave.push({ id: uid('leave'), person: 'Mariam', type: 'Annual Leave', from: '2026-06-25', to: '2026-06-26', backup: 'Aisha', notes: 'Coverage assigned.' });
  tech.operations.push({ id: uid('op'), item: 'Release readiness', status: 'Doing', owner: 'Aisha', priority: 'High', due: '2026-06-26', notes: 'Track by Thursday.' });
  tech.notes = { update: 'Core platform work is progressing. One integration item needs external confirmation.', wins: 'Release checklist improved.', risks: 'Vendor confirmation could delay closure.', decisions: 'Confirm release window.', next: 'Complete access review and integration closure.' };
  tech.datasets = [
    { id: uid('ds'), name: 'Automation coverage', rows: [ { id: uid('row'), label: 'Manual', value: 30 }, { id: uid('row'), label: 'Automated', value: 70 } ] }
  ];
  tech.charts = [
    { id: uid('chart'), title: 'Automation coverage', type: 'donut', datasetId: tech.datasets[0].id }
  ];

  const ops = weeks[weekId].teams['team-operations'];
  ops.people = [
    { id: uid('person'), staffId: '', name: 'Omar', role: 'Ops Lead' },
    { id: uid('person'), staffId: '', name: 'Noora', role: 'Coordinator' }
  ];
  ops.planner.Sun.push({ id: uid('task'), text: 'Weekly readiness check', owner: 'Omar', status: 'Done', priority: 'Med', blocker: '', due: '' });
  ops.planner.Tue.push({ id: uid('task'), text: 'Update vendor tracker', owner: 'Noora', status: 'Doing', priority: 'Med', blocker: '', due: '' });
  ops.planner.Thu.push({ id: uid('task'), text: 'Confirm capacity plan', owner: 'Omar', status: 'To-do', priority: 'High', blocker: '', due: '' });
  ops.notes = { update: 'Operational cadence is stable. Capacity planning is the main focus.', wins: 'Readiness check completed early.', risks: '', decisions: '', next: 'Finalize capacity plan.' };

  const people = weeks[weekId].teams['team-people'];
  people.people = [
    { id: uid('person'), staffId: '', name: 'Sara', role: 'HR Partner' },
    { id: uid('person'), staffId: '', name: 'Hamad', role: 'Recruiter' }
  ];
  people.planner.Mon.push({ id: uid('task'), text: 'Hiring pipeline update', owner: 'Hamad', status: 'Doing', priority: 'Med', blocker: '', due: '' });
  people.planner.Wed.push({ id: uid('task'), text: 'Training nominations', owner: 'Sara', status: 'To-do', priority: 'Low', blocker: '', due: '' });
  people.notes = { update: 'Hiring and training items are on track.', wins: '', risks: '', decisions: '', next: 'Close nominations.' };


  return { schemaVersion: 9, appVersion: '9.0.0', currentWeek: weekId, teams, weeks, recoveryPoints: [] };
}

function readDb(){
  ensureDirs();
  if(!fs.existsSync(DB_FILE)){
    const wrapper = { revision: 1, updatedAt: nowIso(), data: sampleState() };
    fs.writeFileSync(DB_FILE, JSON.stringify(wrapper, null, 2));
    return wrapper;
  }
  try {
    const wrapper = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    if(!wrapper.data || !wrapper.revision) throw new Error('Invalid wrapper');
    return wrapper;
  } catch (err) {
    const corrupt = path.join(BACKUP_DIR, `corrupt-${stamp()}.json`);
    fs.copyFileSync(DB_FILE, corrupt);
    const wrapper = { revision: 1, updatedAt: nowIso(), data: sampleState(), warning: `Previous DB was corrupt. Preserved as ${path.basename(corrupt)}` };
    fs.writeFileSync(DB_FILE, JSON.stringify(wrapper, null, 2));
    return wrapper;
  }
}

function writeDb(wrapper){
  ensureDirs();
  fs.writeFileSync(DB_FILE, JSON.stringify(wrapper, null, 2));
}

function createBackup(reason='manual'){
  ensureDirs();
  if(fs.existsSync(DB_FILE)){
    const name = `pulse-backup-${reason}-${stamp()}.json`.replace(/[^a-zA-Z0-9_.-]/g,'-');
    fs.copyFileSync(DB_FILE, path.join(BACKUP_DIR, name));
    return name;
  }
  return null;
}

function normalizeData(data){
  if(!data || typeof data !== 'object') data = sampleState();
  data.schemaVersion = 9;
  data.appVersion = '9.0.0';
  data.currentWeek = data.currentWeek || '2026-W26';
  data.teams = Array.isArray(data.teams) ? data.teams : [];
  data.weeks = data.weeks || {};
  if(!data.weeks[data.currentWeek]) data.weeks[data.currentWeek] = { teams: {} };
  data.teams.forEach(t => {
    if(!data.weeks[data.currentWeek].teams[t.id]) data.weeks[data.currentWeek].teams[t.id] = emptyTeamWeek(t.name);
    data.weeks[data.currentWeek].teams[t.id].name = t.name;
  });
  Object.values(data.weeks).forEach(week => Object.values(week.teams || {}).forEach(ensureLabels));
  return data;
}

function sendJson(res, code, payload){
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(payload));
}

function parseBody(req){
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if(body.length > 20 * 1024 * 1024) reject(new Error('Body too large'));
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch (err) { reject(err); }
    });
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon'
};

function serveStatic(req, res){
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if(urlPath === '/') urlPath = '/index.html';
  const safePath = path.normalize(urlPath).replace(/^([/\\])+/, '');
  const filePath = path.join(ROOT, safePath);
  if(!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(filePath, (err, data) => {
    if(err){ res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    if(req.url.startsWith('/api/health')) return sendJson(res, 200, { ok: true, app: 'PULSE', version: '9.0.0', time: nowIso() });
    if(req.url.startsWith('/api/state') && req.method === 'GET') {
      const wrapper = readDb();
      wrapper.data = normalizeData(wrapper.data);
      writeDb(wrapper);
      return sendJson(res, 200, wrapper);
    }
    if(req.url.startsWith('/api/backup') && req.method === 'POST') {
      const body = await parseBody(req);
      const name = createBackup(body.reason || 'manual');
      return sendJson(res, 200, { ok: true, backup: name });
    }
    if(req.url.startsWith('/api/state') && req.method === 'POST') {
      const body = await parseBody(req);
      const current = readDb();
      current.data = normalizeData(current.data);
      let nextData;
      let merged = false;

      if(body.scope === 'team' && body.weekId && body.teamId && body.teamData) {
        nextData = current.data;
        if(!nextData.weeks[body.weekId]) nextData.weeks[body.weekId] = { teams: {} };
        nextData.weeks[body.weekId].teams[body.teamId] = body.teamData;
        nextData.weeks[body.weekId].teams[body.teamId].lastUpdated = nowIso();
        const team = nextData.teams.find(t => t.id === body.teamId);
        if(team) nextData.weeks[body.weekId].teams[body.teamId].name = team.name;
        merged = body.baseRevision !== current.revision;
      } else if(body.scope === 'full' && body.data) {
        if(body.baseRevision !== current.revision) {
          createBackup('conflict-full-save');
        }
        nextData = normalizeData(body.data);
      } else {
        return sendJson(res, 400, { ok: false, error: 'Invalid save payload.' });
      }

      const wrapper = { revision: current.revision + 1, updatedAt: nowIso(), data: normalizeData(nextData) };
      writeDb(wrapper);
      return sendJson(res, 200, { ok: true, revision: wrapper.revision, updatedAt: wrapper.updatedAt, merged });
    }
    return serveStatic(req, res);
  } catch (err) {
    return sendJson(res, 500, { ok: false, error: err.message || String(err) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  ensureDirs();
  readDb();
  console.log(`PULSE final is running at http://localhost:${PORT}`);
  console.log('Keep this window open while users are using the dashboard.');
});
