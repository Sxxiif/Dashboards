# PULSE Command User Manual

Choose your team, then update only that team's pages.

Pages:
- Dashboard: weekly summary, charts, and operating attention.
- Weekly Planner: tasks by day.
- Charts: create custom datasets and charts.
- People: add people using the popup.
- Leave / Time Off: add time off using the popup.
- Operations: operational items.
- Notes: weekly narrative and Word export.
