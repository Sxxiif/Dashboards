# PULSE Command

Offline/intranet weekly team dashboard.

## Start

1. Double-click `start-pulse-server.bat`.
2. Open the URL shown in the console, usually `http://localhost:8787`.
3. Choose one of the 3 teams: Technology, Operations, People.

## Add more teams later

Open `server.js` and edit the `DEFAULT_TEAMS` array near the top. Add a new object like:

```js
{ id: 'team-new-name', name: 'New Team Name' }
```

If the dashboard already has data, also add the team to `storage/pulse-db.json`, or start fresh by backing up and deleting `storage/pulse-db.json` before first real use.

## Notes

- No manager/leadership area.
- Word export only.
- All data saves automatically through the local server.
- Backups are kept in `storage/backups`.
