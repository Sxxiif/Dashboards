(function(){
  let saveTimer = null;
  window.PulseStore = {
    state: null,
    revision: 0,
    lastSnapshot: null,
    selectedTeamId: localStorage.getItem('pulse.v8.selectedTeamId') || '',
    mode: 'start',
    teamPage: 'dashboard',
    saving: false,
    dirty: false,
    async load(){
      const res = await fetch('/api/state', { cache: 'no-store' });
      if(!res.ok) throw new Error('Unable to load state');
      const wrapper = await res.json();
      this.state = wrapper.data;
      this.revision = wrapper.revision;
      this.normalize();
      return this.state;
    },
    normalize(){
      const s = this.state;
      if(!s.currentWeek) s.currentWeek = '2026-W26';
      if(!s.teams) s.teams=[];
      if(!s.weeks) s.weeks={};
      if(!s.weeks[s.currentWeek]) s.weeks[s.currentWeek]={teams:{}};
      s.teams.forEach(t=>{
        if(!s.weeks[s.currentWeek].teams[t.id]) s.weeks[s.currentWeek].teams[t.id] = window.PulseApp ? window.PulseApp.emptyTeamWeek(t.name) : { name:t.name, planner:{Sun:[],Mon:[],Tue:[],Wed:[],Thu:[],Fri:[],Sat:[]}, people:[], leave:[], operations:[], notes:{}, datasets:[], charts:[] };
        s.weeks[s.currentWeek].teams[t.id].name = t.name;
      });
    },
    snapshot(){
      this.lastSnapshot = JSON.stringify(this.state);
    },
    undo(){
      if(!this.lastSnapshot) return false;
      const current = JSON.stringify(this.state);
      this.state = JSON.parse(this.lastSnapshot);
      this.lastSnapshot = current;
      this.saveFull('undo');
      return true;
    },
    markDirty(scope='team'){
      this.dirty = true;
      const pill = document.getElementById('saved-pill');
      if(pill){ pill.textContent='Saving…'; pill.className='pill warn'; }
      clearTimeout(saveTimer);
      saveTimer = setTimeout(()=>this.save(scope), 450);
    },
    async save(scope='team'){
      if(this.saving || !this.state) return;
      this.saving = true;
      try{
        let payload;
        if(scope==='team' && this.selectedTeamId && this.mode==='team'){
          const weekId = this.state.currentWeek;
          const teamData = this.state.weeks[weekId]?.teams?.[this.selectedTeamId];
          payload = { scope:'team', baseRevision:this.revision, weekId, teamId:this.selectedTeamId, teamData };
        } else {
          payload = { scope:'full', baseRevision:this.revision, data:this.state };
        }
        const res = await fetch('/api/state', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
        const out = await res.json();
        if(!res.ok || !out.ok) throw new Error(out.error || 'Save failed');
        this.revision = out.revision;
        this.dirty = false;
        const pill = document.getElementById('saved-pill');
        if(pill){ pill.textContent = out.merged ? 'Merged + saved ✓' : 'Saved ✓'; pill.className='pill good'; }
      }catch(err){
        const pill = document.getElementById('saved-pill');
        if(pill){ pill.textContent='Save error'; pill.className='pill bad'; }
        console.error(err);
        alert('PULSE could not save. Keep this page open and contact the dashboard owner. Error: '+err.message);
      }finally{
        this.saving=false;
      }
    },
    saveFull(reason='full'){
      return this.save('full');
    },
    async backup(reason='manual'){
      try{
        await fetch('/api/backup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({reason}) });
      }catch(err){ console.warn('Backup request failed', err); }
    },
    setSelectedTeam(id){
      this.selectedTeamId = id || '';
      if(id) localStorage.setItem('pulse.v8.selectedTeamId', id);
      else localStorage.removeItem('pulse.v8.selectedTeamId');
    }
  };
})();
