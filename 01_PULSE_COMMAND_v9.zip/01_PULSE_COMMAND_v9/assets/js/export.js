(function(){
  const esc = v => String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  function table(headers, rows){
    return `<table border="1" cellspacing="0" cellpadding="6" style="border-collapse:collapse;width:100%;font-size:12px;margin:12px 0"><thead><tr>${headers.map(h=>`<th style="background:#eef2ff;text-align:left">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  }
  function taskRows(team){ const rows=[]; Object.keys(team.planner||{}).forEach(day=>(team.planner[day]||[]).forEach(t=>rows.push([day,t.text,t.owner,t.status,t.priority,t.due,t.blocker]))); return rows; }
  function stats(team){ const tasks=taskRows(team); const total=tasks.length; const done=tasks.filter(r=>r[3]==='Done').length; return {total,done,pct:total?Math.round(done/total*100):0,blocked:tasks.filter(r=>r[3]==='Blocked').length,high:tasks.filter(r=>r[4]==='High').length}; }
  function noteBlock(team){ const n=team.notes||{}; return `<h2>Notes</h2><p><b>Weekly update:</b><br>${esc(n.update||'')}</p><p><b>Wins:</b><br>${esc(n.wins||'')}</p><p><b>Risks / blockers:</b><br>${esc(n.risks||'')}</p><p><b>Decisions needed:</b><br>${esc(n.decisions||'')}</p><p><b>Next week focus:</b><br>${esc(n.next||'')}</p>`; }
  function teamHtml(team, teamName){
    const st=stats(team);
    const people=(team.people||[]).map(p=>[p.staffId||'',p.name||'',p.role||'']);
    const leave=(team.leave||[]).map(l=>[l.person,l.type,l.from,l.to,l.backup,l.notes]);
    const ops=(team.operations||[]).map(o=>[o.item,o.owner,o.status,o.priority,o.due,o.notes]);
    let body=`<h1>PULSE Weekly Report · ${esc(teamName)}</h1><p><b>Done:</b> ${st.pct}% &nbsp; <b>Tasks:</b> ${st.total} &nbsp; <b>Blocked:</b> ${st.blocked} &nbsp; <b>High priority:</b> ${st.high}</p>`;
    body+=`<h2>Weekly Planner</h2>${table(['Day','Task','Owner','Status','Priority','Due','Blocker'], taskRows(team))}`;
    body+=`<h2>People</h2>${table(['ID','Name','Role'], people)}`;
    body+=`<h2>Leave / Time Off</h2>${table(['Person','Type','From','To','Backup','Notes'], leave)}`;
    body+=`<h2>Operations</h2>${table(['Item','Owner','Status','Priority','Due','Notes'], ops)}`;
    body+=noteBlock(team);
    return `<!doctype html><html><head><meta charset="utf-8"><title>PULSE Weekly Report</title></head><body style="font-family:Segoe UI,Arial;margin:28px;color:#111">${body}<p style="color:#666;font-size:11px">Built by sxxiif</p></body></html>`;
  }
  function download(name, content, type){ const blob=new Blob([content],{type}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href); a.remove();},500); }
  function exportTeamWord(team, teamName){ download(`PULSE-${teamName}-weekly-report.doc`, teamHtml(team, teamName), 'application/msword'); }
  window.PulseExport = { exportTeamWord, download };
})();
