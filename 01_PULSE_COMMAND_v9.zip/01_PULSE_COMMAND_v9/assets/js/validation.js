(function(){
  const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  function allTasks(team){ return DAYS.flatMap(day => (team.planner?.[day] || []).map(t => ({...t, day}))); }
  function taskStats(team){
    const tasks = allTasks(team || {});
    const total = tasks.length;
    const done = tasks.filter(t=>t.status==='Done').length;
    const blocked = tasks.filter(t=>t.status==='Blocked').length;
    const high = tasks.filter(t=>t.priority==='High').length;
    const pct = total ? Math.round(done/total*100) : 0;
    return { tasks,total,done,blocked,high,pct };
  }
  function leaveDays(record){
    if(!record?.from || !record?.to) return 0;
    const from = new Date(record.from+'T00:00:00');
    const to = new Date(record.to+'T00:00:00');
    if(isNaN(from) || isNaN(to) || to < from) return 0;
    return Math.round((to-from)/86400000)+1;
  }
  function peopleAway(team){
    const names = new Set((team?.leave || []).filter(l => l.person && l.from && l.to && leaveDays(l)>0).map(l => String(l.person).trim().toLowerCase()));
    return names.size;
  }
  function teamWarnings(team){
    team = team || {};
    const warnings=[];
    allTasks(team).forEach(t=>{
      if(!String(t.text||'').trim()) warnings.push({level:'critical', text:`${t.day}: task is missing text.`});
      if(!String(t.owner||'').trim()) warnings.push({level:'warning', text:`${t.day}: "${t.text||'Task'}" has no owner.`});
      if(t.priority==='High' && !String(t.owner||'').trim()) warnings.push({level:'critical', text:`${t.day}: high priority task has no owner.`});
      if(t.status==='Blocked' && !String(t.blocker||'').trim()) warnings.push({level:'warning', text:`${t.day}: blocked task needs a blocker note.`});
    });
    (team.leave||[]).forEach(l=>{
      if(!l.person) warnings.push({level:'warning', text:'Time off record is missing person.'});
      if(l.from && l.to && new Date(l.to) < new Date(l.from)) warnings.push({level:'critical', text:`Time off date is invalid for ${l.person||'person'}.`});
      if(!l.backup) warnings.push({level:'warning', text:`Time off for ${l.person||'person'} has no backup/coverage owner.`});
    });
    (team.operations||[]).forEach(o=>{
      if(!o.item) warnings.push({level:'warning', text:'Operation item is missing.'});
      if(!o.owner) warnings.push({level:'warning', text:`Operation "${o.item||'item'}" has no owner.`});
      if(!o.status) warnings.push({level:'warning', text:`Operation "${o.item||'item'}" has no status.`});
    });
    const notes = team.notes || {};
    if(!notes.update && !notes.wins && !notes.risks && !notes.decisions && !notes.next) warnings.push({level:'warning', text:'Weekly notes are empty.'});
    return warnings;
  }
  window.PulseValidation = { DAYS, allTasks, taskStats, peopleAway, leaveDays, teamWarnings };
})();
