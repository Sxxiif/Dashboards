(function(){
  const COLORS = ['#5b7cff','#ec4899','#22c55e','#f59e0b','#8b5cf6','#22d3ee','#94a3b8','#ef4444'];
  function esc(v){ return String(v ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }
  function fmt(n){
    n = Number(n)||0;
    if(Math.abs(n)>=1000000) return (n/1000000).toFixed(1)+'M';
    if(Math.abs(n)>=1000) return (n/1000).toFixed(1)+'K';
    return String(Math.round(n*10)/10);
  }
  function empty(msg='No chart data yet'){
    return `<div class="chart-empty">${esc(msg)}</div>`;
  }
  function donut(title, rows){
    rows = (rows||[]).filter(r => Number(r.value)>0);
    if(!rows.length) return empty();
    const total = rows.reduce((a,r)=>a+Number(r.value||0),0);
    let acc=0; const cx=210, cy=170, r=108, sw=46;
    const segs = rows.map((row,i)=>{
      const val=Number(row.value||0), frac=val/total;
      const dash=frac*2*Math.PI*r;
      const gap=2*Math.PI*r-dash;
      const rot=(acc/total)*360-90; acc+=val;
      return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${COLORS[i%COLORS.length]}" stroke-width="${sw}" stroke-dasharray="${dash} ${gap}" transform="rotate(${rot} ${cx} ${cy})" stroke-linecap="butt"></circle>`;
    }).join('');
    const legend = rows.map((row,i)=>`<div class="legend-item"><span class="dot" style="background:${COLORS[i%COLORS.length]}"></span>${esc(row.label)} · ${fmt(row.value)}</div>`).join('');
    return `<svg class="chart-svg" viewBox="0 0 680 360" role="img" aria-label="${esc(title)}">
      <rect width="680" height="360" fill="transparent"></rect>
      <g>${segs}</g>
      <circle cx="${cx}" cy="${cy}" r="67" fill="#151b2b"></circle>
      <text x="${cx}" y="${cy-6}" text-anchor="middle" fill="#e8eefc" font-size="30" font-weight="900">${fmt(total)}</text>
      <text x="${cx}" y="${cy+22}" text-anchor="middle" fill="#95a3bd" font-size="13">total</text>
      ${rows.map((row,i)=>`<g transform="translate(390 ${72+i*36})"><rect width="14" height="14" rx="4" fill="${COLORS[i%COLORS.length]}"></rect><text x="24" y="12" fill="#dbeafe" font-size="14" font-weight="700">${esc(row.label)}</text><text x="230" y="12" fill="#95a3bd" font-size="14" text-anchor="end">${fmt(row.value)}</text></g>`).join('')}
    </svg><div class="legend">${legend}</div>`;
  }
  function bar(title, rows, opts={}){
    rows = (rows||[]).map(r=>({label:String(r.label), value:Number(r.value)||0}));
    if(!rows.length) return empty();
    const w=780,h=390,ml=62,mr=24,mt=36,mb=58;
    const max=Math.max(1,...rows.map(r=>r.value));
    const plotW=w-ml-mr, plotH=h-mt-mb, bw=Math.max(20,plotW/rows.length*0.56), gap=plotW/rows.length;
    let grid=''; for(let i=0;i<=4;i++){ const y=mt+plotH-i*plotH/4; const val=max*i/4; grid+=`<line x1="${ml}" y1="${y}" x2="${w-mr}" y2="${y}" stroke="#27334d"/><text x="${ml-12}" y="${y+4}" fill="#95a3bd" font-size="12" text-anchor="end">${fmt(val)}</text>`; }
    const bars=rows.map((r,i)=>{ const x=ml+i*gap+(gap-bw)/2; const bh=(r.value/max)*plotH; const y=mt+plotH-bh; return `<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="7" fill="url(#barGrad)"></rect><text x="${x+bw/2}" y="${Math.max(y-8,16)}" fill="#e8eefc" font-size="12" font-weight="800" text-anchor="middle">${fmt(r.value)}</text><text x="${x+bw/2}" y="${h-26}" fill="#95a3bd" font-size="12" text-anchor="middle">${esc(r.label).slice(0,12)}</text>`; }).join('');
    return `<svg class="chart-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(title)}">
      <defs><linearGradient id="barGrad" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#7c8dff"/><stop offset="1" stop-color="#6d28d9"/></linearGradient></defs>
      <rect width="${w}" height="${h}" fill="transparent"></rect>${grid}<line x1="${ml}" y1="${mt+plotH}" x2="${w-mr}" y2="${mt+plotH}" stroke="#394767"/>${bars}
    </svg>`;
  }
  function horizontalBar(title, rows){
    rows = (rows||[]).map(r=>({label:String(r.label), value:Number(r.value)||0}));
    if(!rows.length) return empty();
    const w=780,h=Math.max(340,80+rows.length*38),ml=160,mr=46,mt=34,mb=34;
    const max=Math.max(1,...rows.map(r=>r.value)); const plotW=w-ml-mr;
    const bars=rows.map((r,i)=>{const y=mt+i*38; const bw=(r.value/max)*plotW; return `<text x="${ml-12}" y="${y+18}" fill="#cbd5e1" font-size="13" text-anchor="end">${esc(r.label).slice(0,20)}</text><rect x="${ml}" y="${y}" width="${plotW}" height="20" rx="8" fill="#202a42"></rect><rect x="${ml}" y="${y}" width="${bw}" height="20" rx="8" fill="url(#hbarGrad)"></rect><text x="${ml+bw+8}" y="${y+15}" fill="#e8eefc" font-size="12" font-weight="800">${fmt(r.value)}</text>`}).join('');
    return `<svg class="chart-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(title)}"><defs><linearGradient id="hbarGrad" x1="0" x2="1"><stop offset="0" stop-color="#5b7cff"/><stop offset="1" stop-color="#ec4899"/></linearGradient></defs><rect width="${w}" height="${h}" fill="transparent"></rect>${bars}</svg>`;
  }
  function line(title, rows){
    rows=(rows||[]).map(r=>({label:String(r.label), value:Number(r.value)||0}));
    if(rows.length<2) return empty('Need at least two points for a line chart');
    const w=780,h=390,ml=62,mr=30,mt=34,mb=62,plotW=w-ml-mr,plotH=h-mt-mb;
    const max=Math.max(1,...rows.map(r=>r.value));
    let grid=''; for(let i=0;i<=4;i++){ const y=mt+plotH-i*plotH/4; const val=max*i/4; grid+=`<line x1="${ml}" y1="${y}" x2="${w-mr}" y2="${y}" stroke="#27334d"/><text x="${ml-12}" y="${y+4}" fill="#95a3bd" font-size="12" text-anchor="end">${fmt(val)}</text>`; }
    const pts=rows.map((r,i)=>[ml+i*(plotW/(rows.length-1)), mt+plotH-(r.value/max)*plotH, r]);
    const path='M '+pts.map(p=>p[0]+','+p[1]).join(' L ');
    return `<svg class="chart-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(title)}"><defs><linearGradient id="lineFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#5b7cff" stop-opacity=".32"/><stop offset="1" stop-color="#5b7cff" stop-opacity="0"/></linearGradient></defs><rect width="${w}" height="${h}" fill="transparent"></rect>${grid}<path d="${path} L ${pts[pts.length-1][0]},${mt+plotH} L ${pts[0][0]},${mt+plotH} Z" fill="url(#lineFill)"></path><path d="${path}" fill="none" stroke="#7c8dff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>${pts.map((p,i)=>`<circle cx="${p[0]}" cy="${p[1]}" r="6" fill="#ec4899" stroke="#0d111b" stroke-width="3"></circle><text x="${p[0]}" y="${Math.max(p[1]-14,16)}" fill="#e8eefc" font-size="12" font-weight="800" text-anchor="middle">${fmt(p[2].value)}</text><text x="${p[0]}" y="${h-26}" fill="#95a3bd" font-size="12" text-anchor="middle">${esc(p[2].label).slice(0,10)}</text>`).join('')}</svg>`;
  }
  function renderCustom(chart, dataset){
    if(!chart || !dataset) return empty('Dataset missing');
    const rows=(dataset.rows||[]).map(r=>({label:r.label,value:r.value}));
    if(chart.type==='donut') return donut(chart.title, rows);
    if(chart.type==='line') return line(chart.title, rows);
    return rows.length>7 ? horizontalBar(chart.title, rows) : bar(chart.title, rows);
  }
  window.PulseCharts = { donut, bar, horizontalBar, line, renderCustom, empty, fmt, esc, COLORS };
})();
