(function(){
  const { DAYS } = PulseValidation;
  const $ = sel => document.querySelector(sel);
  const html = v => PulseCharts.esc(v);
  const uid = prefix => `${prefix}-${Math.random().toString(16).slice(2,10)}`;
  const clone = obj => JSON.parse(JSON.stringify(obj));

  const DEFAULT_LABELS = {
    planner:{ text:'Task details', owner:'Owner', due:'Due date', status:'Status', priority:'Priority', blocker:'Blocker note' },
    people:{ id:'ID', name:'Name', role:'Role' },
    leave:{ person:'Person', type:'Type', from:'From', to:'To', backup:'Backup / Coverage', notes:'Notes' },
    operations:{ item:'Item', status:'Status', owner:'Owner', priority:'Priority', due:'Due date', notes:'Notes' },
    notes:{ update:'Weekly update', wins:'Wins', risks:'Risks / blockers', decisions:'Decisions needed', next:'Next week focus' }
  };

  function emptyTeamWeek(name){
    return { name, lastUpdated:new Date().toISOString(), planner:{Sun:[],Mon:[],Tue:[],Wed:[],Thu:[],Fri:[],Sat:[]}, people:[], leave:[], operations:[], notes:{update:'',wins:'',risks:'',decisions:'',next:''}, datasets:[], charts:[], labels:clone(DEFAULT_LABELS) };
  }
  function state(){ return PulseStore.state; }
  function weekData(){
    const s=state();
    if(!s.weeks[s.currentWeek]) s.weeks[s.currentWeek]={teams:{}};
    s.teams.forEach(t=>{ if(!s.weeks[s.currentWeek].teams[t.id]) s.weeks[s.currentWeek].teams[t.id]=emptyTeamWeek(t.name); });
    return s.weeks[s.currentWeek];
  }
  function selectedTeamMeta(){ return state().teams.find(t=>t.id===PulseStore.selectedTeamId); }
  function ensureLabels(team){
    if(!team.labels) team.labels=clone(DEFAULT_LABELS);
    Object.keys(DEFAULT_LABELS).forEach(section=>{
      if(!team.labels[section]) team.labels[section]={};
      Object.keys(DEFAULT_LABELS[section]).forEach(key=>{ if(!team.labels[section][key]) team.labels[section][key]=DEFAULT_LABELS[section][key]; });
      Object.keys(team.labels[section]).forEach(key=>{ if(!(key in DEFAULT_LABELS[section])) delete team.labels[section][key]; });
    });
    return team.labels;
  }
  function selectedTeam(){
    const meta=selectedTeamMeta(); if(!meta) return null;
    const wd=weekData(); if(!wd.teams[meta.id]) wd.teams[meta.id]=emptyTeamWeek(meta.name);
    wd.teams[meta.id].name=meta.name; ensureLabels(wd.teams[meta.id]); return wd.teams[meta.id];
  }
  function label(section,key,fallback){ const t=selectedTeam(); const labels=t?ensureLabels(t):DEFAULT_LABELS; return labels?.[section]?.[key] || fallback || key; }
  function snapshotAndDirty(scope='team'){ PulseStore.snapshot(); const t=selectedTeam(); if(t) t.lastUpdated=new Date().toISOString(); PulseStore.markDirty(scope); renderHeader(); }
  function setMode(mode){
    PulseStore.mode=mode;
    $('#start-screen').hidden = mode !== 'start';
    $('#team-shell').hidden = mode !== 'team';
    $('#topbar').hidden = mode === 'start';
    renderHeader();
  }
  function renderHeader(){
    $('#switch-team-btn').hidden = PulseStore.mode === 'start';
    $('#undo-btn').hidden = PulseStore.mode === 'start';
  }
  function renderWeekSelects(){
    const weeks=Object.keys(state().weeks||{}).sort().reverse();
    const opts=weeks.map(w=>`<option value="${html(w)}" ${w===state().currentWeek?'selected':''}>${html(w)}</option>`).join('');
    $('#week-select').innerHTML=opts;
  }
  function switchWeek(w){ state().currentWeek=w; PulseStore.markDirty('full'); renderAll(); }
  function opts(values,current){ return values.map(v=>`<option ${v===(current||values[0])?'selected':''}>${html(v)}</option>`).join(''); }
  function badgeClass(v){ return String(v||'').toLowerCase().replace(/[^a-z]/g,'') || 'todo'; }
  function kpi(label,value,sub,color){ return `<div class="kpi" style="--accent:${color}"><div class="kpi-label">${html(label)}</div><div class="kpi-value">${html(value)}</div><div class="kpi-sub">${html(sub)}</div></div>`; }
  function emptyState(title,desc){ return `<div class="empty-state"><div class="empty-icon">◇</div><h3>${html(title)}</h3><p>${html(desc)}</p></div>`; }
  function warningHtml(warnings){ if(!warnings.length) return `<div class="empty-state"><h3>Looks clean</h3><p>No important warnings for this week.</p></div>`; return `<div class="warning-list">${warnings.map(w=>`<div class="warning ${w.level==='critical'?'critical':''}">${html(w.text)}</div>`).join('')}</div>`; }


  function dueState(due){
    if(!due) return '';
    const today = new Date(); today.setHours(0,0,0,0);
    const target = new Date(due + 'T00:00:00');
    if(isNaN(target)) return '';
    const diff = Math.round((target - today) / 86400000);
    if(diff < 0) return 'overdue';
    if(diff <= 2) return 'due-soon';
    return '';
  }
  function attentionItems(team){
    const tasks = PulseValidation.allTasks(team);
    const items = [];
    const blocked = tasks.filter(t=>t.status==='Blocked');
    const highOpen = tasks.filter(t=>t.priority==='High' && t.status!=='Done');
    const dueSoon = tasks.filter(t=>t.status!=='Done' && dueState(t.due));
    const leaveMissingBackup = (team.leave||[]).filter(l=>l.person && l.from && l.to && !String(l.backup||'').trim());
    const opsBlocked = (team.operations||[]).filter(o=>o.status==='Blocked' || (o.priority==='High' && o.status!=='Done'));
    if(blocked.length) items.push({level:'critical', title:`${blocked.length} blocked task${blocked.length===1?'':'s'}`, text: blocked.slice(0,3).map(t=>`${t.day}: ${t.text||'Untitled'}`).join(' · '), page:'planner'});
    if(highOpen.length) items.push({level:'warning', title:`${highOpen.length} open high-priority task${highOpen.length===1?'':'s'}`, text: highOpen.slice(0,3).map(t=>`${t.day}: ${t.text||'Untitled'}`).join(' · '), page:'planner'});
    if(dueSoon.length) items.push({level:'warning', title:`${dueSoon.length} due/overdue task${dueSoon.length===1?'':'s'}`, text: dueSoon.slice(0,3).map(t=>`${t.text||'Task'} (${t.due})`).join(' · '), page:'planner'});
    if(leaveMissingBackup.length) items.push({level:'warning', title:`${leaveMissingBackup.length} leave record${leaveMissingBackup.length===1?'':'s'} missing backup`, text: leaveMissingBackup.slice(0,3).map(l=>`${l.person}: ${l.from} → ${l.to}`).join(' · '), page:'leave'});
    if(opsBlocked.length) items.push({level:'warning', title:`${opsBlocked.length} operation item${opsBlocked.length===1?'':'s'} need attention`, text: opsBlocked.slice(0,3).map(o=>`${o.item||'Operation'} · ${o.status||'No status'}`).join(' · '), page:'operations'});
    const n = team.notes || {};
    if(!n.update && !n.wins && !n.risks && !n.decisions && !n.next) items.push({level:'info', title:'Weekly notes are empty', text:'Add a short update, wins, blockers, decisions, and next-week focus.', page:'notes'});
    return items;
  }
  function attentionPanel(team){
    const items = attentionItems(team);
    if(!items.length){
      return `<div class="attention-ok"><div class="attention-ok-mark">✓</div><div><h3>Operating attention is clear</h3><p>No blocked work, urgent due dates, missing leave coverage, or empty weekly update detected.</p></div></div>`;
    }
    return `<div class="attention-list">${items.map(item=>`<button class="attention-item ${html(item.level)}" data-attention-page="${html(item.page)}"><div><div class="attention-title">${html(item.title)}</div><div class="attention-text">${html(item.text)}</div></div><span>Open</span></button>`).join('')}</div>`;
  }
  function bindAttention(scope=document){
    scope.querySelectorAll('[data-attention-page]').forEach(btn=>btn.addEventListener('click',()=>setTeamPage(btn.dataset.attentionPage)));
  }

  function labelEditor(section, fields){
    const team=selectedTeam(); ensureLabels(team);
    return `<details class="label-editor"><summary>Customize labels</summary><div class="label-grid">${fields.map(([key,fallback])=>`<label><span>${html(fallback)}</span><input data-label-section="${section}" data-label-key="${key}" value="${html(label(section,key,fallback))}"></label>`).join('')}</div><p class="label-help">Only this team is affected. Use it when another team uses different wording.</p></details>`;
  }
  function bindLabelEditor(){
    const team=selectedTeam(); if(!team) return; ensureLabels(team);
    document.querySelectorAll('[data-label-section][data-label-key]').forEach(input=>{
      input.addEventListener('input',()=>{
        const sec=input.dataset.labelSection, key=input.dataset.labelKey;
        if(!team.labels[sec]) team.labels[sec]={};
        team.labels[sec][key]=input.value.trim() || DEFAULT_LABELS[sec]?.[key] || key;
        snapshotAndDirty();
      });
    });
  }

  function openModal(title, bodyHtml, options={}){
    const root=$('#modal-root');
    root.hidden=false;
    root.innerHTML=`<div class="modal ${options.wide?'chart-modal':''}" role="dialog" aria-modal="true"><div class="modal-head"><div class="modal-title">${html(title)}</div><button class="modal-close" data-close-modal>×</button></div><div class="modal-body">${bodyHtml}</div>${options.actions===false?'':`<div class="modal-actions"><button class="btn ghost" data-close-modal>Cancel</button><button class="btn primary" id="modal-save-btn">${html(options.saveText||'Save')}</button></div>`}</div>`;
    const close=()=>{ root.hidden=true; root.innerHTML=''; document.removeEventListener('keydown',escClose); };
    const escClose=e=>{ if(e.key==='Escape') close(); };
    document.addEventListener('keydown',escClose);
    root.querySelectorAll('[data-close-modal]').forEach(b=>b.addEventListener('click',close));
    root.addEventListener('click',e=>{ if(e.target===root) close(); }, {once:true});
    if(options.onSave && root.querySelector('#modal-save-btn')) root.querySelector('#modal-save-btn').addEventListener('click',()=>{ options.onSave(root); close(); });
    return {root, close};
  }
  function openChartModal(title, chartHtml){ openModal(title, `<div class="chart-box large">${chartHtml}</div>`, {wide:true, actions:false}); }
  function bindMaximize(scope=document){
    scope.querySelectorAll('[data-max-chart]').forEach(btn=>btn.addEventListener('click',()=>{
      const card=btn.closest('.card,.chart-card'); const title=btn.dataset.title || card?.querySelector('.card-title')?.textContent || 'Chart'; const box=card?.querySelector('.chart-box');
      openChartModal(title, box ? box.innerHTML : PulseCharts.empty());
    }));
  }
  function chartCard(title,desc,body,size=''){
    return `<div class="card"><div class="card-head"><div><div class="card-title">${html(title)}</div><div class="card-desc">${html(desc)}</div></div><div class="card-actions"><button class="btn small ghost" data-max-chart data-title="${html(title)}">Maximize</button></div></div><div class="card-body chart-box ${size}">${body}</div></div>`;
  }
  function customChartHtml(c,team){ const ds=(team.datasets||[]).find(d=>d.id===c.datasetId); return `<div class="chart-card"><div class="card-head"><div><div class="card-title">${html(c.title)}</div><div class="card-desc">${html(ds?.name||'Missing dataset')}</div></div><div class="card-actions"><button class="btn small ghost" data-max-chart data-title="${html(c.title)}">Maximize</button></div></div><div class="chart-box">${PulseCharts.renderCustom(c,ds)}</div></div>`; }

  function renderTeamPicker(){
    const wrap=$('#team-picker');
    wrap.innerHTML=(state().teams||[]).map(t=>{
      const team=state().weeks[state().currentWeek]?.teams?.[t.id] || emptyTeamWeek(t.name); const st=PulseValidation.taskStats(team);
      return `<button class="team-card" data-team-id="${html(t.id)}"><h3>${html(t.name)}</h3><p>Open only this team workspace</p><div class="team-card-kpi"><span>${st.total} tasks</span><span>${st.pct}% done</span><span>${PulseValidation.peopleAway(team)} away</span></div></button>`;
    }).join('') || `<div class="empty-state"><h3>No teams yet</h3><p>Add more teams later by editing server.js/sample data and storage/pulse-db.json as described in docs/ADMIN_GUIDE.md.</p></div>`;
    wrap.querySelectorAll('.team-card').forEach(btn=>btn.addEventListener('click',()=>selectTeam(btn.dataset.teamId)));
  }
  function selectTeam(id){ PulseStore.setSelectedTeam(id); PulseStore.teamPage='dashboard'; setMode('team'); renderTeamShell(); }
  function renderTeamShell(){
    const meta=selectedTeamMeta(); const team=selectedTeam(); if(!meta||!team){ setMode('start'); renderTeamPicker(); return; }
    $('#team-title').textContent=`${meta.name} Workspace`; $('#team-subtitle').textContent=`Only ${meta.name} data is shown here.`;
    renderWeekSelects(); $('#team-tabs').querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page===PulseStore.teamPage)); renderTeamPage(); renderHeader();
  }
  function setTeamPage(page){ PulseStore.teamPage=page; renderTeamShell(); }
  function renderTeamPage(){
    const page=PulseStore.teamPage;
    if(page==='dashboard') return renderDashboard();
    if(page==='planner') return renderPlanner();
    if(page==='charts') return renderTeamCharts();
    if(page==='people') return renderPeople();
    if(page==='leave') return renderLeave();
    if(page==='operations') return renderOperations();
    if(page==='notes') return renderNotes();
    return renderDashboard();
  }

  function dashboardRows(){
    const team=selectedTeam(); const st=PulseValidation.taskStats(team);
    return {
      st,
      byStatus:['To-do','Doing','Done','Blocked'].map(s=>({label:s,value:st.tasks.filter(t=>t.status===s).length})),
      byPriority:['High','Med','Low'].map(p=>({label:p,value:st.tasks.filter(t=>t.priority===p).length})),
      byDay:DAYS.map(d=>({label:d,value:(team.planner[d]||[]).length}))
    };
  }
  function notesSummary(team){ const n=team.notes||{}; return n.update || n.wins || n.risks || n.next || 'No weekly note has been added yet.'; }
  function renderDashboard(){
    const team=selectedTeam(); const meta=selectedTeamMeta(); const {st,byStatus,byPriority,byDay}=dashboardRows(); const previewCharts=(team.charts||[]).slice(0,4);
    $('#team-page').innerHTML=`<div class="dashboard-hero"><div><div class="eyebrow">Weekly command view</div><h2>${html(meta.name)} Dashboard</h2><p>${html(notesSummary(team)).slice(0,280)}</p></div><button class="btn primary" data-go-page="planner">Update planner</button></div>
    <div class="grid kpis">${kpi('Done %',st.pct+'%',`${st.done} of ${st.total} complete`,'#22c55e')}${kpi('Total tasks',st.total,'This week','#5b7cff')}${kpi('Blocked',st.blocked,'Needs attention','#f59e0b')}${kpi('High priority',st.high,'Important work','#ef4444')}${kpi('People', (team.people||[]).length, 'Team members','#8b5cf6')}${kpi('People away',PulseValidation.peopleAway(team),'Leave / Time Off','#22d3ee')}</div>
    <div style="height:16px"></div><div class="grid three">${chartCard('Tasks by status','Current week task distribution',PulseCharts.donut('Tasks by status',byStatus))}${chartCard('Priority mix','High / Medium / Low priority work',PulseCharts.donut('Priority mix',byPriority))}${chartCard('Tasks by day','Weekly planner activity by day',PulseCharts.bar('Tasks by day',byDay))}</div>
    <div style="height:16px"></div><div class="grid wide-left"><div class="card"><div class="card-head"><div><div class="card-title">Team-created charts preview</div><div class="card-desc">Latest charts created by ${html(meta.name)}.</div></div><button class="btn small ghost" data-go-page="charts">Open Charts</button></div><div class="card-body"><div class="chart-grid">${previewCharts.length?previewCharts.map(c=>customChartHtml(c,team)).join(''):emptyState('No charts yet','Create charts from the Charts page to show them here.')}</div></div></div><div class="card attention-card"><div class="card-head"><div><div class="card-title">Operating attention</div><div class="card-desc">Clickable items that need a team action</div></div></div><div class="card-body">${attentionPanel(team)}</div></div></div>`;
    $('#team-page').querySelectorAll('[data-go-page]').forEach(b=>b.addEventListener('click',()=>setTeamPage(b.dataset.goPage))); bindAttention($('#team-page')); bindMaximize($('#team-page'));
  }

  function renderPlanner(){
    const team=selectedTeam();
    $('#team-page').innerHTML=`<div class="toolbar"><div class="filters"><input id="task-search" class="search" placeholder="Search tasks or owners"><select id="status-filter"><option value="">All statuses</option><option>To-do</option><option>Doing</option><option>Done</option><option>Blocked</option></select><select id="priority-filter"><option value="">All priorities</option><option>High</option><option>Med</option><option>Low</option></select></div></div>${labelEditor('planner',[['text','Task details'],['owner','Owner'],['due','Due date'],['status','Status'],['priority','Priority'],['blocker','Blocker note']])}<div class="planner-board" id="planner-board"></div>`;
    bindLabelEditor();
    const renderBoard=()=>{ const q=$('#task-search').value.toLowerCase(); const sf=$('#status-filter').value; const pf=$('#priority-filter').value;
      $('#planner-board').innerHTML=DAYS.map(day=>{ const tasks=(team.planner[day]||[]).filter(t=>(!q||`${t.text} ${t.owner}`.toLowerCase().includes(q))&&(!sf||t.status===sf)&&(!pf||t.priority===pf)); return `<div class="day-column"><div class="day-head"><div class="day-name">${day}</div><button class="btn small" data-add-task="${day}">+ Task</button></div><div class="task-list">${tasks.length?tasks.map(t=>taskCard(day,t)).join(''):emptyState('No tasks','Add task for '+day)}</div></div>`; }).join(''); bindTaskEvents(); };
    ['task-search','status-filter','priority-filter'].forEach(id=>$('#'+id).addEventListener('input',renderBoard)); renderBoard();
  }
  function taskCard(day,t){ return `<div class="task-card ${t.priority==='High'?'high':''} ${t.status==='Blocked'?'blocked':''}" data-task-id="${html(t.id)}" data-day="${day}"><textarea class="task-text" data-field="text" placeholder="${html(label('planner','text','Task details'))}">${html(t.text)}</textarea><div class="task-row task-owner-row"><input data-field="owner" placeholder="${html(label('planner','owner','Owner'))}" value="${html(t.owner)}"><input data-field="due" aria-label="${html(label('planner','due','Due date'))}" title="${html(label('planner','due','Due date'))}" type="date" value="${html(t.due||'')}"></div><div class="task-row"><select data-field="status" aria-label="${html(label('planner','status','Status'))}">${opts(['To-do','Doing','Done','Blocked'],t.status)}</select><select data-field="priority" aria-label="${html(label('planner','priority','Priority'))}">${opts(['Low','Med','High'],t.priority)}</select></div><input data-field="blocker" placeholder="${html(label('planner','blocker','Blocker note'))}" value="${html(t.blocker||'')}"><div style="display:flex;justify-content:space-between;margin-top:10px"><span><span class="badge ${badgeClass(t.status)}">${html(t.status)}</span> <span class="badge ${badgeClass(t.priority)}">${html(t.priority)}</span></span><button class="btn small danger" data-delete-task>Delete</button></div></div>`; }
  function bindTaskEvents(){
    $('#planner-board').querySelectorAll('[data-add-task]').forEach(b=>b.addEventListener('click',()=>{ const day=b.dataset.addTask; selectedTeam().planner[day].push({id:uid('task'),text:'',owner:'',status:'To-do',priority:'Med',blocker:'',due:''}); snapshotAndDirty(); renderPlanner(); }));
    $('#planner-board').querySelectorAll('.task-card').forEach(card=>{ const day=card.dataset.day, id=card.dataset.taskId; const task=selectedTeam().planner[day].find(t=>t.id===id); card.querySelectorAll('[data-field]').forEach(el=>el.addEventListener('input',()=>{ task[el.dataset.field]=el.value; snapshotAndDirty(); })); card.querySelector('[data-delete-task]').addEventListener('click',()=>{ if(confirm('Delete this task?')){ selectedTeam().planner[day]=selectedTeam().planner[day].filter(t=>t.id!==id); snapshotAndDirty(); renderPlanner(); }}); });
  }

  function renderTeamCharts(){
    const team=selectedTeam();
    $('#team-page').innerHTML=`<div class="grid wide-left"><div class="card"><div class="card-head"><div><div class="card-title">Charts board</div><div class="card-desc">Create charts from team datasets. Use Maximize when chart names become long or crowded.</div></div><button class="btn small primary" id="add-chart-btn">+ Add chart</button></div><div class="card-body"><div class="chart-grid">${(team.charts||[]).length?team.charts.map(c=>chartEditor(c,team)).join(''):emptyState('No charts yet','Add a dataset, then create a chart.')}</div></div></div><div class="card"><div class="card-head"><div><div class="card-title">Datasets</div><div class="card-desc">Rows are label + number.</div></div><button class="btn small primary" id="add-dataset-btn">+ Dataset</button></div><div class="card-body"><div class="grid">${(team.datasets||[]).map(datasetEditor).join('') || emptyState('No datasets','Create the first dataset.')}</div></div></div></div>`;
    $('#add-dataset-btn').addEventListener('click',()=>{ team.datasets.push({id:uid('ds'),name:'New dataset',rows:[{id:uid('row'),label:'Item 1',value:10},{id:uid('row'),label:'Item 2',value:20}]}); snapshotAndDirty(); renderTeamCharts(); });
    $('#add-chart-btn').addEventListener('click',()=>{ if(!team.datasets.length) return alert('Create a dataset first.'); team.charts.push({id:uid('chart'),title:'New chart',type:'bar',datasetId:team.datasets[0].id}); snapshotAndDirty(); renderTeamCharts(); });
    bindDatasetEvents(); bindChartEvents(); bindMaximize($('#team-page'));
  }
  function datasetEditor(ds){ return `<div class="dataset-card" data-ds-id="${html(ds.id)}"><input data-ds-name value="${html(ds.name)}" style="width:100%;font-weight:900;margin-bottom:10px">${(ds.rows||[]).map(r=>`<div class="dataset-row" data-row-id="${html(r.id)}"><input data-row-label value="${html(r.label)}"><input data-row-value type="number" value="${html(r.value)}"><button class="btn small danger" data-delete-row>Delete</button></div>`).join('')}<div style="display:flex;gap:8px;margin-top:10px"><button class="btn small" data-add-row>+ Row</button><button class="btn small danger" data-delete-ds>Delete dataset</button></div></div>`; }
  function chartEditor(c,team){ const ds=(team.datasets||[]).find(d=>d.id===c.datasetId); return `<div class="chart-card" data-chart-id="${html(c.id)}"><div class="card-head"><div style="flex:1"><input data-chart-title value="${html(c.title)}" style="width:100%;font-weight:900"><div class="card-desc">${html(ds?.name||'Missing dataset')}</div></div><div class="card-actions"><button class="btn small ghost" data-max-chart data-title="${html(c.title)}">Maximize</button></div></div><div class="card-body"><div class="chart-config"><select data-chart-type>${opts(['bar','line','donut'],c.type)}</select><select data-chart-dataset>${(team.datasets||[]).map(d=>`<option value="${html(d.id)}" ${d.id===c.datasetId?'selected':''}>${html(d.name)}</option>`).join('')}</select><button class="btn small danger" data-delete-chart>Delete</button></div><div class="chart-box">${PulseCharts.renderCustom(c,ds)}</div></div></div>`; }
  function bindDatasetEvents(){ const team=selectedTeam(); $('#team-page').querySelectorAll('[data-ds-id]').forEach(card=>{ const ds=team.datasets.find(d=>d.id===card.dataset.dsId); card.querySelector('[data-ds-name]').addEventListener('input',e=>{ ds.name=e.target.value; snapshotAndDirty(); }); card.querySelector('[data-add-row]').addEventListener('click',()=>{ ds.rows.push({id:uid('row'),label:'New item',value:0}); snapshotAndDirty(); renderTeamCharts(); }); card.querySelector('[data-delete-ds]').addEventListener('click',()=>{ if(confirm('Delete this dataset and charts using it?')){ team.datasets=team.datasets.filter(d=>d.id!==ds.id); team.charts=team.charts.filter(c=>c.datasetId!==ds.id); snapshotAndDirty(); renderTeamCharts(); }}); card.querySelectorAll('[data-row-id]').forEach(row=>{ const r=ds.rows.find(x=>x.id===row.dataset.rowId); row.querySelector('[data-row-label]').addEventListener('input',e=>{r.label=e.target.value; snapshotAndDirty();}); row.querySelector('[data-row-value]').addEventListener('input',e=>{r.value=Number(e.target.value)||0; snapshotAndDirty();}); row.querySelector('[data-delete-row]').addEventListener('click',()=>{ds.rows=ds.rows.filter(x=>x.id!==r.id); snapshotAndDirty(); renderTeamCharts();}); }); }); }
  function bindChartEvents(){ const team=selectedTeam(); $('#team-page').querySelectorAll('[data-chart-id]').forEach(card=>{ const c=team.charts.find(x=>x.id===card.dataset.chartId); card.querySelector('[data-chart-title]').addEventListener('input',e=>{c.title=e.target.value; snapshotAndDirty();}); card.querySelector('[data-chart-type]').addEventListener('change',e=>{c.type=e.target.value; snapshotAndDirty(); renderTeamCharts();}); card.querySelector('[data-chart-dataset]').addEventListener('change',e=>{c.datasetId=e.target.value; snapshotAndDirty(); renderTeamCharts();}); card.querySelector('[data-delete-chart]').addEventListener('click',()=>{ if(confirm('Delete this chart?')){ team.charts=team.charts.filter(x=>x.id!==c.id); snapshotAndDirty(); renderTeamCharts(); }}); }); }

  function renderPeople(){
    const team=selectedTeam();
    $('#team-page').innerHTML=`<div class="toolbar"><div><h2>People</h2><p class="muted-text">Simple team directory. Only ID, name, and role are required.</p></div><button class="btn primary" id="add-person-btn">+ Add person</button></div>${labelEditor('people',[['id','ID'],['name','Name'],['role','Role']])}<div class="summary-strip"><div class="mini-stat"><div class="label">People</div><div class="value">${(team.people||[]).length}</div></div><div class="mini-stat"><div class="label">People away</div><div class="value">${PulseValidation.peopleAway(team)}</div></div></div><div class="people-list">${(team.people||[]).length?(team.people||[]).map(personCard).join(''):emptyState('No people yet','Click Add person to create the team list.')}</div>`;
    bindLabelEditor(); $('#add-person-btn').addEventListener('click',()=>openPersonModal());
    $('#team-page').querySelectorAll('[data-edit-person]').forEach(b=>b.addEventListener('click',()=>openPersonModal(b.dataset.editPerson)));
    $('#team-page').querySelectorAll('[data-delete-person]').forEach(b=>b.addEventListener('click',()=>{ if(confirm('Delete this person?')){ team.people=team.people.filter(p=>p.id!==b.dataset.deletePerson); snapshotAndDirty(); renderPeople(); }}));
  }
  function personCard(p){ return `<div class="person-card"><div class="person-top"><div><div class="person-name">${html(p.name||'Unnamed')}</div><div class="person-role">${html(p.role||'No role')}</div></div><span class="person-id">${html(p.staffId||p.employeeId||p.id)}</span></div><div class="card-footer-actions"><button class="btn small ghost" data-edit-person="${html(p.id)}">Edit</button><button class="btn small danger" data-delete-person="${html(p.id)}">Delete</button></div></div>`; }
  function openPersonModal(id){ const team=selectedTeam(); const existing=(team.people||[]).find(p=>p.id===id); const p=existing||{id:uid('person'),staffId:'',name:'',role:''}; openModal(existing?'Edit person':'Add person', `<div class="modal-form"><label>${html(label('people','id','ID'))}<input id="m-person-id" value="${html(p.staffId||p.employeeId||'')}"></label><label>${html(label('people','name','Name'))}<input id="m-person-name" value="${html(p.name||'')}"></label><label>${html(label('people','role','Role'))}<input id="m-person-role" value="${html(p.role||'')}"></label></div>`, {saveText: existing?'Save person':'Add person', onSave:(root)=>{ p.staffId=root.querySelector('#m-person-id').value.trim(); p.name=root.querySelector('#m-person-name').value.trim(); p.role=root.querySelector('#m-person-role').value.trim(); if(!existing) team.people.push(p); snapshotAndDirty(); renderPeople(); }}); }

  function renderLeave(){
    const team=selectedTeam(); const totalDays=(team.leave||[]).reduce((a,l)=>a+PulseValidation.leaveDays(l),0);
    $('#team-page').innerHTML=`<div class="toolbar"><div><h2>Leave / Time Off</h2><p class="muted-text">Shows who will be off and from when to when.</p></div><button class="btn primary" id="add-leave-btn">+ Add time off</button></div>${labelEditor('leave',[['person','Person'],['type','Type'],['from','From'],['to','To'],['backup','Backup / Coverage'],['notes','Notes']])}<div class="summary-strip"><div class="mini-stat"><div class="label">People away</div><div class="value">${PulseValidation.peopleAway(team)}</div></div><div class="mini-stat"><div class="label">Total days</div><div class="value">${totalDays}</div></div></div><div class="leave-list">${(team.leave||[]).length?(team.leave||[]).map(leaveCard).join(''):emptyState('No time off yet','Click Add time off to add leave, WFH, training, or public holiday records.')}</div>`;
    bindLabelEditor(); $('#add-leave-btn').addEventListener('click',()=>openLeaveModal());
    $('#team-page').querySelectorAll('[data-edit-leave]').forEach(b=>b.addEventListener('click',()=>openLeaveModal(b.dataset.editLeave)));
    $('#team-page').querySelectorAll('[data-delete-leave]').forEach(b=>b.addEventListener('click',()=>{ if(confirm('Delete this time off record?')){ team.leave=team.leave.filter(l=>l.id!==b.dataset.deleteLeave); snapshotAndDirty(); renderLeave(); }}));
  }
  function leaveCard(l){ const days=PulseValidation.leaveDays(l); return `<div class="leave-card"><div class="leave-top"><div><div class="leave-name">${html(l.person||'Person')}</div><div class="leave-range">${html(l.from||'No start')} → ${html(l.to||'No end')} · ${days} day${days===1?'':'s'}</div></div><span class="badge ${badgeClass(l.type)}">${html(l.type||'Time Off')}</span></div><div class="muted-small">Backup: ${html(l.backup||'Not assigned')}</div>${l.notes?`<div>${html(l.notes)}</div>`:''}<div class="card-footer-actions"><button class="btn small ghost" data-edit-leave="${html(l.id)}">Edit</button><button class="btn small danger" data-delete-leave="${html(l.id)}">Delete</button></div></div>`; }
  function openLeaveModal(id){ const team=selectedTeam(); const existing=(team.leave||[]).find(l=>l.id===id); const l=existing||{id:uid('leave'),person:'',type:'Annual Leave',from:'',to:'',backup:'',notes:''}; openModal(existing?'Edit time off':'Add time off', `<div class="modal-form"><label>${html(label('leave','person','Person'))}<input id="m-leave-person" value="${html(l.person||'')}"></label><label>${html(label('leave','type','Type'))}<select id="m-leave-type">${opts(['Annual Leave','Sick Leave','Training','Work From Home','Public Holiday','Other'],l.type)}</select></label><label>${html(label('leave','from','From'))}<input id="m-leave-from" type="date" value="${html(l.from||'')}"></label><label>${html(label('leave','to','To'))}<input id="m-leave-to" type="date" value="${html(l.to||'')}"></label><label>${html(label('leave','backup','Backup / Coverage'))}<input id="m-leave-backup" value="${html(l.backup||'')}"></label><label>${html(label('leave','notes','Notes'))}<textarea id="m-leave-notes">${html(l.notes||'')}</textarea></label></div>`, {saveText: existing?'Save time off':'Add time off', onSave:(root)=>{ l.person=root.querySelector('#m-leave-person').value.trim(); l.type=root.querySelector('#m-leave-type').value; l.from=root.querySelector('#m-leave-from').value; l.to=root.querySelector('#m-leave-to').value; l.backup=root.querySelector('#m-leave-backup').value.trim(); l.notes=root.querySelector('#m-leave-notes').value; if(!existing) team.leave.push(l); snapshotAndDirty(); renderLeave(); }}); }

  function renderOperations(){
    const team=selectedTeam(); const byStatus=['To-do','Doing','Done','Blocked'].map(s=>({label:s,value:(team.operations||[]).filter(o=>o.status===s).length}));
    $('#team-page').innerHTML=`<div class="toolbar"><div><h2>Operations</h2><p class="muted-text">Track operational items without crowding the weekly planner.</p></div><button class="btn primary" id="add-op-btn">+ Add operation</button></div>${labelEditor('operations',[['item','Item'],['owner','Owner'],['status','Status'],['priority','Priority'],['due','Due date'],['notes','Notes']])}<div class="grid wide-left"><div class="ops-list">${(team.operations||[]).length?(team.operations||[]).map(opCard).join(''):emptyState('No operations yet','Click Add operation to create the first item.')}</div>${chartCard('Operations by status','Auto-generated from this page',PulseCharts.donut('Operations by status',byStatus),'large')}</div>`;
    bindLabelEditor(); bindMaximize($('#team-page')); $('#add-op-btn').addEventListener('click',()=>openOperationModal());
    $('#team-page').querySelectorAll('[data-edit-op]').forEach(b=>b.addEventListener('click',()=>openOperationModal(b.dataset.editOp)));
    $('#team-page').querySelectorAll('[data-delete-op]').forEach(b=>b.addEventListener('click',()=>{ if(confirm('Delete this operation?')){ team.operations=team.operations.filter(o=>o.id!==b.dataset.deleteOp); snapshotAndDirty(); renderOperations(); }}));
  }
  function opCard(o){ return `<div class="op-card"><div class="op-top"><div><div class="op-name">${html(o.item||'Operation item')}</div><div class="op-meta">${html(o.owner||'No owner')} · ${html(o.due||'No due date')}</div></div><span class="badge ${badgeClass(o.status)}">${html(o.status||'To-do')}</span></div><div><span class="badge ${badgeClass(o.priority)}">${html(o.priority||'Med')}</span></div>${o.notes?`<div class="muted-small">${html(o.notes)}</div>`:''}<div class="card-footer-actions"><button class="btn small ghost" data-edit-op="${html(o.id)}">Edit</button><button class="btn small danger" data-delete-op="${html(o.id)}">Delete</button></div></div>`; }
  function openOperationModal(id){ const team=selectedTeam(); const existing=(team.operations||[]).find(o=>o.id===id); const o=existing||{id:uid('op'),item:'',status:'To-do',owner:'',priority:'Med',due:'',notes:''}; openModal(existing?'Edit operation':'Add operation', `<div class="modal-form"><label>${html(label('operations','item','Item'))}<input id="m-op-item" value="${html(o.item||'')}"></label><label>${html(label('operations','owner','Owner'))}<input id="m-op-owner" value="${html(o.owner||'')}"></label><label>${html(label('operations','status','Status'))}<select id="m-op-status">${opts(['To-do','Doing','Done','Blocked'],o.status)}</select></label><label>${html(label('operations','priority','Priority'))}<select id="m-op-priority">${opts(['Low','Med','High'],o.priority)}</select></label><label>${html(label('operations','due','Due date'))}<input id="m-op-due" type="date" value="${html(o.due||'')}"></label><label>${html(label('operations','notes','Notes'))}<textarea id="m-op-notes">${html(o.notes||'')}</textarea></label></div>`, {saveText: existing?'Save operation':'Add operation', onSave:(root)=>{ o.item=root.querySelector('#m-op-item').value.trim(); o.owner=root.querySelector('#m-op-owner').value.trim(); o.status=root.querySelector('#m-op-status').value; o.priority=root.querySelector('#m-op-priority').value; o.due=root.querySelector('#m-op-due').value; o.notes=root.querySelector('#m-op-notes').value; if(!existing) team.operations.push(o); snapshotAndDirty(); renderOperations(); }}); }

  function renderNotes(){
    const team=selectedTeam(); const n=team.notes || (team.notes={update:'',wins:'',risks:'',decisions:'',next:''});
    const labels=[['update','Weekly update'],['wins','Wins'],['risks','Risks / blockers'],['decisions','Decisions needed'],['next','Next week focus']];
    $('#team-page').innerHTML=`<div class="toolbar"><div><h2>Notes</h2><p class="muted-text">Clean weekly narrative for the team update.</p></div><button class="btn primary" id="notes-word-btn">Export Word</button></div>${labelEditor('notes',labels)}<div class="notes-grid v8">${labels.map(([key,txt])=>`<div class="card pad note-card"><label>${html(label('notes',key,txt))}</label><textarea data-note="${key}">${html(n[key]||'')}</textarea></div>`).join('')}</div>`;
    bindLabelEditor(); $('#notes-word-btn').addEventListener('click',()=>PulseExport.exportTeamWord(team, selectedTeamMeta().name)); $('#team-page').querySelectorAll('[data-note]').forEach(el=>el.addEventListener('input',()=>{ n[el.dataset.note]=el.value; snapshotAndDirty(); }));
  }

  function createNewWeek(){ const current=state().currentWeek; const next=prompt('Enter new week ID (example: 2026-W27)', current); if(!next) return; if(!state().weeks[next]) state().weeks[next]={teams:{}}; state().teams.forEach(t=>{ if(!state().weeks[next].teams[t.id]) state().weeks[next].teams[t.id]=emptyTeamWeek(t.name); }); state().currentWeek=next; snapshotAndDirty('full'); renderAll(); }
  function copyPreviousWeek(){ const weeks=Object.keys(state().weeks).sort(); const idx=weeks.indexOf(state().currentWeek); const prev=weeks[idx-1]; if(!prev) return alert('No previous week found.'); if(!confirm(`Copy previous week ${prev} into ${state().currentWeek}? This will replace current week data.`)) return; state().weeks[state().currentWeek]=clone(state().weeks[prev]); Object.values(state().weeks[state().currentWeek].teams).forEach(t=>{ t.lastUpdated=new Date().toISOString(); }); snapshotAndDirty('full'); renderAll(); }
  function renderAll(){ renderTeamPicker(); renderWeekSelects(); if(PulseStore.mode==='team') renderTeamShell(); renderHeader(); }
  function bindGlobal(){
    $('#switch-team-btn').addEventListener('click',()=>{ PulseStore.setSelectedTeam(''); setMode('start'); renderTeamPicker(); });
    $('#undo-btn').addEventListener('click',()=>{ if(PulseStore.undo()) setTimeout(renderAll,150); else alert('Nothing to undo yet.'); });
    $('#team-tabs').addEventListener('click',e=>{ if(e.target.matches('.tab')) setTeamPage(e.target.dataset.page); });
    $('#week-select').addEventListener('change',e=>switchWeek(e.target.value));
    $('#new-week-btn').addEventListener('click',createNewWeek); $('#copy-week-btn').addEventListener('click',copyPreviousWeek);
    $('#header-word-btn').addEventListener('click',()=>{ const t=selectedTeam(); const m=selectedTeamMeta(); if(t&&m) PulseExport.exportTeamWord(t,m.name); });
  }
  async function init(){ bindGlobal(); try{ await PulseStore.load(); } catch(err){ console.error(err); $('#start-screen').hidden=true; $('#server-error').hidden=false; return; } renderTeamPicker(); const remembered=PulseStore.selectedTeamId && state().teams.some(t=>t.id===PulseStore.selectedTeamId); if(remembered){ setMode('team'); renderTeamShell(); } else { setMode('start'); } }
  window.PulseApp={ init, emptyTeamWeek };
  document.addEventListener('DOMContentLoaded', init);
})();
