# GitHub Upload Checklist

Use this before pushing the dashboard to GitHub.

## Files to include

```text
index.html
README.md
LOGO_README.md
.gitignore
```

Optional:

```text
logo.png
```

Only add `logo.png` if you are allowed to publish it.

## Files not to include

Do not upload files that contain real internal data:

```text
exported dashboard JSON files
weekly data backups
PDF reports
Word reports
screenshots with real team data
company-confidential logos
```

## Before pushing

Check the following:

- Dashboard opens offline by double-clicking `index.html`
- No CDN links
- No external scripts
- No real company/team sensitive data inside default demo data
- No real employee information
- No confidential screenshots
- Logo is allowed to be uploaded, or removed
- README does not mention private internal details

## Suggested commands

```bash
git status
git add index.html README.md LOGO_README.md .gitignore GITHUB_UPLOAD_CHECKLIST.md
git commit -m "Add offline weekly dashboard"
git push
```

If adding a logo:

```bash
git add logo.png
git commit -m "Add dashboard logo"
git push
```

## Public repository safety

If the repository is public, keep all content generic.

Use names like:

```text
Team 1
Team 2
Team 3
System A
System B
Sample User
```

Avoid:

```text
real employee names
real system names
real case numbers
real internal references
real operational data
```
