# Offline Dashboard External JavaScript Version

Use these files together in the same folder:

```text
index.html
app.js
```

Open `index.html` in Microsoft Edge or Google Chrome on the VDI.

Do not rename `app.js` unless you also update this line inside `index.html`:

```html
<script src="app.js" defer></script>
```

If the dashboard still does not load, the VDI is likely blocking local JavaScript files. In that case, ask IT/security to allow local HTML active content, or run the file through an approved internal web server/share.
