@echo off
cd /d "%~dp0"
title PULSE Atlas Pro Server
node server.js
pause
