# PULSE Atlas Pro

A fresh, professional weekly team dashboard built from scratch.

This option is intentionally different from the earlier PULSE versions. It uses a restrained enterprise dark UI, a left workspace rail, large chart cards, modal-based editing, and a clean team-only workflow.

## Start

1. Install Node.js on the host machine if it is not installed.
2. Extract this folder.
3. Double-click `start-pulse-server.bat`.
4. Open the URL shown in the command window.

No npm install is required.

## Teams included

The dashboard starts with only three teams:

- Technology
- Operations
- People

## How to add more teams later

Open `storage/pulse-db.json`, copy an existing team object inside the `teams` array, then change:

- `id` to a unique lowercase value, such as `security`
- `name` to the display name, such as `Security`

Clear or update that team's tasks, people, leave, operations, notes, datasets, and charts. Save the JSON and restart the server.

The same instruction is also written as a code comment at the top of `server.js`.

## What is included

- Choose team start screen
- Team-only workspace
- Dashboard
- Weekly Planner
- Charts builder
- Chart maximize overlay
- People popup: ID, Name, Role
- Leave / Time Off popup
- Operations popup
- Notes
- Word export only
- Autosave through local/intranet server
- Server-side JSON storage
- Automatic backup before each team save
- Undo last local change
- Customizable team labels

## Removed by design

- Finance
- Manager / Leadership
- PDF export
- CSV export
- Global admin bar
- Shared JSON controls for normal users
- Workload / availability fields

## Files

```text
PULSE_ATLAS_PRO/
  index.html
  server.js
  start-pulse-server.bat
  storage/
    pulse-db.json
    sample-pulse-db.json
    backups/
  docs/
    FINAL_TEST_REPORT.md
```

## Notes

This is an offline/intranet browser application. It is not a security permission system. Any user who can open the URL can select any of the three teams unless a passcode/login layer is added later.
