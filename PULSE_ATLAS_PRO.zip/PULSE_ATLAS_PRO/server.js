/*
  PULSE ATLAS PRO - offline/intranet server

  HOW TO ADD MORE TEAMS LATER:
  1) Stop the server.
  2) Open storage/pulse-db.json in a text editor.
  3) Copy one team object inside the "teams" array.
  4) Change id to a unique lowercase value, e.g. "security".
  5) Change name to the display name, e.g. "Security".
  6) Clear or edit tasks/people/leave/operations/notes/charts as needed.
  7) Save the JSON and restart the server.

  No npm install is required. Start with: node server.js
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = Number(process.env.PORT || 8787);
const ROOT = __dirname;
const STORAGE = path.join(ROOT, 'storage');
const DB_PATH = path.join(STORAGE, 'pulse-db.json');
const BACKUP_DIR = path.join(STORAGE, 'backups');

fs.mkdirSync(STORAGE, { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8'
};

function nowIso() { return new Date().toISOString(); }
function readJson() { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
function writeJson(data) { fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2)); }
function backup(reason) {
  try {
    if (!fs.existsSync(DB_PATH)) return null;
    const safeReason = String(reason || 'auto').replace(/[^a-z0-9_-]/gi, '_').slice(0, 32);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const target = path.join(BACKUP_DIR, `pulse-db-${stamp}-${safeReason}.json`);
    fs.copyFileSync(DB_PATH, target);
    return path.basename(target);
  } catch (err) {
    console.error('Backup failed:', err.message);
    return null;
  }
}

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 20 * 1024 * 1024) reject(new Error('Request too large'));
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function sanitizeTeam(team) {
  if (!team || typeof team !== 'object') throw new Error('Invalid team payload');
  if (!team.id || !team.name) throw new Error('Team must have id and name');
  const clone = JSON.parse(JSON.stringify(team));
  clone.updatedAt = nowIso();
  return clone;
}

function serveStatic(req, res) {
  const parsed = url.parse(req.url);
  let rel = decodeURIComponent(parsed.pathname || '/');
  if (rel === '/') rel = '/index.html';
  const filePath = path.normalize(path.join(ROOT, rel));
  if (!filePath.startsWith(ROOT)) return send(res, 403, 'Forbidden', 'text/plain; charset=utf-8');
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
    const type = MIME[path.extname(filePath)] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const parsed = url.parse(req.url, true);
    if (parsed.pathname === '/api/health') return send(res, 200, { ok: true, app: 'PULSE_ATLAS_PRO', time: nowIso() });
    if (parsed.pathname === '/api/state' && req.method === 'GET') {
      return send(res, 200, { ok: true, state: readJson() });
    }
    if (parsed.pathname === '/api/team' && req.method === 'POST') {
      const payload = JSON.parse(await readBody(req));
      const team = sanitizeTeam(payload.team);
      const db = readJson();
      const idx = db.teams.findIndex(t => t.id === team.id);
      if (idx < 0) return send(res, 404, { ok: false, error: 'Team not found' });
      backup('before-team-save');
      db.teams[idx] = team;
      db.updatedAt = nowIso();
      db.revision = Number(db.revision || 0) + 1;
      writeJson(db);
      return send(res, 200, { ok: true, revision: db.revision, updatedAt: db.updatedAt });
    }
    if (parsed.pathname === '/api/backup' && req.method === 'POST') {
      const file = backup('manual');
      return send(res, 200, { ok: true, backup: file });
    }
    serveStatic(req, res);
  } catch (err) {
    console.error(err);
    send(res, 500, { ok: false, error: err.message || 'Server error' });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('PULSE Atlas Pro is running');
  console.log(`Open: http://localhost:${PORT}`);
  console.log(`For others on the network: http://<THIS-PC-NAME-OR-IP>:${PORT}`);
});
