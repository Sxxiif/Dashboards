# PULSE — Weekly Team Dashboard · Manual

**Built by sxxiif**

PULSE is a single HTML file. It runs fully offline, needs no internet, no
install, and no libraries. Double-click it and it opens in your browser
(Edge or Chrome on Windows recommended).

---

## 1. What it does

One shared dashboard for all your teams. Everyone sees everything, plus an
all-teams overview. It's built for **weekly updates**: each team fills in their
week — tasks per day, finance, people, operations, notes — and it stays saved
as the latest state.

- **All-Teams Overview** — company rollup: team completion %, totals, status charts.
- **Per team** — a weekly planner (Sun–Sat), plus editable Finance / People /
  Operations tables and a weekly notes box.
- **Charts Board** — build your own charts (bar / line / donut) from your own data.
- **Export** — each team (or all teams) to PDF or Word.

---

## 2. Saving & the shared folder (important)

PULSE saves your work in two layers:

**A. Automatic local save.** Every change is saved instantly inside the browser
on that PC. The dot at the top shows **Saving… → Saved**. If you refresh or
reopen, your work is still there. You don't have to do anything.

**B. The shared file (the master copy for everyone).** Because a web page is not
allowed to silently write to a network folder, PULSE uses the browser's built-in
file access:

1. Click **Link shared file** once.
2. Choose (or create) `pulse-data.json` in your shared folder.
3. From then on, PULSE **auto-writes every change back to that file**. The
   indicator reads "Saved to shared file."

Anyone else opening PULSE clicks **Load**, picks that same `pulse-data.json`,
and sees the latest data — and their changes save back to it too.

> **The one honest limitation:** "Link shared file" auto-save works in Edge and
> Chrome on Windows (they support the File System Access API). If your browser
> doesn't, PULSE falls back to a one-click **download / Load** of
> `pulse-data.json` instead — slightly more manual, but it still works
> everywhere, and the automatic *local* save (layer A) always protects your work.

**Tip:** because everyone shares one file, it's a weekly-update tool — coordinate
so two people aren't editing the exact same second. Last save wins.

---

## 3. Daily tasks (the weekly planner)

Open a team → **Weekly Planner**. Seven day cards, Sun to Sat. Today is highlighted.

- Click **+ Task** under any day.
- Type the task, set **Status** (To-do / Doing / Done / Blocked), **Priority**
  (Low / Med / High), and an optional **Owner**.
- Tasks are colour-coded by status. Click a task to edit it; hover and click ×
  to delete it.
- The team's **Done %** updates automatically and rolls up into the overview.

Move between weeks with the **‹ ›** arrows; **Today** jumps back to this week.
Past weeks are kept — it's a full history.

---

## 4. Editing tables (Finance / People / Operations)

Each is a simple editable table:

- **+ Add line / person / item** adds a row. Type directly into any cell.
- **+ Col** adds a custom column; hover a column header and click × to remove it.
- Hover a row and click × to remove it.
- Everything saves automatically as you type.

---

## 4b. Absence page

Each team has an **Absence** table (Name / Type / From / To / Days / Status) for
logging time off — sick leave, annual leave, missions, etc.

- **+ Add item** adds a row; type directly into any cell.
- **+ Col** adds a custom column if you need more detail.
- All absences roll up automatically into **All-Teams Overview → Absence — all
  teams**, so leadership sees who's out across the whole company in one place.
- Absences are included in the PDF / Word export.

> Keep the first column as a name and use the standard column names (Type, From,
> To, Days, Status) so the overview rollup lines them up correctly.

---

## 4c. Team Charts (per-team)

In addition to the company-wide **Charts Board**, every team has its own **Team
Charts** section at the bottom of its page — for visualising that team's data and
outcomes.

- Scroll to **Team Charts → Add chart**.
- Name it, pick **Bar / Line / Donut**, and enter your data items (label + value).
- The chart is saved with that team and appears only on that team's page.
- Hover a chart to **Edit** or delete it.

Use the company **Charts Board** for cross-team/company numbers, and **Team
Charts** for a single team's metrics (velocity, output, spend trend, etc.).

---

## 5. Teams

- **+ Add team** (bottom of the sidebar) — name it; it gets its own colour.
- Click the **team name in the top bar** for actions: type `rename`, `color`,
  or `remove`.
- Removing a team can be reversed with **Undo** (top bar) if done immediately.

---

## 6. Building your own charts

Go to **Charts Board → Add chart**:

1. Give it a title.
2. Pick **Bar**, **Line**, or **Donut**.
3. Add data items — a label and a number each (**+ Add item**).
4. **Save chart**. It appears on the board.

Hover a chart to **Edit** or delete it. Charts are saved with everything else.

---

## 7. Exporting

Top bar → **Export**:

- **Scope** — one team, or all teams.
- **PDF (print)** — opens a clean report and your browser's print dialog; choose
  *Save as PDF*. Works natively on Windows.
- **Word (.doc)** — downloads a Word document of the report.

The report includes the week's planner, the Finance / People / Operations tables,
and the notes.

---

## 8. Performance notes (VDI)

PULSE is deliberately lightweight: no libraries, no animation loops, no blur, no
constant timers. Charts are simple SVG that only redraw when something changes.
It should run smoothly on a low-resource VDI session.

---

## 9. Editing the file itself

Open `PULSE.html` in a text editor. It's organised in clearly-commented sections:
core (data + saving), render, team view, tasks, charts, builder, export. Colours
live in the `:root{ }` block at the top of the `<style>` — change `--accent` to
re-theme. Search for a function name to find any feature.

---

*PULSE · Built by sxxiif · runs fully offline*

---

## 10. Light / Dark theme

Click the sun/moon button in the top bar to switch between light and dark.
Your choice is saved with your data and restored next time.

## 11. The team tabs

Each team page is now organised into tabs so it stays light and uncluttered:

- **Planner** — the Sun–Sat weekly task board.
- **Tables** — Finance, People, Operations, Absence.
- **Charts** — this team's own custom charts.
- **Activity** — heatmaps and week history (below).
- **Notes** — the weekly notes box.

Only one tab renders at a time, which keeps the page fast on a VDI. (When you
Export to PDF/Word, all tabs are included in the report.)

## 12. The Activity tab

- **Activity — last 18 weeks**: a calendar-style heatmap; darker squares mean
  more tasks completed that week.
- **This week — task distribution**: a grid showing tasks by day and status.
- **Week history**: every recorded week as an expandable row — click to see its
  done / in-progress / blocked counts and that week's notes.

## 13. Your company logo

The dashboard can show your logo instead of the "PULSE" wordmark:

1. Put a `logo.png` (or `logo.svg`) in the **assets** folder next to `index.html`.
2. Refresh — it appears automatically in the sidebar.

Recommended size ~140×36 px, transparent PNG. If no logo file is present, the
text wordmark is shown. (This is why PULSE ships as a small folder: `index.html`
plus an `assets` folder for your logo. Keep them together.)

## 14. Week-over-week

The overview's Tasks and Completion cards show a small **↑ / ↓ vs last week**
badge, comparing this week to the previous one — so you can see at a glance
whether things are improving.


*PULSE · Built by sxxiif · runs fully offline*
