PULSE — assets folder
=====================
Drop your company logo here to replace the "PULSE" wordmark in the sidebar.

HOW TO USE YOUR OWN LOGO:
  1. Name your file  logo.png   (or  logo.svg)
  2. Put it in this  assets/  folder, replacing the one here.
  3. Refresh the dashboard — your logo appears automatically.

Recommended size: about 140 x 36 pixels (wide, short). A transparent PNG
looks best. If no logo file is found, PULSE shows its text wordmark instead.
