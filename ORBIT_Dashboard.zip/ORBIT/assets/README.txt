ORBIT — assets folder
Drop your company logo here as  logo.png  (or logo.svg) to replace the ORBIT
wordmark in the top bar. Recommended ~150x40px. Since ORBIT is dark-themed,
a white or light-colored transparent PNG looks best.
