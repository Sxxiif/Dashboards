(function () {
  'use strict';
  var KEY = 'soc-console-v4';
  var STATUSES = ['Available', 'On-call', 'Busy', 'Leave'];
  var app = document.getElementById('app');
  var fileInput = document.getElementById('importFile');

  var state = {
    data: null,
    view: 'overview',
    team: 'team1',
    online: (typeof navigator !== 'undefined' ? navigator.onLine : true),
    forcedOffline: false,
    sidebarCollapsed: false,
    collapsed: {}
  };
  var pendingPersist = null;

  // ---------------- utils ----------------
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function uid() { return Math.random().toString(36).slice(2, 9); }
  function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }
  function num(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }
  function mondayISO(dt) { var d = new Date(dt); var day = (d.getDay() + 6) % 7; d.setDate(d.getDate() - day); d.setHours(0, 0, 0, 0); return d.toISOString().slice(0, 10); }
  function addDays(iso, n) { var d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); }
  function relTime(ts) { if (!ts) return 'never'; var s = Math.floor((Date.now() - ts) / 1000); if (s < 45) return 'just now'; if (s < 3600) return Math.floor(s / 60) + 'm ago'; if (s < 86400) return Math.floor(s / 3600) + 'h ago'; return Math.floor(s / 86400) + 'd ago'; }
  function initials(name) { return (name || '?').trim().split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase() || '?'; }
  function memberStatusColor(s) { return s === 'Available' ? 'var(--good)' : s === 'On-call' ? 'var(--accent-2)' : s === 'Busy' ? 'var(--warn)' : 'var(--bad)'; }
  function colorFor(cls) { return cls === 'bad' ? 'var(--bad)' : cls === 'warn' ? 'var(--warn)' : 'var(--good)'; }

  function persist(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) {} }
  function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
  function schedulePersist() { clearTimeout(pendingPersist); pendingPersist = setTimeout(function () { persist(state.data); }, 400); }

  // ---------------- schema builders ----------------
  function mkCols(list) {
    var used = {};
    return list.map(function (pair) {
      var label = pair[0], type = pair[1];
      var k = slug(label) || 'c'; while (used[k]) k += '_'; used[k] = 1;
      return { id: uid(), key: k, label: label, type: type, fixed: true };
    });
  }
  function keyOf(cols, label) { var c = cols.filter(function (x) { return x.label === label; })[0]; return c ? c.key : slug(label); }
  function secDef(type, sid, title, subtitle, extra) { return Object.assign({ id: uid(), type: type, sid: sid, title: title, subtitle: subtitle || '' }, extra || {}); }

  function buildSections() {
    function S(t, sid, title, sub, ex) { return secDef(t, sid, title, sub, ex); }

    var t1machines = mkCols([['System Name', 'text'], ['Description', 'text'], ['Machines Active', 'number'], ['Machines Inactive', 'number']]);
    var t1tasks = mkCols([['Date', 'date'], ['Ref Number', 'text'], ['Case Name', 'text'], ['Total Received', 'number'], ['Total Recovered', 'number'], ['Complexity', 'text'], ['Urgent', 'text'], ['Saif.Created', 'text'], ['Progress %', 'number'], ['Result Progress %', 'number']]);
    var t1outcomes = mkCols([['System Name', 'text'], ['Status Line', 'text'], ['Active Tasks', 'number'], ['Pending', 'number'], ['Completed', 'number']]);
    var t1jira = mkCols([['From Date', 'date'], ['To Date', 'date'], ['Total Tasks Count', 'number'], ['Recovered Tasks Count', 'number'], ['Notes', 'text']]);
    var t1avail = mkCols([['Name', 'text'], ['Status', 'text'], ['Note', 'text']]);
    var t1tna = mkCols([['Name', 'text'], ['Training / Need', 'text'], ['Status', 'text'], ['Notes', 'text']]);
    var team1 = [
      S('summary', 'summary', 'Weekly Summary', "One-line status for the week"),
      S('list', 'team-notes', 'Team Notes', '', { tone: 'neutral' }),
      S('weekday', 'daily-tasks', 'Daily Tasks', 'Logged by weekday · Sun–Sat'),
      S('list', 'team-concerns', 'Team Concerns', '', { tone: 'warn' }),
      S('table', 'machines-activity', 'Systems / Machines Activity', '', { columns: t1machines, autoStatus: { activeKey: keyOf(t1machines, 'Machines Active'), inactiveKey: keyOf(t1machines, 'Machines Inactive') } }),
      S('table', 'tasks-received', 'Tasks Received This Week', '', { columns: t1tasks, chart: { title: 'Tasks received vs recovered', labelKey: keyOf(t1tasks, 'Case Name'), series: [{ key: keyOf(t1tasks, 'Total Received'), label: 'Received', color: 'var(--accent)' }, { key: keyOf(t1tasks, 'Total Recovered'), label: 'Recovered', color: 'var(--good)' }] } }),
      S('list', 'ongoing-tasks', 'Ongoing Tasks', '', { tone: 'neutral' }),
      S('list', 'urgent-tasks', 'Urgent Tasks', '', { tone: 'danger' }),
      S('list', 'recovered-systems', 'Recovered Systems', '', { tone: 'neutral' }),
      S('table', 'systems-outcomes', 'Systems Outcomes', '', { columns: t1outcomes }),
      S('table', 'jira-inputs', 'Jira Inputs / Range Data', '', { columns: t1jira, chart: { title: 'Jira — total vs recovered', labelKey: keyOf(t1jira, 'From Date'), series: [{ key: keyOf(t1jira, 'Total Tasks Count'), label: 'Total', color: 'var(--accent)' }, { key: keyOf(t1jira, 'Recovered Tasks Count'), label: 'Recovered', color: 'var(--good)' }] } }),
      S('table', 'availability', 'People Availability / Absence', '', { columns: t1avail, availability: true }),
      S('table', 'tna', 'TNA', '', { columns: t1tna, tna: true }),
      S('personnel', 'personnel', 'Personnel', '')
    ];

    var t2req = mkCols([['Task Name', 'text'], ['Start Date', 'date'], ['End Date', 'date'], ['Ref Number', 'text'], ['Requested From', 'text'], ['Input 1', 'text'], ['Input 2', 'text']]);
    var t2stat = mkCols([['Period', 'text'], ['Input 1 Received', 'number'], ['Input 1 Analyzed', 'number'], ['Input 2 Received', 'number'], ['Input 2 Analyzed', 'number']]);
    var t2res = mkCols([['Module / Model Name', 'text'], ['Result Value', 'number']]);
    var t2sys = mkCols([['System Name', 'text'], ['Count', 'number']]);
    var t2int = mkCols([['Task Name', 'text'], ['Tool Used', 'text'], ['Total', 'number'], ['Comments', 'text']]);
    var t2avail = mkCols([['Name', 'text'], ['Status', 'text'], ['Note', 'text']]);
    var t2tna = mkCols([['Name', 'text'], ['Training / Need', 'text'], ['Status', 'text'], ['Notes', 'text']]);
    var team2 = [
      S('summary', 'summary', 'Weekly Summary', 'One-line status for the week'),
      S('list', 'team-notes', 'Team Notes', '', { tone: 'neutral' }),
      S('weekday', 'daily-tasks', 'Daily Tasks', 'Logged by weekday · Sun–Sat'),
      S('table', 'requested-tasks', 'Requested Tasks', '', { columns: t2req }),
      S('table', 'statistics', 'Statistics', '', { columns: t2stat, chart: { title: 'Received vs analyzed by period', labelKey: keyOf(t2stat, 'Period'), series: [{ key: keyOf(t2stat, 'Input 1 Received'), label: 'In1 Received', color: 'var(--accent)' }, { key: keyOf(t2stat, 'Input 1 Analyzed'), label: 'In1 Analyzed', color: 'var(--accent-2)' }, { key: keyOf(t2stat, 'Input 2 Received'), label: 'In2 Received', color: 'var(--warn)' }, { key: keyOf(t2stat, 'Input 2 Analyzed'), label: 'In2 Analyzed', color: 'var(--good)' }] } }),
      S('table', 'results', 'Results', '', { columns: t2res, chart: { title: 'Result value by module', horizontal: true, labelKey: keyOf(t2res, 'Module / Model Name'), series: [{ key: keyOf(t2res, 'Result Value'), label: 'Result', color: 'var(--accent)' }] } }),
      S('table', 'system-graph', 'System Graph', '', { columns: t2sys, chart: { title: 'Count by system', horizontal: true, labelKey: keyOf(t2sys, 'System Name'), series: [{ key: keyOf(t2sys, 'Count'), label: 'Count', color: 'var(--accent-2)' }] } }),
      S('table', 'internal-tasks', 'Internal Tasks', '', { columns: t2int }),
      S('table', 'availability', 'People Availability / Absence', '', { columns: t2avail, availability: true }),
      S('table', 'tna', 'TNA', '', { columns: t2tna, tna: true }),
      S('personnel', 'personnel', 'Personnel', '')
    ];

    var g1 = uid(), g2 = uid();
    var t3log = mkCols([['Name #', 'text'], ['Description', 'text'], ['Status', 'text'], ['Name', 'text']]);
    var t3avail = mkCols([['Name', 'text'], ['Status', 'text'], ['Note', 'text']]);
    var t3tna = mkCols([['Name', 'text'], ['Training / Need', 'text'], ['Status', 'text'], ['Notes', 'text']]);
    var team3 = [
      S('summary', 'summary', 'Weekly Summary', 'One-line status for the week'),
      S('list', 'team-notes', 'Team Notes', '', { tone: 'neutral' }),
      S('list', 'daily-inputs', 'Daily Inputs', 'Routine operational input · add / edit / delete', { tone: 'neutral' }),
      S('ops', 'operations-status', 'Operations Status', 'Green / Yellow / Red per item', { groups: [{ id: g1, name: 'Status Group A' }, { id: g2, name: 'Status Group B' }] }),
      S('table', 'log', 'Log', '', { columns: t3log }),
      S('list', 'maintenance', 'Maintenance', 'Add / edit / delete maintenance entries', { tone: 'neutral' }),
      S('table', 'availability', 'People Availability / Absence', '', { columns: t3avail, availability: true }),
      S('table', 'tna', 'TNA', '', { columns: t3tna, tna: true }),
      S('personnel', 'personnel', 'Personnel', '')
    ];

    return { team1: team1, team2: team2, team3: team3 };
  }

  function defaultMembers() {
    function m(name, role, status) { return { id: uid(), name: name, role: role, status: status }; }
    return {
      team1: [m('M. Chen', 'Shift Lead', 'Available'), m('S. Patel', 'Analyst', 'On-call'), m('J. Kim', 'Analyst', 'Leave')],
      team2: [m('L. Diaz', 'Analysis Lead', 'Available'), m('R. Osei', 'Reverse Engineer', 'Leave')],
      team3: [m('A. Rao', 'Ops Lead', 'Available'), m('T. Novak', 'Engineer', 'On-call'), m('K. Ali', 'Engineer', 'Available')]
    };
  }

  function emptySecData(def) {
    if (def.type === 'summary') return { text: '' };
    if (def.type === 'list') return { items: [] };
    if (def.type === 'weekday') return { entries: [] };
    if (def.type === 'table') return { rows: [] };
    if (def.type === 'ops') return { rows: {} };
    return {};
  }
  function ensureWeek(data, wk) {
    if (!data.weeks[wk]) data.weeks[wk] = { teams: { team1: { sec: {} }, team2: { sec: {} }, team3: { sec: {} } } };
    var w = data.weeks[wk];
    ['team1', 'team2', 'team3'].forEach(function (tk) {
      if (!w.teams[tk]) w.teams[tk] = { sec: {} };
      if (!w.teams[tk].sec) w.teams[tk].sec = {};
      (data.global.sections[tk] || []).forEach(function (def) {
        if (def.type === 'personnel') return;
        if (!w.teams[tk].sec[def.sid]) w.teams[tk].sec[def.sid] = emptySecData(def);
      });
    });
    return w;
  }

  function addSampleRow(data, wk, tk, sid, obj) {
    var def = data.global.sections[tk].filter(function (s) { return s.sid === sid; })[0];
    var row = { id: uid() };
    Object.keys(obj).forEach(function (label) { var c = def.columns.filter(function (x) { return x.label === label; })[0]; if (c) row[c.key] = obj[label]; });
    data.weeks[wk].teams[tk].sec[sid].rows.push(row);
  }
  function setList(data, wk, tk, sid, arr) { data.weeks[wk].teams[tk].sec[sid].items = arr.map(function (t) { return { id: uid(), text: t }; }); }
  function setSummary(data, wk, tk, sid, t) { data.weeks[wk].teams[tk].sec[sid].text = t; }
  function addWeekdayEntry(data, wk, tk, sid, day, text) { data.weeks[wk].teams[tk].sec[sid].entries.push({ id: uid(), day: day, text: text }); }

  function seedSamples(data, wk) {
    function A(n) { return addDays(wk, n); }
    setSummary(data, wk, 'team1', 'summary', 'Tier-1 monitoring steady; 2 critical cases recovered, 1 firmware patch pending.');
    setList(data, wk, 'team1', 'team-notes', ['On-call rota updated for the weekend.']);
    addWeekdayEntry(data, wk, 'team1', 'daily-tasks', 'Mon', 'Triaged overnight EDR alerts — 3 escalations.');
    addWeekdayEntry(data, wk, 'team1', 'daily-tasks', 'Wed', 'Closed phishing case RQ-4473.');
    setList(data, wk, 'team1', 'team-concerns', ['Escalation SLA for critical alerts breached twice this week.']);
    addSampleRow(data, wk, 'team1', 'machines-activity', { 'System Name': 'EDR Cluster', 'Description': 'Endpoint sensors', 'Machines Active': 120, 'Machines Inactive': 3 });
    addSampleRow(data, wk, 'team1', 'machines-activity', { 'System Name': 'Firewall Pair', 'Description': 'Perimeter gateways', 'Machines Active': 2, 'Machines Inactive': 0 });
    addSampleRow(data, wk, 'team1', 'machines-activity', { 'System Name': 'SIEM Node', 'Description': 'Log ingest', 'Machines Active': 0, 'Machines Inactive': 1 });
    addSampleRow(data, wk, 'team1', 'tasks-received', { 'Date': A(0), 'Ref Number': 'RQ-4471', 'Case Name': 'Credential dumping HR-07', 'Total Received': 22, 'Total Recovered': 18, 'Complexity': 'High', 'Urgent': 'Yes', 'Saif.Created': 'Yes', 'Progress %': 80, 'Result Progress %': 70 });
    addSampleRow(data, wk, 'team1', 'tasks-received', { 'Date': A(1), 'Ref Number': 'RQ-4473', 'Case Name': 'Phishing wave', 'Total Received': 27, 'Total Recovered': 27, 'Complexity': 'Medium', 'Urgent': 'No', 'Saif.Created': 'Yes', 'Progress %': 100, 'Result Progress %': 100 });
    addSampleRow(data, wk, 'team1', 'tasks-received', { 'Date': A(2), 'Ref Number': 'RQ-4479', 'Case Name': 'Impossible travel', 'Total Received': 9, 'Total Recovered': 4, 'Complexity': 'Low', 'Urgent': 'No', 'Saif.Created': 'No', 'Progress %': 45, 'Result Progress %': 30 });
    setList(data, wk, 'team1', 'ongoing-tasks', ['RQ-4479 impossible-travel investigation', 'Perimeter firewall rule review']);
    setList(data, wk, 'team1', 'urgent-tasks', ['RQ-4471 credential-dumping containment on HR-07']);
    setList(data, wk, 'team1', 'recovered-systems', ['HR-07 endpoint', 'Mail gateway ruleset']);
    addSampleRow(data, wk, 'team1', 'systems-outcomes', { 'System Name': 'HR-07 Endpoint', 'Status Line': 'Contained & cleaned', 'Active Tasks': 1, 'Pending': 0, 'Completed': 3 });
    addSampleRow(data, wk, 'team1', 'systems-outcomes', { 'System Name': 'Perimeter FW', 'Status Line': 'Monitoring', 'Active Tasks': 2, 'Pending': 1, 'Completed': 1 });
    addSampleRow(data, wk, 'team1', 'jira-inputs', { 'From Date': A(-7), 'To Date': A(-1), 'Total Tasks Count': 48, 'Recovered Tasks Count': 40, 'Notes': 'Sprint 21' });
    addSampleRow(data, wk, 'team1', 'jira-inputs', { 'From Date': A(0), 'To Date': A(6), 'Total Tasks Count': 52, 'Recovered Tasks Count': 33, 'Notes': 'Sprint 22' });
    addSampleRow(data, wk, 'team1', 'availability', { 'Name': 'J. Kim', 'Status': 'Sick leave', 'Note': 'Back Wednesday' });
    addSampleRow(data, wk, 'team1', 'availability', { 'Name': 'M. Chen', 'Status': 'Available', 'Note': '' });
    addSampleRow(data, wk, 'team1', 'tna', { 'Name': 'S. Patel', 'Training / Need': 'Malware analysis', 'Status': 'Scheduled', 'Notes': 'August cohort' });

    setSummary(data, wk, 'team2', 'summary', 'Two feeds fully analyzed; model results within target range.');
    setList(data, wk, 'team2', 'team-notes', ['Sandbox B capacity increased.']);
    addWeekdayEntry(data, wk, 'team2', 'daily-tasks', 'Tue', 'Analyzed ransomware sample AN-771.');
    addSampleRow(data, wk, 'team2', 'requested-tasks', { 'Task Name': 'Analyze ransomware sample', 'Start Date': A(0), 'End Date': A(3), 'Ref Number': 'AN-771', 'Requested From': 'IR Team', 'Input 1': 'Binary sample', 'Input 2': 'Memory dump' });
    addSampleRow(data, wk, 'team2', 'statistics', { 'Period': 'Week 27', 'Input 1 Received': 540, 'Input 1 Analyzed': 512, 'Input 2 Received': 210, 'Input 2 Analyzed': 180 });
    addSampleRow(data, wk, 'team2', 'statistics', { 'Period': 'Week 26', 'Input 1 Received': 480, 'Input 1 Analyzed': 470, 'Input 2 Received': 190, 'Input 2 Analyzed': 175 });
    addSampleRow(data, wk, 'team2', 'results', { 'Module / Model Name': 'Static classifier', 'Result Value': 88 });
    addSampleRow(data, wk, 'team2', 'results', { 'Module / Model Name': 'Behavioral engine', 'Result Value': 73 });
    addSampleRow(data, wk, 'team2', 'results', { 'Module / Model Name': 'YARA ruleset match', 'Result Value': 64 });
    addSampleRow(data, wk, 'team2', 'system-graph', { 'System Name': 'Sandbox A', 'Count': 120 });
    addSampleRow(data, wk, 'team2', 'system-graph', { 'System Name': 'Sandbox B', 'Count': 64 });
    addSampleRow(data, wk, 'team2', 'system-graph', { 'System Name': 'Threat DB', 'Count': 210 });
    addSampleRow(data, wk, 'team2', 'internal-tasks', { 'Task Name': 'Update YARA rules', 'Tool Used': 'CyberChef', 'Total': 12, 'Comments': 'Merged to main' });
    addSampleRow(data, wk, 'team2', 'availability', { 'Name': 'R. Osei', 'Status': 'Vacation', 'Note': 'Until Monday' });
    addSampleRow(data, wk, 'team2', 'tna', { 'Name': 'L. Diaz', 'Training / Need': 'Reverse engineering', 'Status': 'In progress', 'Notes': '' });

    setSummary(data, wk, 'team3', 'summary', 'Routine ops nominal; one maintenance window completed.');
    setList(data, wk, 'team3', 'team-notes', ['Shift handover notes updated.']);
    setList(data, wk, 'team3', 'daily-inputs', ['Reviewed overnight SIEM queue — 3 escalations to Tier-2.', 'Verified backup integrity for HR file server.']);
    var ops = data.global.sections.team3.filter(function (s) { return s.sid === 'operations-status'; })[0];
    var opsData = data.weeks[wk].teams.team3.sec['operations-status'];
    opsData.rows[ops.groups[0].id] = [{ id: uid(), name: 'VPN Gateway', status: 'green' }, { id: uid(), name: 'Mail Relay', status: 'yellow' }];
    opsData.rows[ops.groups[1].id] = [{ id: uid(), name: 'Backup Job', status: 'green' }, { id: uid(), name: 'AV Console', status: 'red' }];
    addSampleRow(data, wk, 'team3', 'log', { 'Name #': 'LOG-001', 'Description': 'Restarted mail relay service', 'Status': 'Done', 'Name': 'T. Novak' });
    addSampleRow(data, wk, 'team3', 'log', { 'Name #': 'LOG-002', 'Description': 'Patched AV console', 'Status': 'Pending', 'Name': 'K. Ali' });
    setList(data, wk, 'team3', 'maintenance', ['Scheduled firmware update for VPN-GW — Saturday 02:00.']);
    addSampleRow(data, wk, 'team3', 'availability', { 'Name': 'A. Rao', 'Status': 'Day off', 'Note': '' });
    addSampleRow(data, wk, 'team3', 'tna', { 'Name': 'K. Ali', 'Training / Need': 'Forensics 201', 'Status': 'Planned', 'Notes': '' });
  }

  function seed() {
    var thisWeek = mondayISO(new Date());
    var lastWeek = addDays(thisWeek, -7);
    var data = {
      currentWeek: thisWeek,
      global: {
        orgName: 'Nightwatch SOC',
        teamNames: { team1: 'Team 1 — Operations', team2: 'Team 2 — Analysis', team3: 'Team 3 — Response' },
        sections: buildSections(),
        members: defaultMembers()
      },
      weeks: {},
      meta: { lastSync: Date.now(), queued: 0 }
    };
    ensureWeek(data, lastWeek);
    ensureWeek(data, thisWeek);
    seedSamples(data, thisWeek);
    return data;
  }

  function migrate(data) {
    if (!data.global) data.global = {};
    if (!data.global.sections) data.global.sections = buildSections();
    if (!data.global.members) data.global.members = defaultMembers();
    if (!data.global.teamNames) data.global.teamNames = { team1: 'Team 1', team2: 'Team 2', team3: 'Team 3' };
    if (!data.global.orgName) data.global.orgName = 'Operations';
    if (!data.weeks) data.weeks = {};
    if (!data.meta) data.meta = { lastSync: Date.now(), queued: 0 };
    if (!data.currentWeek) data.currentWeek = mondayISO(new Date());
    Object.keys(data.weeks).forEach(function (wk) { ensureWeek(data, wk); });
    ensureWeek(data, data.currentWeek);
    return data;
  }

  // ---------------- online / sync ----------------
  function effOnline() { return state.online && !state.forcedOffline; }
  function cur() { var d = state.data; return d.weeks[d.currentWeek]; }
  function sd(data, tk, sid) { return data.weeks[data.currentWeek].teams[tk].sec[sid]; }
  function colDef(data, tk, sid, cid) { var s = data.global.sections[tk].filter(function (x) { return x.sid === sid; })[0]; return s.columns.filter(function (c) { return c.id === cid; })[0]; }

  function mutate(fn) {
    var data = JSON.parse(JSON.stringify(state.data));
    fn(data);
    if (effOnline()) { data.meta.lastSync = Date.now(); data.meta.queued = 0; }
    else { data.meta.queued = (data.meta.queued || 0) + 1; }
    state.data = data;
    persist(data);
    render();
  }
  function editModel(fn) { fn(state.data); schedulePersist(); }
  function commit() {
    clearTimeout(pendingPersist);
    var d = state.data;
    if (effOnline()) { d.meta.lastSync = Date.now(); d.meta.queued = 0; }
    else { d.meta.queued = (d.meta.queued || 0) + 1; }
    persist(d);
    patchStatus();
  }
  function handleConn(isOnline) { state.online = isOnline; if (effOnline()) flush(); else render(); }
  function flush() { var d = JSON.parse(JSON.stringify(state.data)); d.meta.queued = 0; d.meta.lastSync = Date.now(); state.data = d; persist(d); render(); }
  function toggleOffline() { state.forcedOffline = !state.forcedOffline; if (effOnline()) flush(); else render(); }

  function weekNav(delta) { mutate(function (d) { var wk = addDays(d.currentWeek, delta * 7); ensureWeek(d, wk); d.currentWeek = wk; }); }
  function toggleSidebar() { state.sidebarCollapsed = !state.sidebarCollapsed; render(); }
  function toggleCollapse(id) { state.collapsed[id] = !state.collapsed[id]; render(); }
  function setView(view, team) { state.view = view; if (team) state.team = team; render(); }

  // ---- edit ops ----
  function editOrg(val) { editModel(function (d) { d.global.orgName = val; }); }
  function editTeamName(tk, val) { editModel(function (d) { d.global.teamNames[tk] = val; }); }
  function editSummary(tk, sid, val) { editModel(function (d) { sd(d, tk, sid).text = val; }); }

  function addListItem(tk, sid) { mutate(function (d) { sd(d, tk, sid).items.push({ id: uid(), text: '' }); }); }
  function editListItem(tk, sid, id, val) { editModel(function (d) { var it = sd(d, tk, sid).items.filter(function (x) { return x.id === id; })[0]; if (it) it.text = val; }); }
  function delListItem(tk, sid, id) { mutate(function (d) { var s = sd(d, tk, sid); s.items = s.items.filter(function (x) { return x.id !== id; }); }); }

  function addWeekday(tk, sid, day) { mutate(function (d) { sd(d, tk, sid).entries.push({ id: uid(), day: day, text: '' }); }); }
  function editWeekday(tk, sid, id, val) { editModel(function (d) { var e = sd(d, tk, sid).entries.filter(function (x) { return x.id === id; })[0]; if (e) e.text = val; }); }
  function delWeekday(tk, sid, id) { mutate(function (d) { var s = sd(d, tk, sid); s.entries = s.entries.filter(function (x) { return x.id !== id; }); }); }

  function addRow(tk, sid) { mutate(function (d) { sd(d, tk, sid).rows.push({ id: uid() }); }); }
  function editCell(tk, sid, rid, key, val) { editModel(function (d) { var r = sd(d, tk, sid).rows.filter(function (x) { return x.id === rid; })[0]; if (r) r[key] = val; }); }
  function delRow(tk, sid, rid) { mutate(function (d) { var s = sd(d, tk, sid); s.rows = s.rows.filter(function (x) { return x.id !== rid; }); }); }
  function addColumn(tk, sid) { mutate(function (d) { var s = d.global.sections[tk].filter(function (x) { return x.sid === sid; })[0]; s.columns.push({ id: uid(), key: 'c_' + uid(), label: 'New Column', type: 'text', fixed: false }); }); }
  function editColLabel(tk, sid, cid, val) { editModel(function (d) { var c = colDef(d, tk, sid, cid); if (c) c.label = val; }); }
  function cycleType(tk, sid, cid) { mutate(function (d) { var c = colDef(d, tk, sid, cid); if (!c || c.fixed) return; c.type = c.type === 'text' ? 'number' : c.type === 'number' ? 'date' : 'text'; }); }
  function delCol(tk, sid, cid) { mutate(function (d) { var s = d.global.sections[tk].filter(function (x) { return x.sid === sid; })[0]; var c = s.columns.filter(function (x) { return x.id === cid; })[0]; if (!c || c.fixed) return; s.columns = s.columns.filter(function (x) { return x.id !== cid; }); }); }

  function opsAddRow(tk, sid, gid) { mutate(function (d) { var s = sd(d, tk, sid); if (!s.rows[gid]) s.rows[gid] = []; s.rows[gid].push({ id: uid(), name: '', status: 'green' }); }); }
  function opsEditName(tk, sid, gid, rid, val) { editModel(function (d) { var arr = sd(d, tk, sid).rows[gid] || []; var r = arr.filter(function (x) { return x.id === rid; })[0]; if (r) r.name = val; }); }
  function opsSetStatus(tk, sid, gid, rid, st) { mutate(function (d) { var arr = sd(d, tk, sid).rows[gid] || []; var r = arr.filter(function (x) { return x.id === rid; })[0]; if (r) r.status = st; }); }
  function opsDelRow(tk, sid, gid, rid) { mutate(function (d) { var s = sd(d, tk, sid); s.rows[gid] = (s.rows[gid] || []).filter(function (x) { return x.id !== rid; }); }); }
  function opsRenameGroup(tk, sid, gid, val) { editModel(function (d) { var s = d.global.sections[tk].filter(function (x) { return x.sid === sid; })[0]; var g = s.groups.filter(function (x) { return x.id === gid; })[0]; if (g) g.name = val; }); }

  function addMember(tk) { mutate(function (d) { if (!d.global.members) d.global.members = { team1: [], team2: [], team3: [] }; d.global.members[tk].push({ id: uid(), name: '', role: '', status: 'Available' }); }); }
  function editMember(tk, id, field, val) { editModel(function (d) { var m = d.global.members[tk].filter(function (x) { return x.id === id; })[0]; if (m) m[field] = val; }); }
  function cycleMemberStatus(tk, id) { mutate(function (d) { var m = d.global.members[tk].filter(function (x) { return x.id === id; })[0]; if (!m) return; var i = STATUSES.indexOf(m.status); m.status = STATUSES[(i + 1) % STATUSES.length]; }); }
  function delMember(tk, id) { mutate(function (d) { d.global.members[tk] = d.global.members[tk].filter(function (x) { return x.id !== id; }); }); }

  // ---------------- exports ----------------
  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a'); a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }
  function doExportJSON() {
    var data = state.data;
    var stamp = new Date().toISOString().slice(0, 10);
    var safe = String(data.global.orgName || 'soc').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    download(blob, safe + '-console-' + stamp + '.json');
  }
  function doExportWord() {
    var d = state.data, wk = cur(), names = d.global.teamNames, sections = d.global.sections;
    var body = '<h1>' + esc(d.global.orgName) + ' — Weekly Operations Report</h1><p>Week of ' + esc(weekLabel()) + '</p>';
    ['team1', 'team2', 'team3'].forEach(function (tk) {
      body += '<h2>' + esc(names[tk]) + '</h2>';
      sections[tk].forEach(function (def) {
        var data = wk.teams[tk].sec[def.sid];
        body += '<h3>' + esc(def.title) + '</h3>';
        if (def.type === 'summary') { body += '<p>' + esc(data && data.text) + '</p>'; }
        else if (def.type === 'list') { var items = (data && data.items || []).filter(function (x) { return x.text; }); body += items.length ? '<ul>' + items.map(function (x) { return '<li>' + esc(x.text) + '</li>'; }).join('') + '</ul>' : '<p><i>None</i></p>'; }
        else if (def.type === 'weekday') { var ents = (data && data.entries || []).filter(function (x) { return x.text; }); body += ents.length ? '<ul>' + ents.map(function (x) { return '<li><b>' + esc(x.day) + ':</b> ' + esc(x.text) + '</li>'; }).join('') + '</ul>' : '<p><i>None</i></p>'; }
        else if (def.type === 'table') {
          var rows = (data && data.rows) || [];
          body += '<table border="1" cellspacing="0" cellpadding="5" style="border-collapse:collapse;width:100%"><tr>' + def.columns.map(function (c) { return '<th align="left">' + esc(c.label) + '</th>'; }).join('') + (def.autoStatus ? '<th align="left">Status</th>' : '') + '</tr>';
          rows.forEach(function (row) {
            body += '<tr>' + def.columns.map(function (c) { return '<td>' + esc(row[c.key]) + '</td>'; }).join('');
            if (def.autoStatus) { var a = num(row[def.autoStatus.activeKey]), i = num(row[def.autoStatus.inactiveKey]); body += '<td>' + ((a === 0 && i === 0) ? '—' : i === 0 ? 'Operational' : a === 0 ? 'Down' : 'Degraded') + '</td>'; }
            body += '</tr>';
          });
          body += '</table>';
        }
        else if (def.type === 'ops') {
          def.groups.forEach(function (g) { var arr = (data && data.rows && data.rows[g.id]) || []; body += '<p><b>' + esc(g.name) + '</b></p>'; body += arr.length ? '<ul>' + arr.map(function (r) { return '<li>' + esc(r.name) + ' — ' + esc((r.status || '').toUpperCase()) + '</li>'; }).join('') + '</ul>' : '<p><i>None</i></p>'; });
        }
        else if (def.type === 'personnel') { var mem = d.global.members[tk] || []; body += mem.length ? '<ul>' + mem.map(function (m) { return '<li>' + esc(m.name) + ' — ' + esc(m.role) + ' (' + esc(m.status) + ')</li>'; }).join('') + '</ul>' : '<p><i>None</i></p>'; }
      });
    });
    var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><style>body{font-family:Calibri,Arial,sans-serif;color:#111}h1{font-size:20pt}h2{font-size:15pt;border-bottom:1px solid #999;margin-top:22px}h3{font-size:12pt;color:#333;margin-bottom:4px}th{background:#eee}</style></head><body>' + body + '</body></html>';
    var stamp = new Date().toISOString().slice(0, 10);
    var safe = String(d.global.orgName || 'soc').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    download(new Blob(['\ufeff' + html], { type: 'application/msword' }), safe + '-report-' + stamp + '.doc');
  }
  function importClick() { fileInput.click(); }
  function doImport(e) {
    var f = e.target.files && e.target.files[0]; if (!f) return;
    var reader = new FileReader();
    reader.onload = function () {
      try { var p = JSON.parse(reader.result); if (!p.weeks || !p.global) throw 0; var m = migrate(p); state.data = m; persist(m); render(); }
      catch (err) { alert('Import failed: not a valid console export.'); }
    };
    reader.readAsText(f); e.target.value = '';
  }

  // ---------------- derived / health ----------------
  function teamHealth(tk) {
    var week = cur(); var secs = state.data.global.sections[tk]; var bad = 0, warn = 0, items = 0;
    secs.forEach(function (def) {
      var data = week.teams[tk] && week.teams[tk].sec[def.sid]; if (!data) return;
      if (def.type === 'table') { (data.rows || []).forEach(function (r) { items++; var b = Object.values(r).join(' ').toLowerCase(); if (/critical|urgent|down|breach|fail/.test(b)) bad++; else if (/pending|open|progress|investigat|degrad|backlog/.test(b)) warn++; }); }
      if (def.type === 'list' && def.tone === 'danger') { (data.items || []).forEach(function (it) { if (it.text) bad++; }); }
      if (def.type === 'ops') { Object.values(data.rows || {}).forEach(function (arr) { arr.forEach(function (r) { if (r.status === 'red') bad++; else if (r.status === 'yellow') warn++; }); }); }
    });
    if (bad > 0) return { cls: 'bad', label: 'ELEVATED', detail: bad + ' critical/urgent · ' + warn + ' active' };
    if (warn > 0) return { cls: 'warn', label: 'ACTIVE', detail: warn + ' in progress' };
    return { cls: 'good', label: 'STEADY', detail: items + ' records tracked' };
  }
  function weekLabel() { var s = state.data.currentWeek, e = addDays(s, 6); function f(iso) { return new Date(iso + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); } return f(s) + ' – ' + f(e); }
  function opsBtnStyle(active, color) { return 'width:30px; height:26px; border-radius:7px; cursor:pointer; font-size:11px; font-weight:700; font-family:var(--mono); border:1.5px solid ' + color + '; color:' + (active ? 'var(--bg)' : color) + '; background:' + (active ? color : 'transparent') + ';'; }
  function cc(id, defaultOpen) {
    var collapsed = state.collapsed[id];
    var open = collapsed === undefined ? (defaultOpen !== false) : !collapsed;
    return { open: open, chevron: open ? '▾' : '▸' };
  }
  function buildChart(cfg, rows) {
    var series = cfg.series, legend = series.map(function (s) { return { label: s.label, color: s.color }; });
    var max = 1; rows.forEach(function (r) { series.forEach(function (s) { max = Math.max(max, num(r[s.key])); }); });
    if (cfg.horizontal) {
      var s0 = series[0];
      var bars = rows.map(function (r) { return { label: String(r[cfg.labelKey] || '—'), val: num(r[s0.key]), h: Math.round(num(r[s0.key]) / max * 100), color: s0.color }; });
      return { bars: bars, legend: legend, hasLegend: false, horizontal: true };
    }
    var bars2 = rows.map(function (r) { return { label: String(r[cfg.labelKey] || '—'), groups: series.map(function (s) { return { val: num(r[s.key]), h: Math.round(num(r[s.key]) / max * 100), color: s.color }; }) }; });
    return { bars: bars2, legend: legend, hasLegend: series.length > 1, horizontal: false };
  }

  // ---------------- render helpers ----------------
  function actAttr(fn, args) { return "data-act='" + esc(JSON.stringify({ fn: fn, args: args || [] })) + "'"; }
  function bindAttr(fn, args) { return "data-bind='" + esc(JSON.stringify({ fn: fn, args: args || [] })) + "'"; }

  function renderStatusBadge(compact) {
    var d = state.data, on = effOnline(), queued = d.meta.queued || 0;
    var status = on
      ? { border: 'rgba(52,211,153,.34)', bg: 'rgba(52,211,153,.07)', dot: 'var(--good)', fg: 'var(--good)', anim: 'none', label: 'ONLINE', short: 'SYNCED', sub: 'Synced ' + relTime(d.meta.lastSync) }
      : { border: 'rgba(251,191,36,.34)', bg: 'rgba(251,191,36,.07)', dot: 'var(--warn)', fg: 'var(--warn)', anim: 'soc-pulse 1.6s ease-in-out infinite', label: 'OFFLINE', short: 'OFFLINE', sub: queued ? queued + ' queued' : 'Local data' };
    var html = '<div id="statusBadge" style="display:flex; align-items:center; gap:7px; padding:7px 10px; border:1px solid ' + status.border + '; border-radius:10px; background:' + status.bg + ';">' +
      '<span style="width:7px; height:7px; border-radius:99px; background:' + status.dot + '; animation:' + status.anim + ';"></span>' +
      '<span style="font-family:var(--mono); font-size:10.5px; font-weight:600; letter-spacing:.05em; color:' + status.fg + '; white-space:nowrap;">' + status.short + '</span>';
    if (!on && queued > 0) html += '<button ' + actAttr('flush') + ' title="Retry sync now" style="margin-left:2px; padding:3px 7px; border-radius:6px; border:1px solid var(--warn); background:transparent; color:var(--warn); font-family:var(--mono); font-size:10px; font-weight:600; cursor:pointer;">↑ ' + queued + '</button>';
    html += '</div>';
    return html;
  }
  function sidebarStatusHtml() {
    var d = state.data, on = effOnline();
    var status = on
      ? { border: 'rgba(52,211,153,.34)', bg: 'rgba(52,211,153,.07)', dot: 'var(--good)', fg: 'var(--good)', anim: 'none', label: 'ONLINE', sub: 'Synced ' + relTime(d.meta.lastSync) }
      : { border: 'rgba(251,191,36,.34)', bg: 'rgba(251,191,36,.07)', dot: 'var(--warn)', fg: 'var(--warn)', anim: 'soc-pulse 1.6s ease-in-out infinite', label: 'OFFLINE', sub: (d.meta.queued ? d.meta.queued + ' queued' : 'Local data') };
    var labelDisplay = state.sidebarCollapsed ? 'none' : 'block';
    return '<div id="sidebarStatus" style="display:flex; align-items:center; gap:9px; padding:10px; border:1px solid ' + status.border + '; border-radius:10px; background:' + status.bg + ';">' +
      '<span style="flex:0 0 auto; width:8px; height:8px; border-radius:99px; background:' + status.dot + '; animation:' + status.anim + ';"></span>' +
      '<div style="min-width:0; display:' + labelDisplay + '; line-height:1.25;">' +
      '<div style="font-family:var(--mono); font-size:10px; font-weight:600; letter-spacing:.06em; color:' + status.fg + '; white-space:nowrap;">' + status.label + '</div>' +
      '<div style="font-size:10px; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(status.sub) + '</div>' +
      '</div></div>';
  }

  function renderSidebar() {
    var d = state.data;
    var sidebarW = state.sidebarCollapsed ? '64px' : '234px';
    var labelDisplay = state.sidebarCollapsed ? 'none' : 'block';
    var tabs = [{ key: 'overview', label: 'Overview', icon: '◆' }, { key: 'team1', label: d.global.teamNames.team1, icon: 'T1' }, { key: 'team2', label: d.global.teamNames.team2, icon: 'T2' }, { key: 'team3', label: d.global.teamNames.team3, icon: 'T3' }];
    var nav = tabs.map(function (t) {
      var active = (t.key === 'overview' && state.view === 'overview') || (t.key === state.team && state.view === 'team');
      var dot = t.key === 'overview' ? 'var(--accent)' : colorFor(teamHealth(t.key).cls);
      var style = 'display:flex; align-items:center; gap:10px; width:100%; padding:8px; border-radius:9px; cursor:pointer; font-size:13px; font-weight:500; border:none; background:' + (active ? 'var(--accent-soft)' : 'transparent') + '; color:' + (active ? 'var(--text)' : 'var(--muted)') + ';';
      var args = t.key === 'overview' ? ['overview', null] : ['team', t.key];
      return '<button ' + actAttr('setView', args) + ' title="' + esc(t.label) + '" style="' + style + '">' +
        '<span style="flex:0 0 auto; width:24px; height:24px; border-radius:7px; display:grid; place-items:center; font-family:var(--mono); font-size:10px; font-weight:600; background:' + (active ? 'var(--accent)' : 'var(--panel-2)') + '; color:' + (active ? 'var(--on-accent)' : 'var(--muted)') + ';">' + t.icon + '</span>' +
        '<span style="display:' + labelDisplay + '; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; flex:1; text-align:left;">' + esc(t.label) + '</span>' +
        '<span style="display:' + labelDisplay + '; flex:0 0 auto; width:7px; height:7px; border-radius:99px; background:' + dot + ';"></span>' +
        '</button>';
    }).join('');
    return '<aside style="flex:0 0 auto; width:' + sidebarW + '; border-right:1px solid var(--border); background:var(--panel-3); position:sticky; top:0; height:100vh; display:flex; flex-direction:column; padding:14px 12px; gap:6px;">' +
      '<div style="display:flex; align-items:center; gap:11px; padding:6px 6px 14px;">' +
      '<div style="flex:0 0 auto; width:34px; height:34px; border-radius:9px; display:grid; place-items:center; background:var(--accent); color:var(--on-accent); font-family:var(--head); font-weight:700; font-size:13px;">SX</div>' +
      '<div style="min-width:0; display:' + labelDisplay + ';">' +
      '<div style="font-family:var(--head); font-weight:600; font-size:14px; letter-spacing:-.01em; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(d.global.orgName) + '</div>' +
      '<div style="font-family:var(--mono); font-size:9px; letter-spacing:.14em; color:var(--faint); text-transform:uppercase; white-space:nowrap;">OPS CONSOLE</div>' +
      '</div></div>' +
      nav +
      '<div style="flex:1;"></div>' +
      sidebarStatusHtml() +
      '<button ' + actAttr('toggleSidebar') + ' style="display:flex; align-items:center; justify-content:center; gap:8px; padding:9px; border-radius:9px; border:1px solid var(--border); background:transparent; color:var(--muted); font-size:12px; cursor:pointer;">' +
      '<span>' + (state.sidebarCollapsed ? '»' : '«') + '</span><span style="display:' + labelDisplay + ';">Collapse</span></button>' +
      '</aside>';
  }

  function renderHeader() {
    var d = state.data;
    var titleHtml;
    if (state.view === 'overview') {
      titleHtml = '<div style="font-family:var(--head); font-size:20px; font-weight:600; letter-spacing:-.02em;">Operations Overview</div>' +
        '<div style="font-size:12px; color:var(--muted); margin-top:1px;">All teams · ' + esc(weekLabel()) + '</div>';
    } else {
      var badgeMap = { team1: 'TEAM 1 · OPERATIONS', team2: 'TEAM 2 · ANALYSIS', team3: 'TEAM 3 · RESPONSE' };
      titleHtml = '<input value="' + esc(d.global.teamNames[state.team]) + '" ' + bindAttr('editTeamName', [state.team]) + ' placeholder="Team name" style="width:100%; max-width:440px; background:transparent; border:1px solid transparent; color:var(--text); font-family:var(--head); font-size:20px; font-weight:600; letter-spacing:-.02em; padding:2px 5px; border-radius:8px;" />' +
        '<div style="font-family:var(--mono); font-size:10px; color:var(--faint); letter-spacing:.12em; margin-top:2px; padding-left:5px;">' + (badgeMap[state.team] || 'TEAM') + ' · ' + esc(weekLabel()) + '</div>';
    }
    return '<header style="position:sticky; top:0; z-index:30; display:flex; align-items:center; gap:14px; flex-wrap:wrap; padding:14px 22px; border-bottom:1px solid var(--border); background:var(--bg);">' +
      '<div style="min-width:0; flex:1 1 240px;">' + titleHtml + '</div>' +
      '<div style="display:flex; align-items:center; gap:4px; padding:4px; border:1px solid var(--border); border-radius:10px; background:var(--panel);">' +
      '<button ' + actAttr('weekNav', [-1]) + ' style="width:30px; height:30px; border-radius:7px; border:none; background:transparent; color:var(--text); cursor:pointer; font-size:15px;">‹</button>' +
      '<div style="text-align:center; min-width:132px; font-family:var(--mono); font-size:12px; font-weight:500;">' + esc(weekLabel()) + '</div>' +
      '<button ' + actAttr('weekNav', [1]) + ' style="width:30px; height:30px; border-radius:7px; border:none; background:transparent; color:var(--text); cursor:pointer; font-size:15px;">›</button>' +
      '</div>' +
      renderStatusBadge() +
      '<div style="display:flex; align-items:center; gap:6px;">' +
      '<button ' + actAttr('toggleOffline') + ' title="Simulate connection drop" style="width:32px; height:32px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--muted); cursor:pointer; font-size:13px;">' + (state.forcedOffline ? '⚡' : '⏻') + '</button>' +
      '<button ' + actAttr('doExportJSON') + ' style="padding:8px 11px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:12px; font-weight:600; cursor:pointer;">JSON</button>' +
      '<button ' + actAttr('doExportWord') + ' style="padding:8px 11px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:12px; font-weight:600; cursor:pointer;">Word</button>' +
      '<button ' + actAttr('importClick') + ' style="padding:8px 11px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:12px; font-weight:600; cursor:pointer;">Import</button>' +
      '</div></header>';
  }

  function bar(pct) { return Math.max(0, Math.min(100, pct)); }

  function renderOverview() {
    var d = state.data, week = cur(), names = d.global.teamNames;
    var teamSummaries = ['team1', 'team2', 'team3'].map(function (tk) { var s = week.teams[tk].sec['summary']; var h = teamHealth(tk); return { name: names[tk], text: (s && s.text) ? s.text : 'No summary yet.', health: h.label, color: colorFor(h.cls), detail: h.detail }; });

    var mainSid = { team1: 'tasks-received', team2: 'requested-tasks', team3: 'log' };
    var compColors = ['var(--accent)', 'var(--accent-2)', 'var(--good)'];
    var comparison = ['team1', 'team2', 'team3'].map(function (tk, i) { var s = week.teams[tk].sec[mainSid[tk]]; return { label: names[tk], val: (s && s.rows) ? s.rows.length : 0, color: compColors[i] }; });
    var compMax = Math.max(1, Math.max.apply(null, comparison.map(function (b) { return b.val; })));
    comparison.forEach(function (b) { b.h = Math.round(b.val / compMax * 100); });

    function sumCol(tk, sid, label) { var def = d.global.sections[tk].filter(function (s) { return s.sid === sid; })[0]; var s = week.teams[tk].sec[sid]; var k = keyOf(def.columns, label); var t = 0; (s ? s.rows : []).forEach(function (r) { t += num(r[k]); }); return t; }
    var jTot = sumCol('team1', 'jira-inputs', 'Total Tasks Count'), jRec = sumCol('team1', 'jira-inputs', 'Recovered Tasks Count');
    var jPct = jTot ? Math.round(jRec / jTot * 100) : 0;
    var jira = { total: jTot, recovered: jRec, pct: jPct, color: jPct >= 75 ? 'var(--good)' : jPct >= 40 ? 'var(--warn)' : 'var(--bad)' };

    var stats = [
      { label: 'In1 received', value: sumCol('team2', 'statistics', 'Input 1 Received'), color: 'var(--accent)' },
      { label: 'In1 analyzed', value: sumCol('team2', 'statistics', 'Input 1 Analyzed'), color: 'var(--accent-2)' },
      { label: 'In2 received', value: sumCol('team2', 'statistics', 'Input 2 Received'), color: 'var(--warn)' },
      { label: 'In2 analyzed', value: sumCol('team2', 'statistics', 'Input 2 Analyzed'), color: 'var(--good)' }
    ];

    var g = 0, y = 0, rd = 0; var opsSd = week.teams.team3.sec['operations-status'];
    if (opsSd && opsSd.rows) Object.values(opsSd.rows).forEach(function (arr) { arr.forEach(function (r) { if (r.status === 'green') g++; else if (r.status === 'yellow') y++; else if (r.status === 'red') rd++; }); });
    var opsTotal = g + y + rd, opsMax = Math.max(1, g, y, rd);
    var opsRows = [
      { label: 'Green', count: g, color: 'var(--good)', h: Math.round(g / opsMax * 100) },
      { label: 'Yellow', count: y, color: 'var(--warn)', h: Math.round(y / opsMax * 100) },
      { label: 'Red', count: rd, color: 'var(--bad)', h: Math.round(rd / opsMax * 100) }
    ];

    var macAct = sumCol('team1', 'machines-activity', 'Machines Active'), macInact = sumCol('team1', 'machines-activity', 'Machines Inactive');
    var soComp = sumCol('team1', 'systems-outcomes', 'Completed'), soPend = sumCol('team1', 'systems-outcomes', 'Pending');
    var recovSd = week.teams.team1.sec['recovered-systems']; var recovCount = recovSd ? (recovSd.items || []).filter(function (x) { return x.text; }).length : 0;
    var sysHealth = [
      { label: 'Machines up', value: macAct, color: 'var(--good)' },
      { label: 'Machines down', value: macInact, color: macInact > 0 ? 'var(--warn)' : 'var(--muted)' },
      { label: 'Recovered', value: recovCount, color: 'var(--accent-2)' },
      { label: 'Completed', value: soComp, color: 'var(--good)' },
      { label: 'Pending', value: soPend, color: soPend > 0 ? 'var(--warn)' : 'var(--muted)' },
      { label: 'Red items', value: rd, color: rd > 0 ? 'var(--bad)' : 'var(--muted)' }
    ];

    var recovery = [];
    var t1r = sumCol('team1', 'tasks-received', 'Total Received'), t1c = sumCol('team1', 'tasks-received', 'Total Recovered');
    recovery.push({ name: names.team1, pct: t1r ? Math.round(t1c / t1r * 100) : 0, sub: 'Tasks recovered / received' });
    var t2r = sumCol('team2', 'statistics', 'Input 1 Received') + sumCol('team2', 'statistics', 'Input 2 Received');
    var t2a = sumCol('team2', 'statistics', 'Input 1 Analyzed') + sumCol('team2', 'statistics', 'Input 2 Analyzed');
    recovery.push({ name: names.team2, pct: t2r ? Math.round(t2a / t2r * 100) : 0, sub: 'Inputs analyzed / received' });
    recovery.push({ name: names.team3, pct: opsTotal ? Math.round(g / opsTotal * 100) : 0, sub: 'Systems green / total' });
    recovery.forEach(function (r) { r.color = r.pct >= 75 ? 'var(--good)' : r.pct >= 40 ? 'var(--warn)' : 'var(--bad)'; });

    var tna = [];
    ['team1', 'team2', 'team3'].forEach(function (tk) {
      var def = d.global.sections[tk].filter(function (s) { return s.sid === 'tna'; })[0]; var s = week.teams[tk].sec['tna'];
      (s ? s.rows : []).forEach(function (r) {
        var name = r[keyOf(def.columns, 'Name')], need = r[keyOf(def.columns, 'Training / Need')], st = r[keyOf(def.columns, 'Status')], notes = r[keyOf(def.columns, 'Notes')];
        if (name || need || st || notes) tna.push({ name: name || '—', need: need || '', status: st || '', notes: notes || '' });
      });
    });

    var absent = []; var rx = /vacation|day ?off|sick|leave|unavailable|absen|\boff\b|out of office/i;
    ['team1', 'team2', 'team3'].forEach(function (tk) {
      var def = d.global.sections[tk].filter(function (s) { return s.sid === 'availability'; })[0]; var s = week.teams[tk].sec['availability'];
      (s ? s.rows : []).forEach(function (r) {
        var name = r[keyOf(def.columns, 'Name')], st = r[keyOf(def.columns, 'Status')] || '';
        if (st && rx.test(st)) absent.push({ name: name || 'Unnamed', status: st, team: names[tk], initials: initials(name) });
      });
    });

    var html = '<div style="display:flex; flex-direction:column; gap:16px; animation:soc-fade .25s ease;">';

    html += '<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(270px,1fr)); gap:14px;">';
    teamSummaries.forEach(function (t) {
      html += '<div style="border:1px solid var(--border); border-radius:14px; padding:16px; background:var(--panel);">' +
        '<div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">' +
        '<div style="font-family:var(--head); font-size:14px; font-weight:600; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(t.name) + '</div>' +
        '<span style="flex:0 0 auto; font-family:var(--mono); font-size:10px; font-weight:600; color:' + t.color + '; padding:3px 8px; border-radius:99px; border:1px solid ' + t.color + ';">' + t.health + '</span></div>' +
        '<div style="font-size:12.5px; color:var(--text); margin-top:10px; line-height:1.5; min-height:38px;">' + esc(t.text) + '</div>' +
        '<div style="font-size:11px; color:var(--muted); margin-top:8px;">' + esc(t.detail) + '</div></div>';
    });
    html += '</div>';

    html += '<div style="display:grid; grid-template-columns:minmax(0,1.35fr) minmax(0,1fr); gap:16px;">' +
      '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:14px; font-weight:600;">Activity by team</div>' +
      '<div style="font-size:11.5px; color:var(--muted); margin-top:1px; margin-bottom:16px;">Records logged this week</div>' +
      '<div style="display:flex; flex-direction:column; gap:11px;">';
    comparison.forEach(function (b) {
      html += '<div style="display:grid; grid-template-columns:minmax(120px,180px) 1fr auto; gap:12px; align-items:center;">' +
        '<div style="font-size:12px; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="' + esc(b.label) + '">' + esc(b.label) + '</div>' +
        '<div style="height:16px; border-radius:99px; background:rgba(255,255,255,.05); overflow:hidden;"><div style="height:100%; border-radius:99px; background:' + b.color + '; width:' + bar(b.h) + '%; min-width:2%;"></div></div>' +
        '<div style="font-family:var(--mono); font-size:12px; font-weight:600; color:var(--text);">' + b.val + '</div></div>';
    });
    html += '</div></div>' +
      '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:14px; font-weight:600; margin-bottom:14px;">System health &amp; recovery</div>' +
      '<div style="display:grid; grid-template-columns:repeat(3,1fr); gap:9px;">';
    sysHealth.forEach(function (h) {
      html += '<div style="border:1px solid var(--border); border-radius:11px; padding:12px 9px; text-align:center; background:var(--panel-3);">' +
        '<div style="font-family:var(--head); font-size:22px; font-weight:600; color:' + h.color + ';">' + h.value + '</div>' +
        '<div style="font-size:10px; color:var(--muted); margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(h.label) + '</div></div>';
    });
    html += '</div></div></div>';

    html += '<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:16px;">' +
      '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:13.5px; font-weight:600;">Team 1 · Jira analytics</div>' +
      '<div style="font-size:11px; color:var(--muted); margin-top:1px; margin-bottom:14px;">Total vs recovered tasks</div>' +
      '<div style="display:flex; align-items:flex-end; gap:16px; margin-bottom:12px;">' +
      '<div><div style="font-family:var(--head); font-size:30px; font-weight:600; line-height:1;">' + jira.recovered + '</div><div style="font-size:10.5px; color:var(--muted); margin-top:4px;">recovered</div></div>' +
      '<div style="color:var(--faint); font-size:16px; padding-bottom:4px;">/</div>' +
      '<div><div style="font-family:var(--head); font-size:30px; font-weight:600; line-height:1; color:var(--muted);">' + jira.total + '</div><div style="font-size:10.5px; color:var(--muted); margin-top:4px;">total</div></div>' +
      '<div style="flex:1; text-align:right;"><span style="font-family:var(--mono); font-size:14px; font-weight:600; color:' + jira.color + ';">' + jira.pct + '%</span></div></div>' +
      '<div style="height:8px; border-radius:99px; background:rgba(255,255,255,.06); overflow:hidden;"><div style="height:100%; border-radius:99px; background:' + jira.color + '; width:' + bar(jira.pct) + '%;"></div></div></div>';

    html += '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:13.5px; font-weight:600;">Team 2 · Statistics</div>' +
      '<div style="font-size:11px; color:var(--muted); margin-top:1px; margin-bottom:14px;">Received vs analyzed</div>' +
      '<div style="display:grid; grid-template-columns:1fr 1fr; gap:9px;">';
    stats.forEach(function (st) {
      html += '<div style="border:1px solid var(--border); border-radius:10px; padding:10px; background:var(--panel-3);">' +
        '<div style="font-family:var(--head); font-size:18px; font-weight:600; color:' + st.color + ';">' + st.value + '</div>' +
        '<div style="font-size:10px; color:var(--muted); margin-top:2px;">' + esc(st.label) + '</div></div>';
    });
    html += '</div></div>';

    html += '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:13.5px; font-weight:600;">Team 3 · Operations status</div>' +
      '<div style="font-size:11px; color:var(--muted); margin-top:1px; margin-bottom:14px;">' + opsTotal + ' items tracked</div>' +
      '<div style="display:flex; flex-direction:column; gap:9px;">';
    opsRows.forEach(function (o) {
      html += '<div style="display:flex; align-items:center; gap:10px;">' +
        '<span style="width:12px; height:12px; border-radius:4px; background:' + o.color + ';"></span>' +
        '<div style="flex:1; height:10px; border-radius:99px; background:rgba(255,255,255,.05); overflow:hidden;"><div style="height:100%; background:' + o.color + '; width:' + bar(o.h) + '%;"></div></div>' +
        '<div style="font-family:var(--mono); font-size:12px; font-weight:600; color:' + o.color + '; width:26px; text-align:right;">' + o.count + '</div>' +
        '<div style="font-size:11px; color:var(--muted); width:56px;">' + o.label + '</div></div>';
    });
    html += '</div></div></div>';

    html += '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:14px; font-weight:600; margin-bottom:15px;">Recovery &amp; resolution rate</div>' +
      '<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:18px;">';
    recovery.forEach(function (r) {
      html += '<div><div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:7px;">' +
        '<span style="font-size:12.5px; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(r.name) + '</span>' +
        '<span style="font-family:var(--mono); font-size:13px; font-weight:600; color:' + r.color + ';">' + r.pct + '%</span></div>' +
        '<div style="height:8px; border-radius:99px; background:rgba(255,255,255,.06); overflow:hidden;"><div style="height:100%; border-radius:99px; background:' + r.color + '; width:' + bar(r.pct) + '%;"></div></div>' +
        '<div style="font-size:11px; color:var(--muted); margin-top:6px;">' + esc(r.sub) + '</div></div>';
    });
    html += '</div></div>';

    html += '<div style="display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:16px;">' +
      '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:14px; font-weight:600; margin-bottom:3px;">TNA updates</div>' +
      '<div style="font-size:11.5px; color:var(--muted); margin-bottom:13px;">Training needs across teams</div>' +
      '<div style="display:flex; flex-direction:column; gap:8px;">';
    if (tna.length === 0) {
      html += '<div style="padding:14px; text-align:center; color:var(--muted); font-size:12px;">No TNA entries yet.</div>';
    } else {
      tna.forEach(function (t) {
        html += '<div style="display:grid; grid-template-columns:1fr auto; gap:10px; align-items:center; padding:10px 12px; border:1px solid var(--border); border-radius:10px; background:var(--panel-3);">' +
          '<div style="min-width:0;"><div style="font-size:12.5px; font-weight:500;">' + esc(t.name) + ' · <span style="color:var(--muted); font-weight:400;">' + esc(t.need) + '</span></div>' +
          '<div style="font-size:11px; color:var(--faint); margin-top:2px;">' + esc(t.notes) + '</div></div>' +
          '<span style="font-family:var(--mono); font-size:10px; color:var(--accent-2); white-space:nowrap;">' + esc(t.status) + '</span></div>';
      });
    }
    html += '</div></div>';

    html += '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel); padding:var(--pad);">' +
      '<div style="font-family:var(--head); font-size:14px; font-weight:600; margin-bottom:3px;">Availability &amp; absence</div>' +
      '<div style="font-size:11.5px; color:var(--muted); margin-bottom:13px;">People marked off, sick, on leave or unavailable</div>' +
      '<div style="display:flex; flex-direction:column; gap:8px;">';
    if (absent.length === 0) {
      html += '<div style="padding:14px; text-align:center; color:var(--muted); font-size:12px;">Everyone is available this week.</div>';
    } else {
      absent.forEach(function (p) {
        html += '<div style="display:grid; grid-template-columns:auto 1fr auto; align-items:center; gap:10px; padding:9px 11px; border:1px solid var(--border); border-radius:10px;">' +
          '<span style="width:26px; height:26px; border-radius:99px; display:grid; place-items:center; background:var(--panel-2); font-family:var(--mono); font-size:9px; font-weight:600; color:var(--muted);">' + esc(p.initials) + '</span>' +
          '<div style="min-width:0;"><div style="font-size:12.5px; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(p.name) + '</div>' +
          '<div style="font-size:10.5px; color:var(--faint);">' + esc(p.team) + '</div></div>' +
          '<span style="font-family:var(--mono); font-size:10.5px; font-weight:600; color:var(--warn); white-space:nowrap;">' + esc(p.status) + '</span></div>';
      });
    }
    html += '</div></div></div></div>';
    return html;
  }

  // ---------------- team section renderers ----------------
  function renderSectionBody(tk, def, data) {
    if (def.type === 'summary') {
      return '<textarea ' + bindAttr('editSummary', [tk, def.sid]) + ' placeholder="Write this week\'s summary…" style="width:100%; min-height:76px; background:var(--panel-3); border:1px solid var(--border); resize:vertical; color:var(--text); font-size:13px; line-height:1.55; padding:12px 14px; border-radius:10px;">' + esc(data.text || '') + '</textarea>';
    }
    if (def.type === 'list') {
      var toneMap = {
        neutral: { dot: 'var(--accent)', border: 'var(--accent)', bg: 'var(--panel-3)', text: 'var(--text)' },
        warn: { dot: 'var(--warn)', border: 'var(--warn)', bg: 'rgba(251,191,36,.05)', text: '#fde9bf' },
        danger: { dot: 'var(--bad)', border: 'var(--bad)', bg: 'rgba(248,113,113,.05)', text: '#fecaca' }
      };
      var t = toneMap[def.tone || 'neutral'];
      var items = data.items || [];
      var html = '<div style="display:flex; flex-direction:column; gap:8px;">';
      items.forEach(function (it) {
        html += '<div style="display:grid; grid-template-columns:auto 1fr auto; gap:10px; align-items:start; padding:10px 12px; border:1px solid var(--border); border-left:2px solid ' + t.border + '; border-radius:9px; background:' + t.bg + ';">' +
          '<span style="width:6px; height:6px; margin-top:6px; border-radius:99px; background:' + t.dot + ';"></span>' +
          '<textarea ' + bindAttr('editListItem', [tk, def.sid, it.id]) + ' placeholder="Type an entry…" style="width:100%; min-height:22px; background:transparent; border:none; resize:vertical; color:' + t.text + '; font-size:12.5px; line-height:1.5; padding:1px 0;">' + esc(it.text || '') + '</textarea>' +
          '<button ' + actAttr('delListItem', [tk, def.sid, it.id]) + ' style="width:22px; height:22px; border-radius:6px; border:1px solid var(--border); background:transparent; color:var(--muted); cursor:pointer; font-size:11px;">×</button></div>';
      });
      if (items.length === 0) html += '<button ' + actAttr('addListItem', [tk, def.sid]) + ' style="text-align:left; padding:11px 13px; border:1px dashed var(--border-2); border-radius:9px; background:transparent; color:var(--faint); font-size:12px; cursor:pointer;">No entries — click to add</button>';
      html += '</div>';
      return html;
    }
    if (def.type === 'weekday') {
      var WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      var html2 = '<div style="display:flex; flex-direction:column; gap:10px;">';
      WD.forEach(function (day) {
        var entries = (data.entries || []).filter(function (x) { return x.day === day; });
        html2 += '<div style="display:grid; grid-template-columns:70px 1fr; gap:12px; align-items:start;">' +
          '<div style="display:flex; flex-direction:column; align-items:center; gap:4px; padding-top:5px;">' +
          '<span style="font-family:var(--mono); font-size:11px; font-weight:600; letter-spacing:.06em; color:var(--text); text-transform:uppercase;">' + day + '</span>' +
          '<button ' + actAttr('addWeekday', [tk, def.sid, day]) + ' title="Add entry" style="width:22px; height:22px; border-radius:6px; border:1px solid var(--border-2); background:transparent; color:var(--accent); cursor:pointer; font-size:13px; line-height:1;">+</button></div>' +
          '<div style="display:flex; flex-direction:column; gap:6px; min-width:0;">';
        entries.forEach(function (e) {
          html2 += '<div style="display:grid; grid-template-columns:auto 1fr auto; gap:9px; align-items:center; padding:8px 11px; border:1px solid var(--border); border-left:2px solid var(--accent); border-radius:9px; background:var(--panel-3);">' +
            '<span style="width:5px; height:5px; border-radius:99px; background:var(--accent);"></span>' +
            '<input value="' + esc(e.text || '') + '" ' + bindAttr('editWeekday', [tk, def.sid, e.id]) + ' placeholder="Log entry…" style="width:100%; background:transparent; border:none; color:var(--text); font-size:12.5px; padding:2px 0;" />' +
            '<button ' + actAttr('delWeekday', [tk, def.sid, e.id]) + ' style="width:22px; height:22px; border-radius:6px; border:1px solid var(--border); background:transparent; color:var(--muted); cursor:pointer; font-size:11px;">×</button></div>';
        });
        if (entries.length === 0) html2 += '<button ' + actAttr('addWeekday', [tk, def.sid, day]) + ' style="text-align:left; padding:8px 11px; border:1px dashed var(--border-2); border-radius:9px; background:transparent; color:var(--faint); font-size:11.5px; cursor:pointer;">No entries — click to add</button>';
        html2 += '</div></div>';
      });
      html2 += '</div>';
      return html2;
    }
    if (def.type === 'table') {
      var cols = def.columns;
      var minWidth = (cols.length + (def.autoStatus ? 1 : 0)) > 6 ? '980px' : '640px';
      var html3 = '<div style="overflow-x:auto;"><table style="width:100%; border-collapse:collapse; min-width:' + minWidth + ';"><thead><tr>';
      cols.forEach(function (col) {
        var typeIcon = col.type === 'number' ? '#' : col.type === 'date' ? '⌚' : 'T';
        html3 += '<th style="text-align:left; padding:8px 10px; border-bottom:1px solid var(--border-2); background:var(--panel-3); white-space:nowrap;"><div style="display:flex; align-items:center; gap:4px;">' +
          '<input value="' + esc(col.label) + '" ' + bindAttr('editColLabel', [tk, def.sid, col.id]) + ' style="width:100%; min-width:74px; background:transparent; border:1px solid transparent; color:var(--muted); font-family:var(--mono); font-size:10px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; padding:3px 4px; border-radius:5px;" />';
        if (!col.fixed) html3 += '<button ' + actAttr('cycleType', [tk, def.sid, col.id]) + ' title="Column type" style="flex:0 0 auto; width:20px; height:20px; border-radius:5px; border:1px solid var(--border-2); background:transparent; color:var(--accent); cursor:pointer; font-size:10px;">' + typeIcon + '</button>' +
          '<button ' + actAttr('delCol', [tk, def.sid, col.id]) + ' title="Remove column" style="flex:0 0 auto; width:20px; height:20px; border-radius:5px; border:1px solid rgba(248,113,113,.3); background:transparent; color:#fca5a5; cursor:pointer; font-size:11px;">×</button>';
        html3 += '</div></th>';
      });
      if (def.autoStatus) html3 += '<th style="text-align:left; padding:8px 10px; border-bottom:1px solid var(--border-2); background:var(--panel-3); font-family:var(--mono); font-size:10px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; color:var(--muted); white-space:nowrap;">Status</th>';
      html3 += '<th style="width:38px; border-bottom:1px solid var(--border-2); background:var(--panel-3);"></th></tr></thead><tbody>';
      var rows = data.rows || [];
      rows.forEach(function (r) {
        html3 += '<tr>';
        cols.forEach(function (col) {
          var inputType = col.type === 'number' ? 'number' : col.type === 'date' ? 'date' : 'text';
          var font = (col.type === 'number' || col.type === 'date') ? 'var(--mono)' : 'inherit';
          var placeholder = col.type === 'number' ? '0' : col.type === 'date' ? '' : '—';
          var val = (r[col.key] == null ? '' : r[col.key]);
          html3 += '<td style="padding:4px 6px; border-bottom:1px solid var(--border);"><input type="' + inputType + '" value="' + esc(val) + '" ' + bindAttr('editCell', [tk, def.sid, r.id, col.key]) + ' placeholder="' + placeholder + '" style="width:100%; min-width:88px; background:transparent; border:1px solid transparent; color:var(--text); font-size:12px; padding:7px 8px; border-radius:7px; font-family:' + font + ';" /></td>';
        });
        if (def.autoStatus) {
          var a = num(r[def.autoStatus.activeKey]), i = num(r[def.autoStatus.inactiveKey]);
          var statusLabel, statusColor;
          if (a === 0 && i === 0) { statusLabel = '—'; statusColor = 'var(--muted)'; }
          else if (i === 0) { statusLabel = 'Operational'; statusColor = 'var(--good)'; }
          else if (a === 0) { statusLabel = 'Down'; statusColor = 'var(--bad)'; }
          else { statusLabel = 'Degraded'; statusColor = 'var(--warn)'; }
          html3 += '<td style="padding:4px 8px; border-bottom:1px solid var(--border); white-space:nowrap;"><span style="display:inline-flex; align-items:center; gap:6px; font-family:var(--mono); font-size:10.5px; font-weight:600; color:' + statusColor + '; padding:4px 9px; border-radius:99px; border:1px solid ' + statusColor + ';"><span style="width:7px; height:7px; border-radius:99px; background:' + statusColor + ';"></span>' + statusLabel + '</span></td>';
        }
        html3 += '<td style="padding:4px 6px; border-bottom:1px solid var(--border); text-align:center;"><button ' + actAttr('delRow', [tk, def.sid, r.id]) + ' title="Delete row" style="width:26px; height:26px; border-radius:7px; border:1px solid rgba(248,113,113,.26); background:transparent; color:#fca5a5; cursor:pointer; font-size:12px;">✕</button></td></tr>';
      });
      html3 += '</tbody></table>';
      if (rows.length === 0) html3 += '<div style="padding:22px; text-align:center; color:var(--muted); font-size:12.5px;">No rows this week — click <strong style="color:var(--text);">+ Row</strong>.</div>';
      html3 += '</div>';

      if (def.chart) {
        if (rows.length > 0) {
          var chart = buildChart(def.chart, rows);
          html3 += '<div style="margin-top:18px; padding-top:15px; border-top:1px solid var(--border);"><div style="font-family:var(--head); font-size:12.5px; font-weight:600; margin-bottom:14px; color:var(--muted);">' + esc(def.chart.title) + '</div>';
          if (!def.chart.horizontal) {
            html3 += '<div style="display:flex; align-items:flex-end; gap:14px; height:180px;">';
            chart.bars.forEach(function (grp) {
              html3 += '<div style="flex:1; display:flex; flex-direction:column; align-items:center; gap:7px; height:100%; justify-content:flex-end; min-width:0;">' +
                '<div style="display:flex; align-items:flex-end; gap:4px; height:100%; width:100%; justify-content:center;">';
              grp.groups.forEach(function (b) {
                html3 += '<div style="flex:1; max-width:26px; border-radius:5px 5px 2px 2px; background:' + b.color + '; height:' + bar(b.h) + '%; min-height:2px;" title="' + b.val + '"></div>';
              });
              html3 += '</div><div style="width:100%; text-align:center; font-size:10px; color:var(--faint); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="' + esc(grp.label) + '">' + esc(grp.label) + '</div></div>';
            });
            html3 += '</div>';
          } else {
            html3 += '<div style="display:flex; flex-direction:column; gap:9px;">';
            chart.bars.forEach(function (b) {
              html3 += '<div style="display:grid; grid-template-columns:minmax(120px,200px) 1fr auto; gap:12px; align-items:center;">' +
                '<div style="font-size:11.5px; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="' + esc(b.label) + '">' + esc(b.label) + '</div>' +
                '<div style="height:15px; border-radius:99px; background:rgba(255,255,255,.05); overflow:hidden;"><div style="height:100%; border-radius:99px; background:' + b.color + '; width:' + bar(b.h) + '%; min-width:2%;"></div></div>' +
                '<div style="font-family:var(--mono); font-size:11px; font-weight:600; color:var(--text);">' + b.val + '</div></div>';
            });
            html3 += '</div>';
          }
          if (chart.hasLegend) {
            html3 += '<div style="display:flex; gap:16px; margin-top:13px; flex-wrap:wrap;">';
            chart.legend.forEach(function (l) { html3 += '<div style="display:flex; align-items:center; gap:6px; font-size:11px; color:var(--muted);"><span style="width:10px; height:10px; border-radius:3px; background:' + l.color + ';"></span>' + esc(l.label) + '</div>'; });
            html3 += '</div>';
          }
          html3 += '</div>';
        } else {
          html3 += '<div style="margin-top:14px; padding:16px; text-align:center; color:var(--muted); font-size:11.5px; border:1px dashed var(--border-2); border-radius:10px;">Add rows to build the chart.</div>';
        }
      }
      return html3;
    }
    if (def.type === 'ops') {
      var html4 = '<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:14px;">';
      def.groups.forEach(function (g) {
        var grows = ((data.rows || {})[g.id] || []);
        html4 += '<div style="border:1px solid var(--border); border-radius:12px; background:var(--panel-3); overflow:hidden;">' +
          '<div style="display:flex; align-items:center; gap:8px; padding:11px 12px; border-bottom:1px solid var(--border);">' +
          '<input value="' + esc(g.name || '') + '" ' + bindAttr('opsRenameGroup', [tk, def.sid, g.id]) + ' placeholder="Group name" style="flex:1; min-width:0; background:transparent; border:1px solid transparent; color:var(--text); font-family:var(--head); font-size:12.5px; font-weight:600; padding:3px 5px; border-radius:6px;" />' +
          '<button ' + actAttr('opsAddRow', [tk, def.sid, g.id]) + ' style="flex:0 0 auto; padding:5px 9px; border-radius:7px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:11px; font-weight:600; cursor:pointer;">+ Row</button></div>' +
          '<div style="display:flex; flex-direction:column;">';
        grows.forEach(function (r) {
          html4 += '<div style="display:grid; grid-template-columns:1fr auto auto; gap:8px; align-items:center; padding:9px 12px; border-bottom:1px solid var(--border);">' +
            '<input value="' + esc(r.name || '') + '" ' + bindAttr('opsEditName', [tk, def.sid, g.id, r.id]) + ' placeholder="Item…" style="min-width:0; background:transparent; border:1px solid transparent; color:var(--text); font-size:12.5px; padding:4px 5px; border-radius:6px;" />' +
            '<div style="display:flex; gap:5px;">' +
            '<button ' + actAttr('opsSetStatus', [tk, def.sid, g.id, r.id, 'green']) + ' title="Green" style="' + opsBtnStyle(r.status === 'green', 'var(--good)') + '">G</button>' +
            '<button ' + actAttr('opsSetStatus', [tk, def.sid, g.id, r.id, 'yellow']) + ' title="Yellow" style="' + opsBtnStyle(r.status === 'yellow', 'var(--warn)') + '">Y</button>' +
            '<button ' + actAttr('opsSetStatus', [tk, def.sid, g.id, r.id, 'red']) + ' title="Red" style="' + opsBtnStyle(r.status === 'red', 'var(--bad)') + '">R</button></div>' +
            '<button ' + actAttr('opsDelRow', [tk, def.sid, g.id, r.id]) + ' style="width:22px; height:22px; border-radius:6px; border:1px solid var(--border); background:transparent; color:var(--muted); cursor:pointer; font-size:11px;">×</button></div>';
        });
        if (grows.length === 0) html4 += '<button ' + actAttr('opsAddRow', [tk, def.sid, g.id]) + ' style="text-align:left; margin:10px 12px; padding:8px 11px; border:1px dashed var(--border-2); border-radius:8px; background:transparent; color:var(--faint); font-size:11.5px; cursor:pointer;">No items — click to add</button>';
        html4 += '</div></div>';
      });
      html4 += '</div>';
      return html4;
    }
    if (def.type === 'personnel') {
      var d = state.data;
      var roster = (d.global.members && d.global.members[tk]) ? d.global.members[tk] : [];
      var html5 = '<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(230px, 1fr)); gap:11px;">';
      roster.forEach(function (m) {
        var color = memberStatusColor(m.status);
        html5 += '<div style="position:relative; border:1px solid var(--border); border-radius:11px; padding:12px; background:var(--panel-3);">' +
          '<button ' + actAttr('delMember', [tk, m.id]) + ' title="Remove" style="position:absolute; top:8px; right:8px; width:20px; height:20px; border-radius:5px; border:1px solid var(--border); background:transparent; color:var(--muted); cursor:pointer; font-size:11px;">×</button>' +
          '<div style="display:flex; align-items:center; gap:10px; margin-bottom:10px; padding-right:20px;">' +
          '<div style="flex:0 0 auto; width:36px; height:36px; border-radius:99px; display:grid; place-items:center; background:var(--accent); color:var(--on-accent); font-family:var(--mono); font-weight:600; font-size:12px;">' + esc(initials(m.name)) + '</div>' +
          '<div style="min-width:0; flex:1;">' +
          '<input value="' + esc(m.name || '') + '" ' + bindAttr('editMember', [tk, m.id, 'name']) + ' placeholder="Full name" style="width:100%; background:transparent; border:1px solid transparent; color:var(--text); font-size:13px; font-weight:600; padding:2px 3px; border-radius:5px;" />' +
          '<input value="' + esc(m.role || '') + '" ' + bindAttr('editMember', [tk, m.id, 'role']) + ' placeholder="Role" style="width:100%; background:transparent; border:1px solid transparent; color:var(--muted); font-size:11px; padding:1px 3px; border-radius:5px;" />' +
          '</div></div>' +
          '<button ' + actAttr('cycleMemberStatus', [tk, m.id]) + ' title="Change status" style="display:inline-flex; align-items:center; gap:6px; padding:5px 10px; border-radius:99px; border:1px solid ' + color + '; background:transparent; color:' + color + '; font-size:11px; font-weight:600; cursor:pointer; white-space:nowrap;">' +
          '<span style="width:7px; height:7px; border-radius:99px; background:' + color + ';"></span>' + esc(m.status) + '</button></div>';
      });
      html5 += '</div>';
      if (roster.length === 0) html5 += '<div style="padding:18px; text-align:center; color:var(--muted); font-size:12px; border:1px dashed var(--border-2); border-radius:10px; margin-top:11px;">No personnel yet — click <strong style="color:var(--text);">+ Member</strong>.</div>';
      return html5;
    }
    return '';
  }

  function renderTeam(tk) {
    var d = state.data, week = cur(), defs = d.global.sections[tk];
    var html = '<div style="display:flex; flex-direction:column; gap:16px; animation:soc-fade .25s ease;">';
    defs.forEach(function (def) {
      var data = def.type === 'personnel' ? null : week.teams[tk].sec[def.sid];
      var cid = 'sec-' + tk + '-' + def.sid;
      var open = cc(cid, true).open;
      var chevron = open ? '▾' : '▸';
      var accentBar = def.tone === 'warn' ? 'var(--warn)' : def.tone === 'danger' ? 'var(--bad)' : 'var(--accent)';
      var subtitle = def.subtitle;
      if (def.type === 'list' && !subtitle) subtitle = (data.items || []).length + ' entries';
      if (def.type === 'table' && !subtitle) subtitle = (data.rows || []).length + ' rows · columns persist across weeks';
      if (def.type === 'personnel') {
        var roster = (d.global.members && d.global.members[tk]) ? d.global.members[tk] : [];
        var avail = roster.filter(function (m) { return m.status === 'Available' || m.status === 'On-call'; }).length;
        subtitle = avail + ' of ' + roster.length + ' available · shared across weeks';
      }
      html += '<div style="border:1px solid var(--border); border-radius:14px; background:var(--panel);">' +
        '<div style="display:flex; align-items:center; justify-content:space-between; gap:10px; padding:var(--pad); border-bottom:1px solid var(--border);">' +
        '<div style="display:flex; align-items:center; gap:10px; min-width:0;">' +
        '<button ' + actAttr('toggleCollapse', [cid]) + ' style="flex:0 0 auto; width:24px; height:24px; border-radius:7px; border:1px solid var(--border); background:transparent; color:var(--muted); cursor:pointer; font-size:11px;">' + chevron + '</button>' +
        '<span style="flex:0 0 auto; width:3px; height:22px; border-radius:2px; background:' + accentBar + ';"></span>' +
        '<div style="min-width:0;"><div style="font-family:var(--head); font-size:14px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + esc(def.title) + '</div>' +
        '<div style="font-size:11px; color:var(--muted); margin-top:1px;">' + esc(subtitle) + '</div></div></div>' +
        '<div style="display:flex; gap:6px; flex:0 0 auto;">';
      if (def.type === 'table') html += '<button ' + actAttr('addColumn', [tk, def.sid]) + ' style="padding:7px 10px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:11.5px; font-weight:600; cursor:pointer; white-space:nowrap;">+ Col</button>' +
        '<button ' + actAttr('addRow', [tk, def.sid]) + ' style="padding:7px 11px; border-radius:8px; border:none; background:var(--accent); color:var(--on-accent); font-size:11.5px; font-weight:600; cursor:pointer; white-space:nowrap;">+ Row</button>';
      if (def.type === 'list') html += '<button ' + actAttr('addListItem', [tk, def.sid]) + ' style="padding:7px 11px; border-radius:8px; border:1px solid var(--border-2); background:var(--panel); color:var(--text); font-size:11.5px; font-weight:600; cursor:pointer; white-space:nowrap;">+ Entry</button>';
      if (def.type === 'personnel') html += '<button ' + actAttr('addMember', [tk]) + ' style="padding:7px 11px; border-radius:8px; border:none; background:var(--accent); color:var(--on-accent); font-size:11.5px; font-weight:600; cursor:pointer; white-space:nowrap;">+ Member</button>';
      html += '</div></div>';
      if (open) html += '<div style="padding:var(--pad);">' + renderSectionBody(tk, def, data) + '</div>';
      html += '</div>';
    });
    html += '</div>';
    return html;
  }

  function render() {
    if (!state.data) { app.innerHTML = '<div style="padding:40px; color:var(--muted);">Loading…</div>'; return; }
    var c = { pad: '16px' };
    var content = state.view === 'overview' ? renderOverview() : renderTeam(state.team);
    var footNote = 'Auto-saved locally · ' + relTime(state.data.meta.lastSync);
    app.innerHTML = '<div style="display:flex; min-height:100vh; align-items:stretch;">' +
      renderSidebar() +
      '<div style="flex:1; min-width:0; display:flex; flex-direction:column;">' +
      renderHeader() +
      '<div style="padding:22px; display:flex; flex-direction:column; gap:16px;">' +
      content +
      '<div id="footNote" style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; padding-top:6px; color:var(--faint); font-size:11px;">' +
      '<span style="font-family:var(--mono); letter-spacing:.04em;">OFFLINE-FIRST · localStorage · no server · no CDN</span>' +
      '<span id="footNoteText">' + esc(footNote) + '</span></div>' +
      '</div></div></div>';
  }

  function patchStatus() {
    var badge = document.getElementById('statusBadge');
    var sidebarStatus = document.getElementById('sidebarStatus');
    var footNoteText = document.getElementById('footNoteText');
    if (badge) { var tmp = document.createElement('div'); tmp.innerHTML = renderStatusBadge(); badge.replaceWith(tmp.firstChild); }
    if (sidebarStatus) { var tmp2 = document.createElement('div'); tmp2.innerHTML = sidebarStatusHtml(); sidebarStatus.replaceWith(tmp2.firstChild); }
    if (footNoteText) footNoteText.textContent = 'Auto-saved locally · ' + relTime(state.data.meta.lastSync);
    attachDelegatedHandlers();
  }

  // ---------------- action dispatch table ----------------
  var ACTIONS = {
    setView: setView, weekNav: weekNav, toggleSidebar: toggleSidebar, toggleCollapse: toggleCollapse,
    flush: flush, toggleOffline: toggleOffline, doExportJSON: doExportJSON, doExportWord: doExportWord, importClick: importClick,
    addListItem: addListItem, delListItem: delListItem,
    addWeekday: addWeekday, delWeekday: delWeekday,
    addRow: addRow, delRow: delRow, addColumn: addColumn, cycleType: cycleType, delCol: delCol,
    opsAddRow: opsAddRow, opsSetStatus: opsSetStatus, opsDelRow: opsDelRow,
    addMember: addMember, cycleMemberStatus: cycleMemberStatus, delMember: delMember
  };
  var BINDS = {
    editTeamName: editTeamName, editSummary: editSummary, editListItem: editListItem, editWeekday: editWeekday,
    editCell: editCell, editColLabel: editColLabel, opsRenameGroup: opsRenameGroup, opsEditName: opsEditName,
    editMember: editMember, editOrg: editOrg
  };

  function onClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var desc = JSON.parse(el.getAttribute('data-act'));
    var fn = ACTIONS[desc.fn];
    if (fn) fn.apply(null, desc.args || []);
  }
  function onInput(e) {
    var el = e.target;
    if (!el.matches('[data-bind]')) return;
    var desc = JSON.parse(el.getAttribute('data-bind'));
    var fn = BINDS[desc.fn];
    if (fn) fn.apply(null, (desc.args || []).concat([el.value]));
  }
  function onBlur(e) {
    var el = e.target;
    if (el.matches && el.matches('[data-bind]')) commit();
  }

  var handlersAttached = false;
  function attachDelegatedHandlers() {
    if (handlersAttached) return;
    handlersAttached = true;
    document.addEventListener('click', onClick);
    document.addEventListener('input', onInput);
    document.addEventListener('blur', onBlur, true);
    fileInput.addEventListener('change', doImport);
  }

  // ---------------- boot ----------------
  function boot() {
    var data = load();
    if (!data) { data = seed(); persist(data); }
    else { data = migrate(data); persist(data); }
    state.data = data;
    attachDelegatedHandlers();
    render();

    window.addEventListener('online', function () { handleConn(true); });
    window.addEventListener('offline', function () { handleConn(false); });
    setInterval(function () { patchStatus(); }, 30000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
