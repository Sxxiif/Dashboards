# SOC Weekly Operations Console V4

This is a rebuilt offline dashboard sample for SOC / Cyber weekly operations.

## Files required

Keep these two files in the same folder:

```text
index.html
app.js
```

Open `index.html` in Microsoft Edge or Chrome.

## Important

- No internet required
- No CDN
- No external libraries
- No server required
- Uses localStorage for weekly saved data
- Uses inline SVG charts
- English only
- Light/Dark theme included
- Team names remain: Team 1, Team 2, Team 3, Overview

## VDI notes

The dashboard should run on a normal VDI because it uses lightweight HTML, CSS, and vanilla JavaScript. If buttons do not work, the VDI/browser is likely blocking local JavaScript from `file://` paths. In that case, ask IT whether local JavaScript files are allowed or host the folder on an approved internal web share/server.

## Security note

Do not upload real SOC data, employee data, exported JSON, or company logos to a public GitHub repository.
