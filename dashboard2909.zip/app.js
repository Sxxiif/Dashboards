/* Offline Weekly Dashboard - clean stable app.js
   Built for local/offline VDI use. No CDN, no network calls, no external libraries. */

const STORAGE_KEY = 'sxxiif_offline_weekly_dashboard_clean_v2';
const LEGACY_KEYS = ['sxxiif_offline_weekly_dashboard_v1'];
const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
let currentView = 'home';
let state;

function uid() { return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8); }
function nowStamp() { return new Date().toLocaleString(); }
function todayISO() { return formatISODate(new Date()); }
function esc(value) { return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function number(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; }
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function safeText(value) { return String(value ?? '').trim(); }

function formatISODate(date) {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function parseISODate(value) {
  const parts = String(value || todayISO()).split('-').map(Number);
  return new Date(parts[0] || new Date().getFullYear(), (parts[1] || 1) - 1, parts[2] || 1);
}
function startOfWeekISO(value) {
  const d = value instanceof Date ? new Date(value) : parseISODate(value || todayISO());
  d.setHours(0,0,0,0);
  const diff = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - diff);
  return formatISODate(d);
}
function addDaysISO(value, days) { const d = parseISODate(value); d.setDate(d.getDate() + days); return formatISODate(d); }
function formatShortDate(value) { return parseISODate(value).toLocaleDateString(undefined, {day:'2-digit', month:'short', year:'numeric'}); }
function currentWeekStart() { state.meta.currentWeekStart = state.meta.currentWeekStart || startOfWeekISO(todayISO()); return state.meta.currentWeekStart; }
function currentWeekLabel() { const s = currentWeekStart(); return `${formatShortDate(s)} - ${formatShortDate(addDaysISO(s, 6))}`; }
function exportDateStamp() { return todayISO(); }
function cleanFilename(value) { return String(value || 'dashboard').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'dashboard'; }

function storageGet(key) { try { return window.localStorage ? localStorage.getItem(key) : null; } catch { return null; } }
function storageSet(key, value) { try { if (!window.localStorage) return false; localStorage.setItem(key, value); return true; } catch { return false; } }


function compactDefaultColumns() {
  return {
    team1TasksReceived: [
      { id:'date', label:'Date', type:'date', system:true },
      { id:'refNumber', label:'Ref Number', type:'text', system:true },
      { id:'caseName', label:'Case Name', type:'text', system:true },
      { id:'totalReceived', label:'Total Received', type:'number', system:true },
      { id:'totalRecovered', label:'Total Recovered', type:'number', system:true },
      { id:'complexity', label:'Complexity', type:'text', system:true },
      { id:'urgent', label:'Urgent', type:'text', system:true },
      { id:'saifCreated', label:'Saif.Created', type:'text', system:true },
      { id:'progress', label:'Progress %', type:'number', system:true },
      { id:'resultProgress', label:'Result Progress %', type:'number', system:true }
    ],
    team2Requested: [
      { id:'taskName', label:'Task Name', type:'text' },
      { id:'refNumber', label:'Ref Number', type:'text' },
      { id:'requestedFrom', label:'Requested From', type:'text' },
      { id:'notes', label:'Notes', type:'text' }
    ],
    team2Internal: [
      { id:'taskName', label:'Task Name', type:'text' },
      { id:'toolUsed', label:'Tool Used', type:'text' },
      { id:'total', label:'Total', type:'number' },
      { id:'comments', label:'Comments', type:'text' }
    ],
    team3Log: [
      { id:'item', label:'Item / Name', type:'text' },
      { id:'status', label:'Status', type:'text' },
      { id:'notes', label:'Notes', type:'text' }
    ],
    tna: [
      { id:'entry', label:'TNA Input', type:'text' },
      { id:'date', label:'Date', type:'date' },
      { id:'comment', label:'Comment', type:'text' }
    ]
  };
}

function createDefaultGlobal() {
  return {
    teamNames: { team1:'Team 1', team2:'Team 2', team3:'Team 3' },
    labels: { team1:{}, team2:{}, team3:{}, overview:{} },
    tables: compactDefaultColumns(),
    chartSettings: { team1Tasks:'bar', team1Jira:'bar', team2Stats:'bar', team2System:'horizontal' }
  };
}

function blankDaily() { const obj = {}; DAYS.forEach(d => obj[d] = []); return obj; }
function newFlexRows(tableKey, sampleRows = []) {
  const cols = state?.global?.tables?.[tableKey] || compactDefaultColumns()[tableKey] || [];
  return sampleRows.map(sample => {
    const values = {};
    cols.forEach((c, i) => { values[c.id] = sample[c.id] ?? sample[i] ?? ''; });
    return { id: uid(), values };
  });
}
function createPersonnelRows(sampleRows = []) {
  return sampleRows.map(r => ({ id: uid(), idValue:r.idValue || '', name:r.name || '', role:r.role || '' }));
}
function createAvailabilityRows(sampleRows = []) {
  return sampleRows.map(r => ({ id: uid(), name:r.name || '', status:r.status || 'Available', from:r.from || todayISO(), to:r.to || todayISO(), notes:r.notes || '' }));
}
function createTnaRows(sampleRows = []) {
  const cols = state?.global?.tables?.tna || compactDefaultColumns().tna;
  return sampleRows.map(sample => {
    const values = {};
    cols.forEach((c, i) => { values[c.id] = sample[c.id] ?? sample[i] ?? ''; });
    return { id: uid(), values };
  });
}

function createEmptyWeek(weekStart) {
  const weekEnd = addDaysISO(weekStart, 6);
  const rangeText = `${formatShortDate(weekStart)} - ${formatShortDate(weekEnd)}`;
  return {
    createdAt: nowStamp(),
    updatedAt: nowStamp(),
    teams: {
      team1: {
        weeklySummary: `Weekly summary for ${rangeText}.`,
        notes: '',
        dailyTasks: blankDaily(),
        concernsTitle: 'Team 1 Concerns',
        concerns: [],
        systemsActivity: [],
        tasksReceived: [],
        ongoingTasks: [],
        urgentTasks: [],
        recoveredSystems: [],
        systemsOutcomes: [],
        jiraFrom: weekStart,
        jiraTo: weekEnd,
        jiraRecords: [],
        availability: [],
        tnaRows: [],
        personnelRows: []
      },
      team2: {
        weeklySummary: `Weekly summary for ${rangeText}.`,
        notes: '',
        dailyTasks: blankDaily(),
        tableRows: { team2Requested: [], team2Internal: [] },
        statsRows: [],
        resultRows: [],
        systemRows: [],
        availability: [],
        tnaRows: [],
        personnelRows: []
      },
      team3: {
        weeklySummary: `Weekly summary for ${rangeText}.`,
        notes: '',
        dailyInputs: [],
        operations: { group1: [], group2: [] },
        tableRows: { team3Log: [] },
        maintenanceEntries: [],
        availability: [],
        tnaRows: [],
        personnelRows: []
      }
    }
  };
}

function createDefaultState() {
  const wk = startOfWeekISO(todayISO());
  const base = { meta: { createdAt: nowStamp(), lastSaved: nowStamp(), currentWeekStart: wk, theme:'dark', collapsed:{} }, global: createDefaultGlobal(), weeks: {} };
  state = base;
  base.weeks[wk] = createEmptyWeek(wk);
  // Small starter records. These are intentionally compact and easy to delete.
  base.weeks[wk].teams.team1.concerns.push({ id:uid(), text:'', createdAt:nowStamp(), updatedAt:'' });
  base.weeks[wk].teams.team1.jiraRecords.push({ id:uid(), from:wk, to:wk, totalTasks:0, recoveredTasks:0, notes:'' });
  base.weeks[wk].teams.team2.tableRows.team2Requested = newFlexRows('team2Requested', [{}]);
  base.weeks[wk].teams.team2.statsRows.push({ id:uid(), period:'Mon', input1Received:0, input1Analyzed:0, input2Received:0, input2Analyzed:0 });
  base.weeks[wk].teams.team2.systemRows.push({ id:uid(), systemName:'System 1', count:0 });
  base.weeks[wk].teams.team3.dailyInputs.push({ id:uid(), text:'', createdAt:nowStamp(), updatedAt:'' });
  base.weeks[wk].teams.team3.operations.group1.push({ id:uid(), name:'Input name', status:'Green' });
  return base;
}

function ensureGlobalSettings(s) {
  s.global = s.global || createDefaultGlobal();
  const defaults = createDefaultGlobal();
  s.global.teamNames = { ...defaults.teamNames, ...(s.global.teamNames || {}) };
  s.global.labels = s.global.labels || {};
  ['team1','team2','team3','overview'].forEach(k => s.global.labels[k] = s.global.labels[k] || {});
  s.global.tables = s.global.tables || {};
  Object.entries(defaults.tables).forEach(([key, cols]) => {
    if (!Array.isArray(s.global.tables[key]) || !s.global.tables[key].length) s.global.tables[key] = cols;
    s.global.tables[key] = dedupeColumns(s.global.tables[key], cols);
  });
  s.global.chartSettings = { ...defaults.chartSettings, ...(s.global.chartSettings || {}) };
}

function dedupeColumns(cols, fallbackCols) {
  const byId = new Map();
  (cols || []).forEach(col => {
    const id = safeText(col.id) || uid();
    if (!byId.has(id)) byId.set(id, { id, label:safeText(col.label) || 'Column', type:validType(col.type), system:!!col.system });
  });
  // If somehow all columns were removed, restore compact defaults.
  if (!byId.size) (fallbackCols || []).forEach(c => byId.set(c.id, {...c, type:validType(c.type)}));
  return Array.from(byId.values());
}
function validType(type) { return ['text','number','date'].includes(type) ? type : 'text'; }

function ensureWeekSchema(week, weekStart) {
  const fresh = createEmptyWeek(weekStart);
  week.createdAt = week.createdAt || nowStamp();
  week.updatedAt = week.updatedAt || nowStamp();
  week.teams = week.teams || {};
  ['team1','team2','team3'].forEach(team => { week.teams[team] = week.teams[team] || fresh.teams[team]; });

  const t1 = week.teams.team1;
  Object.assign(t1, {
    weeklySummary: t1.weeklySummary ?? fresh.teams.team1.weeklySummary,
    notes: t1.notes ?? '',
    dailyTasks: t1.dailyTasks || blankDaily(),
    concernsTitle: t1.concernsTitle || 'Team 1 Concerns',
    concerns: Array.isArray(t1.concerns) ? t1.concerns : [],
    systemsActivity: Array.isArray(t1.systemsActivity) ? t1.systemsActivity : [],
    tasksReceived: Array.isArray(t1.tasksReceived) ? t1.tasksReceived : [],
    ongoingTasks: Array.isArray(t1.ongoingTasks) ? t1.ongoingTasks : [],
    urgentTasks: Array.isArray(t1.urgentTasks) ? t1.urgentTasks : [],
    recoveredSystems: Array.isArray(t1.recoveredSystems) ? t1.recoveredSystems : [],
    systemsOutcomes: Array.isArray(t1.systemsOutcomes) ? t1.systemsOutcomes : [],
    jiraFrom: t1.jiraFrom || weekStart,
    jiraTo: t1.jiraTo || addDaysISO(weekStart,6),
    jiraRecords: Array.isArray(t1.jiraRecords) ? t1.jiraRecords : [],
    availability: Array.isArray(t1.availability) ? t1.availability : [],
    tnaRows: Array.isArray(t1.tnaRows) ? t1.tnaRows : [],
    personnelRows: Array.isArray(t1.personnelRows) ? t1.personnelRows : []
  });
  DAYS.forEach(d => t1.dailyTasks[d] = Array.isArray(t1.dailyTasks[d]) ? t1.dailyTasks[d] : []);

  const t2 = week.teams.team2;
  Object.assign(t2, {
    weeklySummary: t2.weeklySummary ?? fresh.teams.team2.weeklySummary,
    notes: t2.notes ?? '',
    dailyTasks: t2.dailyTasks || blankDaily(),
    tableRows: t2.tableRows || {},
    statsRows: Array.isArray(t2.statsRows) ? t2.statsRows : [],
    resultRows: Array.isArray(t2.resultRows) ? t2.resultRows : (Array.isArray(t2.resultsModules) ? t2.resultsModules.map(x => ({id:x.id || uid(), moduleName:x.moduleName || x.name || '', resultValue:number(x.resultValue ?? x.value)})) : []),
    systemRows: Array.isArray(t2.systemRows) ? t2.systemRows : (Array.isArray(t2.systemResults) ? t2.systemResults.map(x => ({id:x.id || uid(), systemName:x.systemName || x.name || '', count:number(x.count)})) : []),
    availability: Array.isArray(t2.availability) ? t2.availability : [],
    tnaRows: Array.isArray(t2.tnaRows) ? t2.tnaRows : [],
    personnelRows: Array.isArray(t2.personnelRows) ? t2.personnelRows : []
  });
  DAYS.forEach(d => t2.dailyTasks[d] = Array.isArray(t2.dailyTasks[d]) ? t2.dailyTasks[d] : []);
  ['team2Requested','team2Internal'].forEach(k => t2.tableRows[k] = Array.isArray(t2.tableRows[k]) ? t2.tableRows[k] : []);

  const t3 = week.teams.team3;
  Object.assign(t3, {
    weeklySummary: t3.weeklySummary ?? fresh.teams.team3.weeklySummary,
    notes: t3.notes ?? '',
    dailyInputs: Array.isArray(t3.dailyInputs) ? t3.dailyInputs : (Array.isArray(t3.bullets) ? t3.bullets : []),
    operations: t3.operations || { group1:[], group2:[] },
    tableRows: t3.tableRows || {},
    maintenanceEntries: Array.isArray(t3.maintenanceEntries) ? t3.maintenanceEntries : [],
    availability: Array.isArray(t3.availability) ? t3.availability : [],
    tnaRows: Array.isArray(t3.tnaRows) ? t3.tnaRows : [],
    personnelRows: Array.isArray(t3.personnelRows) ? t3.personnelRows : []
  });
  t3.operations.group1 = Array.isArray(t3.operations.group1) ? t3.operations.group1 : [];
  t3.operations.group2 = Array.isArray(t3.operations.group2) ? t3.operations.group2 : [];
  t3.tableRows.team3Log = Array.isArray(t3.tableRows.team3Log) ? t3.tableRows.team3Log : [];

  // Keep every flexible row compatible with current global columns.
  normalizeFlexRows(t2.tableRows.team2Requested, 'team2Requested');
  normalizeFlexRows(t2.tableRows.team2Internal, 'team2Internal');
  normalizeFlexRows(t3.tableRows.team3Log, 'team3Log');
  [t1,t2,t3].forEach(t => normalizeFlexRows(t.tnaRows, 'tna'));
  normalizeTaskReceivedRows(t1.tasksReceived);
  return week;
}

function normalizeFlexRows(rows, tableKey) {
  const cols = state?.global?.tables?.[tableKey] || [];
  rows.forEach(row => {
    row.id = row.id || uid();
    row.values = row.values || {};
    cols.forEach(col => { if (row.values[col.id] === undefined) row.values[col.id] = ''; });
  });
}
function normalizeTaskReceivedRows(rows) {
  const cols = state?.global?.tables?.team1TasksReceived || [];
  rows.forEach(row => { row.id = row.id || uid(); cols.forEach(col => { if (row[col.id] === undefined) row[col.id] = ''; }); });
}

function migrateState(input) {
  const base = input && typeof input === 'object' ? input : createDefaultState();
  if (!base.meta) base.meta = {};
  base.meta.currentWeekStart = base.meta.currentWeekStart || startOfWeekISO(todayISO());
  base.meta.theme = base.meta.theme === 'light' ? 'light' : 'dark';
  base.meta.collapsed = base.meta.collapsed || {};
  if (!base.weeks || typeof base.weeks !== 'object') base.weeks = {};
  ensureGlobalSettings(base);

  // Migrate old shape where teams were at root.
  const wk = startOfWeekISO(base.meta.currentWeekStart);
  if (!base.weeks[wk]) {
    if (base.teams) base.weeks[wk] = { createdAt: base.meta.createdAt || nowStamp(), updatedAt: base.meta.lastSaved || nowStamp(), teams: migrateLegacyTeams(base.teams) };
    else base.weeks[wk] = createEmptyWeek(wk);
  }
  // Move old team names into global only once.
  if (base.teams) {
    ['team1','team2','team3'].forEach(k => {
      const oldName = base.teams?.[k]?.name;
      if (oldName && !base.global.teamNames[k]) base.global.teamNames[k] = oldName;
      if (oldName && base.global.teamNames[k] === ({team1:'Team 1',team2:'Team 2',team3:'Team 3'}[k])) base.global.teamNames[k] = oldName;
    });
  }
  Object.keys(base.weeks).forEach(weekKey => ensureWeekSchema(base.weeks[weekKey], weekKey));
  delete base.teams; // prevent stale week-scoped settings from taking over
  return base;
}

function migrateLegacyTeams(teams) {
  const out = { team1:{}, team2:{}, team3:{} };
  if (teams.team1) {
    const t = teams.team1;
    out.team1 = {
      weeklySummary:t.weeklySummary || '', notes:t.notes || '', dailyTasks:t.dailyTasks || blankDaily(), concerns:t.concerns || [], concernsTitle:t.concernsTitle || 'Team 1 Concerns',
      systemsActivity:t.systemsActivity || [], tasksReceived:t.tasksReceived || [], ongoingTasks:t.ongoingTasks || [], urgentTasks:t.urgentTasks || [], recoveredSystems:t.recoveredSystems || [], systemsOutcomes:t.systemsOutcomes || [],
      jiraFrom:t.jiraFrom || currentWeekStart(), jiraTo:t.jiraTo || addDaysISO(currentWeekStart(),6), jiraRecords:t.jiraRecords || [], availability:t.availability || [],
      tnaRows:migrateLegacyFlexRows(t.tnaTable?.rows, t.tnaTable?.columns, 'tna'), personnelRows:migrateLegacyPersonnel(t.personnelTable)
    };
  }
  if (teams.team2) {
    const t = teams.team2;
    out.team2 = { weeklySummary:t.weeklySummary || '', notes:t.notes || '', dailyTasks:t.dailyTasks || blankDaily(), tableRows:{ team2Requested:migrateLegacyFlexRows(t.requestedTasksTable?.rows, t.requestedTasksTable?.columns, 'team2Requested'), team2Internal:migrateLegacyFlexRows(t.internalTaskTable?.rows, t.internalTaskTable?.columns, 'team2Internal') }, statsRows:t.statsRows || [], resultRows:t.resultsModules || t.resultRows || [], systemRows:t.systemResults || t.systemRows || [], availability:t.availability || [], tnaRows:migrateLegacyFlexRows(t.tnaTable?.rows, t.tnaTable?.columns, 'tna'), personnelRows:migrateLegacyPersonnel(t.personnelTable) };
  }
  if (teams.team3) {
    const t = teams.team3;
    out.team3 = { weeklySummary:t.weeklySummary || '', notes:t.notes || '', dailyInputs:t.dailyInputs || t.bullets || [], operations:t.operations || {group1:[], group2:[]}, tableRows:{team3Log:migrateLegacyFlexRows(t.logTable?.rows, t.logTable?.columns, 'team3Log')}, maintenanceEntries:t.maintenanceEntries || [], availability:t.availability || [], tnaRows:migrateLegacyFlexRows(t.tnaTable?.rows, t.tnaTable?.columns, 'tna'), personnelRows:migrateLegacyPersonnel(t.personnelTable) };
  }
  return out;
}
function migrateLegacyFlexRows(rows, legacyCols, tableKey) {
  if (!Array.isArray(rows)) return [];
  const currentCols = compactDefaultColumns()[tableKey] || [];
  return rows.map(row => {
    const values = {};
    currentCols.forEach((c, i) => {
      let val = '';
      if (row.values) {
        if (row.values[c.id] !== undefined) val = row.values[c.id];
        else if (legacyCols?.[i]?.id && row.values[legacyCols[i].id] !== undefined) val = row.values[legacyCols[i].id];
      }
      values[c.id] = val;
    });
    return { id: row.id || uid(), values };
  });
}
function migrateLegacyPersonnel(table) {
  if (!table?.rows) return [];
  const cols = table.columns || [];
  const find = (keywords, fallback) => cols.find(c => keywords.some(k => String(c.label||'').toLowerCase().includes(k))) || cols[fallback] || cols[0];
  const idCol = find(['id'], 0), nameCol = find(['name'], 1), roleCol = find(['role'], 2);
  return table.rows.map(row => ({ id: row.id || uid(), idValue: row.values?.[idCol?.id] || '', name: row.values?.[nameCol?.id] || '', role: row.values?.[roleCol?.id] || '' }));
}

function loadState() {
  try {
    let raw = storageGet(STORAGE_KEY);
    if (!raw) {
      for (const key of LEGACY_KEYS) { raw = storageGet(key); if (raw) break; }
    }
    if (!raw) return createDefaultState();
    const loaded = migrateState(JSON.parse(raw));
    return loaded;
  } catch (err) {
    /* Start clean if saved data is unavailable or invalid. */
    return createDefaultState();
  }
}
function saveState() {
  try {
    state.meta.lastSaved = nowStamp();
    state.weeks[currentWeekStart()] = ensureWeekSchema(state.weeks[currentWeekStart()] || createEmptyWeek(currentWeekStart()), currentWeekStart());
    storageSet(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    /* Keep dashboard usable even if localStorage is blocked. */
  }
  renderLastSaved();
  renderWeekSwitcher();
}

function activeWeek() { const wk = currentWeekStart(); state.weeks[wk] = ensureWeekSchema(state.weeks[wk] || createEmptyWeek(wk), wk); return state.weeks[wk]; }
function team(teamKey) { return activeWeek().teams[teamKey]; }
function teamDisplayName(teamKey) { return state.global.teamNames[teamKey] || ({team1:'Team 1',team2:'Team 2',team3:'Team 3'}[teamKey] || teamKey); }
function updateTeamName(teamKey, value) { state.global.teamNames[teamKey] = safeText(value) || ({team1:'Team 1',team2:'Team 2',team3:'Team 3'}[teamKey] || teamKey); saveState(); renderNavLabels(); }
function getLabel(scope, key, fallback) { state.global.labels[scope] = state.global.labels[scope] || {}; return state.global.labels[scope][key] ?? fallback; }
function updateLabel(scope, key, value) { state.global.labels[scope] = state.global.labels[scope] || {}; state.global.labels[scope][key] = value; saveState(); }
function labelWidthStyle(value) { return `--label-width:${clamp(String(value||'').length + 3, 12, 86)}ch`; }
function labelInput(scope, key, fallback, extraClass='') { const value = getLabel(scope, key, fallback); return `<input class="label-input subject-label ${extraClass}" value="${esc(value)}" style="${labelWidthStyle(value)}" oninput="updateLabel('${scope}','${key}',this.value);this.style.setProperty('--label-width', Math.max(12, Math.min(86, this.value.length + 3)) + 'ch')" title="Rename label">`; }
function thLabel(scope, key, fallback) { const value = getLabel(scope, key, fallback); return `<textarea class="th-label-input th-label-textarea" rows="1" oninput="updateLabel('${scope}','${key}',this.value);autoFitHeader(this)" title="Rename column">${esc(value)}</textarea>`; }

function applyTheme() { const light = state.meta.theme === 'light'; document.body.classList.toggle('theme-light', light); document.body.classList.toggle('theme-dark', !light); }
function toggleTheme() { state.meta.theme = state.meta.theme === 'light' ? 'dark' : 'light'; saveState(); render(); }
function renderThemeToggle() { const b = document.getElementById('themeToggleBtn'); if (b) b.textContent = state.meta.theme === 'light' ? 'Dark Theme' : 'Light Theme'; }
function renderLastSaved() { const el = document.getElementById('lastSavedLabel'); if (el) el.textContent = 'Auto-saved locally: ' + (state.meta.lastSaved || 'not yet saved'); }
function renderNavLabels() { ['team1','team2','team3'].forEach(k => { const b = document.getElementById('nav-' + k); if (b) b.textContent = teamDisplayName(k); }); }

function showView(view) {
  currentView = view;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const target = document.getElementById(view);
  if (target) target.classList.add('active');
  render();
  try { window.scrollTo({top:0, behavior:'smooth'}); } catch { window.scrollTo(0,0); }
}
function render() {
  activeWeek();
  applyTheme(); renderThemeToggle(); renderLastSaved(); renderWeekSwitcher(); renderNavLabels();
  renderHome();
  if (currentView === 'team1') renderTeam1();
  if (currentView === 'team2') renderTeam2();
  if (currentView === 'team3') renderTeam3();
  if (currentView === 'overview') renderOverview();
  requestAnimationFrame(() => { autoGrowAll(); polishDeleteButtons(); });
}
function preserveScrollRender(fn) { const x = window.scrollX || 0, y = window.scrollY || 0; fn(); requestAnimationFrame(() => window.scrollTo(x, y)); }
function renderCurrentViewPreservingScroll() { preserveScrollRender(render); }
function autoGrow(el) { if (!el) return; el.style.height = 'auto'; el.style.height = Math.max(el.scrollHeight, 38) + 'px'; }
function autoGrowAll() { document.querySelectorAll('textarea.auto-grow').forEach(autoGrow); document.querySelectorAll('textarea.th-label-textarea').forEach(autoFitHeader); }
function autoFitHeader(el) {
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = Math.max(el.scrollHeight, 34) + 'px';
  const text = String(el.value || el.placeholder || '');
  const longest = text.split(/\s+/).reduce((m,w)=>Math.max(m,w.length),0);
  const target = Math.max(118, Math.min(360, Math.max(text.length * 7.6 + 30, longest * 9 + 30)));
  el.style.width = target + 'px';
  el.style.minWidth = target + 'px';
  const th = el.closest('th');
  if (th) { th.style.minWidth = (target + 16) + 'px'; th.style.width = (target + 16) + 'px'; }
}
function polishDeleteButtons(root=document) { root.querySelectorAll('button.btn.danger').forEach(btn => { btn.classList.add('trash-btn'); btn.setAttribute('title', btn.getAttribute('title') || 'Delete'); btn.setAttribute('aria-label', btn.getAttribute('aria-label') || 'Delete'); btn.innerHTML = '🗑'; }); }

function renderWeekSwitcher() {
  const el = document.getElementById('weekSwitcher'); if (!el) return;
  const start = currentWeekStart();
  el.innerHTML = `<button class="btn small" onclick="changeWeek(-1)">← Previous</button><div class="week-chip"><span>Selected Week</span><strong>${esc(currentWeekLabel())}</strong></div><button class="btn small" onclick="changeWeek(1)">Next →</button><button class="btn small ghost" onclick="goToThisWeek()">This Week</button><input class="input week-date-input" type="date" value="${esc(start)}" onchange="selectWeekByDate(this.value)" title="Jump to week">`;
}
function changeWeek(offset) { openWeek(addDaysISO(currentWeekStart(), offset * 7)); }
function goToThisWeek() { openWeek(startOfWeekISO(todayISO())); }
function selectWeekByDate(value) { if (value) openWeek(value); }
function cloneWeekForTarget(sourceWeek, sourceStart, targetStart) {
  const clone = JSON.parse(JSON.stringify(sourceWeek));
  const deltaDays = Math.round((parseISODate(targetStart) - parseISODate(sourceStart)) / 86400000);
  const shiftIso = value => /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) ? addDaysISO(value, deltaDays) : value;
  const walk = obj => {
    if (!obj || typeof obj !== 'object') return;
    Object.keys(obj).forEach(key => {
      const value = obj[key];
      if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) obj[key] = shiftIso(value);
      else if (value && typeof value === 'object') walk(value);
    });
  };
  walk(clone);
  clone.createdAt = nowStamp();
  clone.updatedAt = nowStamp();
  return ensureWeekSchema(clone, targetStart);
}
function openWeek(weekStart) {
  const sourceStart = currentWeekStart();
  const targetStart = startOfWeekISO(weekStart);
  if (!state.weeks[targetStart]) {
    const sourceWeek = state.weeks[sourceStart] || activeWeek();
    state.weeks[targetStart] = cloneWeekForTarget(sourceWeek, sourceStart, targetStart);
  }
  state.meta.currentWeekStart = targetStart;
  activeWeek();
  saveState();
  render();
}

function pageTitle(title, subtitle, actions='') { return `<div class="page-title"><div><h2>${esc(title)}</h2></div><div class="pill-row">${actions}</div></div>`; }
function teamPageTitle(teamKey, actions='') { const name = teamDisplayName(teamKey); return `<div class="page-title"><div><h2><input class="label-input subject-label team-name-input" value="${esc(name)}" style="${labelWidthStyle(name)}" oninput="updateTeamName('${teamKey}',this.value);this.style.setProperty('--label-width', Math.max(12, Math.min(86, this.value.length + 3)) + 'ch')" title="Rename team"></h2></div><div class="pill-row">${actions}</div></div>`; }
function reportButtons(target) { return `<div class="report-actions"><button class="btn small" onclick="exportWord('${target}')">Export Word</button><button class="btn small" onclick="printDashboard()">Export / Print PDF</button>${target !== 'overview' ? `<button class="btn small primary" onclick="showView('overview')">Open Overview</button>` : ''}</div>`; }
function addButton(label, onclick, cls='') { return `<button type="button" class="btn small add-btn ${cls}" onclick="${onclick}" title="${esc(label)}" aria-label="${esc(label)}"></button>`; }
function refreshButton(target='') { return `<button type="button" class="btn small refresh-btn" onclick="refreshGraphs('${target}')" title="Refresh"><span class="sr-only">Refresh</span></button>`; }
function sectionCard(id, titleHtml, subtitle, actions, body, extraClass='') {
  const collapsed = state.meta.collapsed?.[id] ? ' is-collapsed' : '';
  return `<div class="card section ${extraClass}${collapsed}" id="${esc(id)}"><div class="card-head wrap"><div><h3>${titleHtml}</h3></div><div class="section-tools">${actions || ''}<button type="button" class="collapse-btn" onclick="toggleCollapse('${id}')" title="Collapse / expand" aria-label="Collapse / expand"></button></div></div>${body}</div>`;
}
function toggleCollapse(id) { state.meta.collapsed = state.meta.collapsed || {}; state.meta.collapsed[id] = !state.meta.collapsed[id]; saveState(); const el = document.getElementById(id); if (el) el.classList.toggle('is-collapsed', state.meta.collapsed[id]); }

function renderHome() {
  const el = document.getElementById('home'); if (!el) return;
  el.innerHTML = `<div class="hero"><h2>Weekly command center for offline team updates.</h2><div class="pill-row" style="margin-top:18px"><span class="pill"><span class="dot good"></span>Offline</span><span class="pill"><span class="dot"></span>Auto-save</span><span class="pill"><span class="dot warn"></span>Week history</span></div></div><div class="grid team-grid">${homeCard(teamDisplayName('team1'),'','team1')}${homeCard(teamDisplayName('team2'),'','team2')}${homeCard(teamDisplayName('team3'),'','team3')}${homeCard('Overview','','overview', true)}</div>`;
}
function homeCard(title, body, view, primary=false) { return `<div class="card team-card"><div><h3>${esc(title)}</h3></div><button class="btn ${primary ? 'primary' : ''}" onclick="showView('${view}')">Open ${esc(title)}</button></div>`; }

function renderEditableSummary(teamKey) {
  const t = team(teamKey);
  return `<div class="grid two section"><div class="card"><div class="card-head"><h3>${labelInput(teamKey,'weeklySummaryTitle','Weekly Summary')}</h3></div><textarea class="auto-grow" oninput="updateTeamField('${teamKey}','weeklySummary',this.value);autoGrow(this)">${esc(t.weeklySummary)}</textarea></div><div class="card"><div class="card-head"><h3>${labelInput(teamKey,'teamNotesTitle','Team Notes')}</h3></div><textarea class="auto-grow" oninput="updateTeamField('${teamKey}','notes',this.value);autoGrow(this)">${esc(t.notes)}</textarea></div></div>`;
}
function updateTeamField(teamKey, field, value) { team(teamKey)[field] = value; saveState(); }

function renderTeam1() {
  const el = document.getElementById('team1'); if (!el) return;
  el.innerHTML = `${teamPageTitle('team1', reportButtons('team1'))}${renderEditableSummary('team1')}${renderTeam1Charts()}${renderTeam1DailyTasks()}${renderTeam1Concerns()}${renderSystemsActivity()}${renderTeam1TasksReceived()}${renderTeam1TaskLists()}${renderSystemsOutcomes()}${renderJiraSection()}${renderAvailability('team1')}`;
}
function renderTeam1Charts() {
  return `<div class="grid two section analytics-split"><div class="card top-analytics-card"><div class="chart-card-head"><div>${labelInput('team1','chart.tasksTitle','Tasks Received / Recovered')}</div><div class="chart-tools"><button class="btn small" onclick="openChartModal('tasks')">Bigger</button>${refreshButton('tasks')}</div></div><div class="chart-box">${renderTasksChart()}</div></div><div class="card top-analytics-card"><div class="chart-card-head"><div>${labelInput('team1','chart.jiraTitle','Jira Total / Recovered')}</div><div class="chart-tools"><button class="btn small" onclick="openChartModal('jira')">Bigger</button>${refreshButton('jira')}</div></div><div class="chart-box">${renderJiraChart()}</div></div></div>`;
}
function renderTeam1DailyTasks() {
  const t = team('team1');
  const body = `<div class="grid day-grid">${DAYS.map(day => `<div class="card day-card"><div class="card-head"><h3>${esc(day)}</h3>${addButton('Add daily task', `addDailyTask('${day}')`)}</div>${(t.dailyTasks[day] || []).map(e => `<div class="entry"><div class="entry-meta"><span>Created: ${esc(e.createdAt)}</span>${e.updatedAt ? `<span>Updated: ${esc(e.updatedAt)}</span>` : ''}</div><textarea class="auto-grow daily-task-textarea" oninput="updateDailyTask('${day}','${e.id}',this.value);autoGrow(this)">${esc(e.text)}</textarea><div style="margin-top:8px"><button class="btn small danger" onclick="deleteDailyTask('${day}','${e.id}')"></button></div></div>`).join('') || '<div class="empty">No entries yet.</div>'}</div>`).join('')}</div>`;
  return sectionCard('team1-daily', labelInput('team1','section.dailyTasks','1.1 Daily Tasks'), 'Each weekday supports timestamped entries.', '', body);
}
function addDailyTask(day) { team('team1').dailyTasks[day].push({id:uid(), text:'', createdAt:nowStamp(), updatedAt:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateDailyTask(day, id, value) { const item = team('team1').dailyTasks[day].find(x => x.id === id); if (!item) return; item.text = value; item.updatedAt = nowStamp(); saveState(); }
function deleteDailyTask(day, id) { team('team1').dailyTasks[day] = team('team1').dailyTasks[day].filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderTeam1Concerns() {
  const t = team('team1');
  const body = `<div class="concern-list">${t.concerns.map(c => `<div class="entry concern-entry"><span class="concern-dot"></span><input class="concern-line-input" value="${esc(c.text)}" oninput="updateConcern('${c.id}',this.value)" placeholder="Write concern here"><span class="concern-time">${esc(c.updatedAt ? 'Updated: ' + c.updatedAt : 'Created: ' + c.createdAt)}</span><div class="concern-actions"><button class="btn small danger" onclick="deleteArrayItem('team1','concerns','${c.id}')"></button></div></div>`).join('') || '<div class="empty">No concerns added.</div>'}</div>`;
  return sectionCard('team1-concerns', labelInput('team1','section.concerns','Team 1 Concerns'), '', addButton('Add concern', 'addConcern()'), body, 'concern-card');
}
function addConcern() { team('team1').concerns.push({id:uid(), text:'', createdAt:nowStamp(), updatedAt:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateConcern(id, value) { const c = team('team1').concerns.find(x => x.id === id); if (!c) return; c.text = value; c.updatedAt = nowStamp(); saveState(); }

function renderSystemsActivity() {
  const rows = team('team1').systemsActivity;
  const body = `<div class="table-wrap comfort-table-wrap"><table class="comfort-table"><thead><tr><th>${thLabel('team1','systems.systemName','System Name')}</th><th>${thLabel('team1','systems.description','Description')}</th><th>${thLabel('team1','systems.active','Machines Active')}</th><th>${thLabel('team1','systems.inactive','Machines Inactive')}</th><th>${thLabel('team1','systems.status','Status')}</th><th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(r => `<tr><td><input class="cell-input" value="${esc(r.systemName)}" oninput="updateTeam1Array('systemsActivity','${r.id}','systemName',this.value)"></td><td><input class="cell-input" value="${esc(r.description)}" oninput="updateTeam1Array('systemsActivity','${r.id}','description',this.value)"></td><td><input class="cell-input cell-small" type="number" value="${esc(r.active)}" oninput="updateTeam1Array('systemsActivity','${r.id}','active',this.value,true)" onchange="renderCurrentViewPreservingScroll()"></td><td><input class="cell-input cell-small" type="number" value="${esc(r.inactive)}" oninput="updateTeam1Array('systemsActivity','${r.id}','inactive',this.value,true)" onchange="renderCurrentViewPreservingScroll()"></td><td>${machineStatusBadge(r.active,r.inactive)}</td><td class="action-col"><button class="btn small danger" onclick="deleteArrayItem('team1','systemsActivity','${r.id}')"></button></td></tr>`).join('') || `<tr><td colspan="6"><div class="empty">No systems added.</div></td></tr>`}</tbody></table></div>`;
  return sectionCard('team1-systems', labelInput('team1','section.systems','1.3 Systems / Machines Activity'), 'Status updates from active/inactive machine counts.', addButton('Add system','addSystemActivity()'), body, 'wide-table-card');
}
function machineStatusBadge(active, inactive) { active=number(active); inactive=number(inactive); if (active>0 && inactive===0) return '<span class="status-badge status-good"><span class="dot good"></span>All Active</span>'; if (inactive>0 && active===0) return '<span class="status-badge status-bad"><span class="dot bad"></span>Inactive</span>'; if (active>0 && inactive>0) return '<span class="status-badge status-warn"><span class="dot warn"></span>Partial</span>'; return '<span class="status-badge"><span class="dot"></span>No Data</span>'; }
function addSystemActivity() { team('team1').systemsActivity.push({id:uid(), systemName:'', description:'', active:0, inactive:0}); saveState(); renderCurrentViewPreservingScroll(); }
function updateTeam1Array(arrayName, id, field, value, numeric=false) { const item = team('team1')[arrayName].find(x => x.id === id); if (!item) return; item[field] = numeric ? number(value) : value; saveState(); }

function renderTeam1TasksReceived() {
  const cols = state.global.tables.team1TasksReceived;
  const rows = team('team1').tasksReceived;
  const body = `<div class="table-wrap comfort-table-wrap"><table class="tasks-received-table"><thead><tr>${cols.map(col => `<th>${thLabel('team1','tasksReceived.'+col.id,col.label)}</th>`).join('')}<th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(row => `<tr>${cols.map(col => `<td>${renderTaskReceivedCell(row, col)}</td>`).join('')}<td class="action-col"><button class="btn small danger" onclick="deleteArrayItem('team1','tasksReceived','${row.id}')"></button></td></tr>`).join('') || `<tr><td colspan="${cols.length+1}"><div class="empty">No rows added.</div></td></tr>`}</tbody></table></div>`;
  return sectionCard('team1-tasks-received', labelInput('team1','section.tasksReceived','A. Tasks Received This Week'), 'Manual typing only. Date and number columns keep native input types.', addButton('Add row','addTaskReceived()'), body, 'wide-table-card');
}
function renderTaskReceivedCell(row, col) { const type = col.type === 'date' ? 'date' : (col.type === 'number' ? 'number' : 'text'); return `<input class="cell-input ${type==='number'?'cell-small':''}" type="${type}" value="${esc(row[col.id] ?? '')}" oninput="updateTaskReceived('${row.id}','${col.id}',this.value,'${type}')">`; }
function addTaskReceived() { const row = {id:uid()}; state.global.tables.team1TasksReceived.forEach(c => row[c.id] = c.type === 'date' ? todayISO() : (c.type === 'number' ? 0 : '')); team('team1').tasksReceived.push(row); saveState(); renderCurrentViewPreservingScroll(); }
function updateTaskReceived(id, field, value, type) { const row = team('team1').tasksReceived.find(x => x.id === id); if (!row) return; row[field] = type === 'number' ? number(value) : value; saveState(); }

function renderTeam1TaskLists() {
  return `<div class="grid three section">${renderSmallList('team1','ongoingTasks','section.ongoing','B. Ongoing Tasks',['name','owner','status','progress'])}${renderSmallList('team1','urgentTasks','section.urgent','C. Urgent Tasks',['name','deadline','owner','status','progress'])}${renderSmallList('team1','recoveredSystems','section.recovered','D. Recovered Systems',['systemName','recoveredCount','date','notes'])}</div>`;
}
function fieldLabel(field) { return ({name:'Name',owner:'Owner',status:'Status',progress:'Progress %',deadline:'Deadline',systemName:'System Name',recoveredCount:'Recovered Count',date:'Date',notes:'Notes'}[field] || field); }
function renderSmallList(teamKey, arrayName, titleKey, title, fields) {
  const rows = team(teamKey)[arrayName] || [];
  return `<div class="card"><div class="card-head"><h3>${labelInput(teamKey,titleKey,title)}</h3>${addButton('Add', `addSmallListItem('${teamKey}','${arrayName}')`)}</div>${rows.map(r => `<div class="entry">${fields.map(f => smallField(teamKey,arrayName,r,f)).join('')}<button style="margin-top:8px" class="btn small danger" onclick="deleteArrayItem('${teamKey}','${arrayName}','${r.id}')"></button></div>`).join('') || '<div class="empty">No rows yet.</div>'}</div>`;
}
function smallField(teamKey, arrayName, row, field) { const type = ['progress','recoveredCount'].includes(field) ? 'number' : (['deadline','date'].includes(field) ? 'date' : 'text'); return `<label class="subtle">${esc(fieldLabel(field))}<input class="input" type="${type}" value="${esc(row[field] ?? '')}" oninput="updateArrayItem('${teamKey}','${arrayName}','${row.id}','${field}',this.value,'${type}')"></label>`; }
function addSmallListItem(teamKey, arrayName) { const defaults = {ongoingTasks:{name:'',owner:'',status:'',progress:0},urgentTasks:{name:'',deadline:todayISO(),owner:'',status:'',progress:0},recoveredSystems:{systemName:'',recoveredCount:0,date:todayISO(),notes:''}}; team(teamKey)[arrayName].push({id:uid(), ...(defaults[arrayName] || {})}); saveState(); renderCurrentViewPreservingScroll(); }

function renderSystemsOutcomes() {
  const rows = team('team1').systemsOutcomes;
  const body = `<div class="grid three">${rows.map(r => `<div class="card"><div class="card-head"><input class="input" value="${esc(r.systemName || '')}" oninput="updateTeam1Array('systemsOutcomes','${r.id}','systemName',this.value)"><button class="btn small danger" onclick="deleteArrayItem('team1','systemsOutcomes','${r.id}')"></button></div><textarea class="auto-grow" oninput="updateTeam1Array('systemsOutcomes','${r.id}','statusLine',this.value);autoGrow(this)">${esc(r.statusLine || '')}</textarea><div class="metric-strip"><div class="mini-metric"><input class="input" type="number" value="${esc(r.activeTasks||0)}" oninput="updateTeam1Array('systemsOutcomes','${r.id}','activeTasks',this.value,true)"><span>Active</span></div><div class="mini-metric"><input class="input" type="number" value="${esc(r.pending||0)}" oninput="updateTeam1Array('systemsOutcomes','${r.id}','pending',this.value,true)"><span>Pending</span></div><div class="mini-metric"><input class="input" type="number" value="${esc(r.completed||0)}" oninput="updateTeam1Array('systemsOutcomes','${r.id}','completed',this.value,true)"><span>Completed</span></div></div></div>`).join('') || '<div class="empty">No system outcomes yet.</div>'}</div>`;
  return sectionCard('team1-outcomes', labelInput('team1','section.outcomes','1.5 Systems Outcomes'), 'Editable outcome cards.', addButton('Add system','addSystemOutcome()'), body);
}
function addSystemOutcome() { team('team1').systemsOutcomes.push({id:uid(), systemName:'', statusLine:'', activeTasks:0, pending:0, completed:0}); saveState(); renderCurrentViewPreservingScroll(); }

function renderJiraSection() {
  const t = team('team1');
  const rows = t.jiraRecords;
  const body = `<div class="grid two"><label class="subtle">${labelInput('team1','jira.fromFilter','From Date')}<input class="input" type="date" value="${esc(t.jiraFrom)}" oninput="t1Set('jiraFrom',this.value)" onchange="renderCurrentViewPreservingScroll()"></label><label class="subtle">${labelInput('team1','jira.toFilter','To Date')}<input class="input" type="date" value="${esc(t.jiraTo)}" oninput="t1Set('jiraTo',this.value)" onchange="renderCurrentViewPreservingScroll()"></label></div><div class="table-wrap comfort-table-wrap" style="margin-top:12px"><table class="jira-table"><thead><tr><th>${thLabel('team1','jira.from','From Date')}</th><th>${thLabel('team1','jira.to','To Date')}</th><th>${thLabel('team1','jira.total','Total Tasks Count')}</th><th>${thLabel('team1','jira.recovered','Recovered Tasks Count')}</th><th>${thLabel('team1','jira.notes','Notes')}</th><th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(r => `<tr><td><input class="cell-input" type="date" value="${esc(r.from)}" oninput="updateJira('${r.id}','from',this.value)"></td><td><input class="cell-input" type="date" value="${esc(r.to)}" oninput="updateJira('${r.id}','to',this.value)"></td><td><input class="cell-input" type="number" value="${esc(r.totalTasks)}" oninput="updateJira('${r.id}','totalTasks',this.value,true)"></td><td><input class="cell-input" type="number" value="${esc(r.recoveredTasks)}" oninput="updateJira('${r.id}','recoveredTasks',this.value,true)"></td><td><input class="cell-input" value="${esc(r.notes||'')}" oninput="updateJira('${r.id}','notes',this.value)"></td><td class="action-col"><button class="btn small danger" onclick="deleteArrayItem('team1','jiraRecords','${r.id}')"></button></td></tr>`).join('') || '<tr><td colspan="6"><div class="empty">No Jira records.</div></td></tr>'}</tbody></table></div>`;
  return sectionCard('team1-jira', labelInput('team1','section.jira','1.6 Jira Inputs / Range Data'), 'Charts use this selected date range.', addButton('Add range','addJiraRecord()'), body, 'wide-table-card');
}
function t1Set(field, value) { team('team1')[field] = value; saveState(); }
function addJiraRecord() { team('team1').jiraRecords.push({id:uid(), from:todayISO(), to:todayISO(), totalTasks:0, recoveredTasks:0, notes:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateJira(id, field, value, numeric=false) { const r = team('team1').jiraRecords.find(x => x.id === id); if (!r) return; r[field] = numeric ? number(value) : value; saveState(); }

function renderTeam2() {
  const el = document.getElementById('team2'); if (!el) return;
  el.innerHTML = `${teamPageTitle('team2', reportButtons('team2'))}${renderEditableSummary('team2')}${renderDailyEntries('team2','2.1 Daily Tasks')}${renderFlexTable('team2','team2Requested','team2.requestedTitle','2.2 Requested Tasks Table','')}${renderTeam2Stats()}${renderTeam2Results()}${renderTeam2SystemGraph()}${renderFlexTable('team2','team2Internal','team2.internalTitle','2.6 Internal Task Table','')}${renderAvailability('team2')}`;
}
function renderDailyEntries(teamKey, fallbackTitle) {
  const t = team(teamKey);
  const body = `<div class="grid day-grid">${DAYS.map(day => `<div class="card day-card"><div class="card-head"><h3>${esc(day)}</h3>${addButton('Add entry', `addTeamDailyEntry('${teamKey}','${day}')`)}</div>${(t.dailyTasks[day] || []).map(e => `<div class="entry"><div class="entry-meta"><span>Created: ${esc(e.createdAt)}</span>${e.updatedAt ? `<span>Updated: ${esc(e.updatedAt)}</span>` : ''}</div><textarea class="auto-grow daily-task-textarea" oninput="updateTeamDailyEntry('${teamKey}','${day}','${e.id}',this.value);autoGrow(this)">${esc(e.text)}</textarea><div style="margin-top:8px"><button class="btn small danger" onclick="deleteTeamDailyEntry('${teamKey}','${day}','${e.id}')"></button></div></div>`).join('') || '<div class="empty">No entries yet.</div>'}</div>`).join('')}</div>`;
  return sectionCard(`${teamKey}-daily`, labelInput(teamKey,'section.dailyTasks',fallbackTitle), 'Weekday daily entries.', '', body);
}
function addTeamDailyEntry(teamKey, day) { team(teamKey).dailyTasks[day].push({id:uid(), text:'', createdAt:nowStamp(), updatedAt:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateTeamDailyEntry(teamKey, day, id, value) { const item = team(teamKey).dailyTasks[day].find(x => x.id === id); if (!item) return; item.text = value; item.updatedAt = nowStamp(); saveState(); }
function deleteTeamDailyEntry(teamKey, day, id) { team(teamKey).dailyTasks[day] = team(teamKey).dailyTasks[day].filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderFlexTable(teamKey, tableKey, titleKey, fallbackTitle, subtitle) {
  const rows = getTableRows(teamKey, tableKey);
  const cols = state.global.tables[tableKey];
  const body = `<div class="table-wrap comfort-table-wrap"><table class="flexible-wide-table"><thead><tr>${cols.map(col => `<th class="flex-th"><div class="flex-th-row"><textarea class="th-label-input th-label-textarea" rows="1" oninput="updateFlexColumn('${tableKey}','${col.id}','label',this.value);autoFitHeader(this)">${esc(col.label)}</textarea><button class="remove-col-btn" onclick="deleteFlexColumn('${tableKey}','${col.id}')" title="Remove column">×</button></div></th>`).join('')}<th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(row => `<tr>${cols.map(col => `<td>${renderFlexCell(teamKey, tableKey, row, col)}</td>`).join('')}<td class="action-col"><button class="btn small danger" onclick="deleteFlexRow('${teamKey}','${tableKey}','${row.id}')"></button></td></tr>`).join('') || `<tr><td colspan="${cols.length+1}"><div class="empty">No rows yet.</div></td></tr>`}</tbody></table></div>`;
  return sectionCard(`${teamKey}-${tableKey}`, labelInput(teamKey,titleKey,fallbackTitle), subtitle, `${addButton('Add row', `addFlexRow('${teamKey}','${tableKey}')`)}${addButton('Add column', `addFlexColumn('${tableKey}')`)}`, body, 'wide-table-card');
}
function getTableRows(teamKey, tableKey) {
  const t = team(teamKey);
  if (tableKey === 'tna') return t.tnaRows;
  if (!t.tableRows) t.tableRows = {};
  t.tableRows[tableKey] = t.tableRows[tableKey] || [];
  normalizeFlexRows(t.tableRows[tableKey], tableKey);
  return t.tableRows[tableKey];
}
function renderFlexCell(teamKey, tableKey, row, col) { const type = col.type === 'date' ? 'date' : (col.type === 'number' ? 'number' : 'text'); return `<input class="cell-input ${type==='number'?'cell-small':''}" type="${type}" value="${esc(row.values?.[col.id] ?? '')}" oninput="updateFlexCell('${teamKey}','${tableKey}','${row.id}','${col.id}',this.value,'${type}')">`; }
function addFlexRow(teamKey, tableKey) { const values = {}; state.global.tables[tableKey].forEach(c => values[c.id] = c.type === 'date' ? todayISO() : (c.type === 'number' ? 0 : '')); getTableRows(teamKey, tableKey).push({id:uid(), values}); saveState(); renderCurrentViewPreservingScroll(); }
function deleteFlexRow(teamKey, tableKey, rowId) { const rows = getTableRows(teamKey, tableKey); const filtered = rows.filter(r => r.id !== rowId); if (tableKey === 'tna') team(teamKey).tnaRows = filtered; else team(teamKey).tableRows[tableKey] = filtered; saveState(); renderCurrentViewPreservingScroll(); }
function updateFlexCell(teamKey, tableKey, rowId, colId, value, type) { const row = getTableRows(teamKey, tableKey).find(r => r.id === rowId); if (!row) return; row.values = row.values || {}; row.values[colId] = type === 'number' ? number(value) : value; saveState(); }
function addFlexColumn(tableKey) { const label = 'New Column'; const id = 'col_' + uid(); state.global.tables[tableKey].push({id,label,type:'text'}); Object.values(state.weeks).forEach(w => ['team1','team2','team3'].forEach(k => { const t = w.teams?.[k]; if (!t) return; const rows = tableKey === 'tna' ? t.tnaRows : t.tableRows?.[tableKey]; if (Array.isArray(rows)) rows.forEach(r => { r.values = r.values || {}; r.values[id] = ''; }); })); saveState(); renderCurrentViewPreservingScroll(); }
function updateFlexColumn(tableKey, colId, field, value) { const col = state.global.tables[tableKey].find(c => c.id === colId); if (!col) return; col[field] = field === 'type' ? validType(value) : value; saveState(); }
function deleteFlexColumn(tableKey, colId) { const cols = state.global.tables[tableKey]; if (cols.length <= 1) { alert('At least one column is required.'); return; } state.global.tables[tableKey] = cols.filter(c => c.id !== colId); Object.values(state.weeks).forEach(w => ['team1','team2','team3'].forEach(k => { const t = w.teams?.[k]; const rows = tableKey === 'tna' ? t?.tnaRows : t?.tableRows?.[tableKey]; if (Array.isArray(rows)) rows.forEach(r => { if (r.values) delete r.values[colId]; }); })); saveState(); renderCurrentViewPreservingScroll(); }

function renderTeam2Stats() {
  const rows = team('team2').statsRows;
  const body = `<div class="chart-box">${renderTeam2StatsChart()}</div><div class="table-wrap comfort-table-wrap" style="margin-top:12px"><table class="comfort-table"><thead><tr><th>${thLabel('team2','stats.period','Period')}</th><th>${thLabel('team2','stats.i1r','Input 1 Received')}</th><th>${thLabel('team2','stats.i1a','Input 1 Analyzed')}</th><th>${thLabel('team2','stats.i2r','Input 2 Received')}</th><th>${thLabel('team2','stats.i2a','Input 2 Analyzed')}</th><th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(r => `<tr><td><input class="cell-input" value="${esc(r.period)}" oninput="updateStats('${r.id}','period',this.value)"></td><td><input class="cell-input" type="number" value="${esc(r.input1Received)}" oninput="updateStats('${r.id}','input1Received',this.value,true)"></td><td><input class="cell-input" type="number" value="${esc(r.input1Analyzed)}" oninput="updateStats('${r.id}','input1Analyzed',this.value,true)"></td><td><input class="cell-input" type="number" value="${esc(r.input2Received)}" oninput="updateStats('${r.id}','input2Received',this.value,true)"></td><td><input class="cell-input" type="number" value="${esc(r.input2Analyzed)}" oninput="updateStats('${r.id}','input2Analyzed',this.value,true)"></td><td class="action-col"><button class="btn small danger" onclick="deleteStats('${r.id}')"></button></td></tr>`).join('') || '<tr><td colspan="6"><div class="empty">No statistics rows.</div></td></tr>'}</tbody></table></div>`;
  return sectionCard('team2-stats', labelInput('team2','team2.statsTitle','2.3 Statistics - Graph'), 'Received vs analyzed per period.', `${addButton('Add period','addStatsRow()')}<button class="btn small" onclick="openAnyChartModal('team2Stats')">Bigger</button>${refreshButton('team2Stats')}`, body, 'wide-table-card');
}
function addStatsRow() { team('team2').statsRows.push({id:uid(), period:'', input1Received:0, input1Analyzed:0, input2Received:0, input2Analyzed:0}); saveState(); renderCurrentViewPreservingScroll(); }
function updateStats(id, field, value, numeric=false) { const r = team('team2').statsRows.find(x => x.id === id); if (!r) return; r[field] = numeric ? number(value) : value; saveState(); }
function deleteStats(id) { team('team2').statsRows = team('team2').statsRows.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderTeam2Results() {
  const rows = team('team2').resultRows;
  const body = `<div class="grid two"><div class="chart-box wide-name-chart-box">${renderWideNameChart(rows.map(r => ({label:r.moduleName, value:number(r.resultValue)})))}</div><div>${rows.map(r => `<div class="entry"><div class="grid two"><input class="input" value="${esc(r.moduleName||'')}" oninput="updateResult('${r.id}','moduleName',this.value)"><input class="input" type="number" value="${esc(r.resultValue||0)}" oninput="updateResult('${r.id}','resultValue',this.value,true)"></div><button style="margin-top:8px" class="btn small danger" onclick="deleteResult('${r.id}')"></button></div>`).join('') || '<div class="empty">No results yet.</div>'}</div></div>`;
  return sectionCard('team2-results', labelInput('team2','team2.resultsTitle','2.4 Name Results - Chart'), 'Full names are shown beside horizontal bars.', `${addButton('Add result','addResult()')}<button class="btn small" onclick="openAnyChartModal('team2Results')">Bigger</button>${refreshButton('team2Results')}`, body);
}
function addResult() { team('team2').resultRows.push({id:uid(), moduleName:'', resultValue:0}); saveState(); renderCurrentViewPreservingScroll(); }
function updateResult(id, field, value, numeric=false) { const r = team('team2').resultRows.find(x => x.id === id); if (!r) return; r[field] = numeric ? number(value) : value; saveState(); }
function deleteResult(id) { team('team2').resultRows = team('team2').resultRows.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderTeam2SystemGraph() {
  const rows = team('team2').systemRows;
  const body = `<div class="grid two team2-system-layout"><div class="chart-box wide-name-chart-box">${renderWideNameChart(rows.map(r => ({label:r.systemName, value:number(r.count)})))}</div><div>${rows.map(r => `<div class="entry"><div class="grid two"><input class="input" value="${esc(r.systemName||'')}" oninput="updateSystemResult('${r.id}','systemName',this.value)"><input class="input" type="number" value="${esc(r.count||0)}" oninput="updateSystemResult('${r.id}','count',this.value,true)"></div><button style="margin-top:8px" class="btn small danger" onclick="deleteSystemResult('${r.id}')"></button></div>`).join('') || '<div class="empty">No systems yet.</div>'}</div></div>`;
  return sectionCard('team2-system', labelInput('team2','team2.systemTitle','2.5 Name System - Graph'), 'Horizontal full-name graph to avoid cut labels.', `${addButton('Add system','addSystemResult()')}<button class="btn small" onclick="openAnyChartModal('team2System')">Bigger</button>${refreshButton('team2System')}`, body);
}
function addSystemResult() { team('team2').systemRows.push({id:uid(), systemName:'', count:0}); saveState(); renderCurrentViewPreservingScroll(); }
function updateSystemResult(id, field, value, numeric=false) { const r = team('team2').systemRows.find(x => x.id === id); if (!r) return; r[field] = numeric ? number(value) : value; saveState(); }
function deleteSystemResult(id) { team('team2').systemRows = team('team2').systemRows.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderTeam3() {
  const el = document.getElementById('team3'); if (!el) return;
  el.innerHTML = `${teamPageTitle('team3', reportButtons('team3'))}${renderTeam3DailyInputs()}${renderEditableSummary('team3')}${renderTeam3Operations()}${renderFlexTable('team3','team3Log','team3.logTitle','3.3 Log Table','')}${renderTeam3Maintenance()}${renderAvailability('team3')}`;
}
function renderTeam3DailyInputs() {
  const rows = team('team3').dailyInputs;
  const body = `<div class="routine-list">${rows.map(r => `<div class="entry routine-entry"><span class="routine-dot"></span><textarea class="auto-grow routine-line-input" oninput="updateDailyInput('${r.id}',this.value);autoGrow(this)" placeholder="Write routine daily input here">${esc(r.text)}</textarea><span class="routine-time">${esc(r.updatedAt ? 'Updated: ' + r.updatedAt : 'Created: ' + r.createdAt)}</span><div class="routine-actions"><button class="btn small danger" onclick="deleteDailyInput('${r.id}')"></button></div></div>`).join('') || '<div class="empty">No daily inputs yet.</div>'}</div>`;
  return sectionCard('team3-daily-inputs', labelInput('team3','team3.dailyInputsTitle','3.1 Daily Inputs'), 'Routine inputs for Team 3. This is not a concern section.', addButton('Add input','addDailyInput()'), body, 'team3-routine-card');
}
function addDailyInput() { team('team3').dailyInputs.push({id:uid(), text:'', createdAt:nowStamp(), updatedAt:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateDailyInput(id, value) { const item = team('team3').dailyInputs.find(x => x.id === id); if (!item) return; item.text = value; item.updatedAt = nowStamp(); saveState(); }
function deleteDailyInput(id) { team('team3').dailyInputs = team('team3').dailyInputs.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }
function renderTeam3Operations() {
  const body = `<div class="status-grid">${renderStatusGroup('group1','team3.ops1','Name')}${renderStatusGroup('group2','team3.ops2','Name 2')}</div>`;
  return sectionCard('team3-operations', labelInput('team3','team3.operationsTitle','3.2 Operations Status'), 'Green / yellow / red visual statuses.', '', body);
}
function renderStatusGroup(groupKey, labelKey, fallback) {
  const rows = team('team3').operations[groupKey] || [];
  return `<div class="card"><div class="card-head wrap"><h3>${labelInput('team3',labelKey,fallback)}</h3>${addButton('Add status', `addStatus('${groupKey}')`)}</div>${rows.map(r => { const cur = normalizeStatus(r.status); return `<div class="status-row premium-status-row"><input class="input" value="${esc(r.name||'')}" oninput="updateStatus('${groupKey}','${r.id}','name',this.value)"><div class="status-picker"><button type="button" class="status-dot-option green ${cur==='Green'?'active':''}" onclick="setStatus('${groupKey}','${r.id}','Green')" title="Green"></button><button type="button" class="status-dot-option yellow ${cur==='Yellow'?'active':''}" onclick="setStatus('${groupKey}','${r.id}','Yellow')" title="Yellow"></button><button type="button" class="status-dot-option red ${cur==='Red'?'active':''}" onclick="setStatus('${groupKey}','${r.id}','Red')" title="Red"></button></div><button type="button" class="status-pulse ${cur.toLowerCase()}" onclick="cycleStatus('${groupKey}','${r.id}')" title="Cycle"></button><button class="btn small danger" onclick="deleteStatus('${groupKey}','${r.id}')"></button></div>`; }).join('') || '<div class="empty">No status items yet.</div>'}</div>`;
}
function normalizeStatus(value) { const v = String(value||'').toLowerCase(); if (v.includes('red') || v.includes('down')) return 'Red'; if (v.includes('yellow') || v.includes('partial')) return 'Yellow'; return 'Green'; }
function addStatus(groupKey) { team('team3').operations[groupKey].push({id:uid(), name:'', status:'Green'}); saveState(); renderCurrentViewPreservingScroll(); }
function updateStatus(groupKey, id, field, value) { const item = team('team3').operations[groupKey].find(x => x.id === id); if (!item) return; item[field]=value; saveState(); }
function setStatus(groupKey, id, value) { const item = team('team3').operations[groupKey].find(x => x.id === id); if (!item) return; item.status=normalizeStatus(value); saveState(); renderCurrentViewPreservingScroll(); }
function cycleStatus(groupKey, id) { const order=['Green','Yellow','Red']; const item = team('team3').operations[groupKey].find(x => x.id === id); if (!item) return; setStatus(groupKey,id,order[(order.indexOf(normalizeStatus(item.status))+1)%3]); }
function deleteStatus(groupKey, id) { team('team3').operations[groupKey] = team('team3').operations[groupKey].filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }
function renderTeam3Maintenance() {
  const rows = team('team3').maintenanceEntries;
  const body = rows.map(r => `<div class="entry"><div class="entry-meta">Created: ${esc(r.createdAt)}${r.updatedAt ? ' / Updated: ' + esc(r.updatedAt) : ''}</div><textarea class="auto-grow" oninput="updateMaintenance('${r.id}',this.value);autoGrow(this)">${esc(r.text)}</textarea><button style="margin-top:8px" class="btn small danger" onclick="deleteMaintenance('${r.id}')"></button></div>`).join('') || '<div class="empty">No maintenance entries.</div>';
  return sectionCard('team3-maintenance', labelInput('team3','team3.maintenanceTitle','3.4 Maintenance'), 'Free text maintenance records.', addButton('Add maintenance','addMaintenance()'), body);
}
function addMaintenance() { team('team3').maintenanceEntries.push({id:uid(), text:'', createdAt:nowStamp(), updatedAt:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateMaintenance(id, value) { const m = team('team3').maintenanceEntries.find(x => x.id === id); if (!m) return; m.text = value; m.updatedAt = nowStamp(); saveState(); }
function deleteMaintenance(id) { team('team3').maintenanceEntries = team('team3').maintenanceEntries.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderAvailability(teamKey) {
  const rows = team(teamKey).availability;
  const body = `<div class="table-wrap comfort-table-wrap"><table class="comfort-table"><thead><tr><th>${thLabel(teamKey,'availability.name','Name')}</th><th>${thLabel(teamKey,'availability.status','Status / Absence')}</th><th>${thLabel(teamKey,'availability.from','From')}</th><th>${thLabel(teamKey,'availability.to','To')}</th><th>${thLabel(teamKey,'availability.notes','Notes')}</th><th class="action-col"><span class="sr-only">Delete</span></th></tr></thead><tbody>${rows.map(r => `<tr><td><input class="cell-input" value="${esc(r.name)}" oninput="updateAvailability('${teamKey}','${r.id}','name',this.value)"></td><td><input class="cell-input" value="${esc(r.status)}" oninput="updateAvailability('${teamKey}','${r.id}','status',this.value)"></td><td><input class="cell-input" type="date" value="${esc(r.from)}" oninput="updateAvailability('${teamKey}','${r.id}','from',this.value)"></td><td><input class="cell-input" type="date" value="${esc(r.to)}" oninput="updateAvailability('${teamKey}','${r.id}','to',this.value)"></td><td><input class="cell-input" value="${esc(r.notes)}" oninput="updateAvailability('${teamKey}','${r.id}','notes',this.value)"></td><td class="action-col"><button class="btn small danger" onclick="deleteAvailability('${teamKey}','${r.id}')"></button></td></tr>`).join('') || '<tr><td colspan="6"><div class="empty">No availability records.</div></td></tr>'}</tbody></table></div>`;
  return sectionCard(`${teamKey}-availability`, labelInput(teamKey,'section.availability','People Availability / Absence'), 'Manual typing. Overview shows absence/unavailable records.', addButton('Add person', `addAvailability('${teamKey}')`), body, 'wide-table-card');
}
function addAvailability(teamKey) { team(teamKey).availability.push({id:uid(), name:'', status:'Available', from:todayISO(), to:todayISO(), notes:''}); saveState(); renderCurrentViewPreservingScroll(); }
function updateAvailability(teamKey,id,field,value) { const r = team(teamKey).availability.find(x => x.id === id); if (!r) return; r[field]=value; saveState(); }
function deleteAvailability(teamKey,id) { team(teamKey).availability = team(teamKey).availability.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }
function renderTnaSection(teamKey) { return renderFlexTable(teamKey,'tna',`${teamKey}.tnaTitle`,'TNA Table','Compact TNA table. Overview shows filled entries only.'); }
function renderPersonnelSection(teamKey) {
  const rows = team(teamKey).personnelRows;
  const body = `<div class="person-create-form"><input class="input" id="${teamKey}-person-id" placeholder="ID"><input class="input" id="${teamKey}-person-name" placeholder="Full name"><input class="input" id="${teamKey}-person-role" placeholder="Role"><button class="btn small primary" onclick="createPersonnel('${teamKey}')">Create Card</button></div><div class="person-grid">${rows.map(r => `<div class="person-card compact-person-card"><div class="person-card-top"><div class="person-avatar">${esc(initials(r.name))}</div><div class="person-identity"><strong>${esc(r.name||'New Employee')}</strong><span>${esc(r.role||'Role')}</span><small>ID: ${esc(r.idValue||'ID')}</small></div></div><button class="btn small danger" onclick="deletePersonnel('${teamKey}','${r.id}')"></button></div>`).join('') || '<div class="empty">No personnel cards yet.</div>'}</div>`;
  return sectionCard(`${teamKey}-personnel`, labelInput(teamKey,`${teamKey}.personnelTitle`,'Personnel / Team Members'), 'Compact cards.', '', body, 'personnel-section');
}
function initials(name) { const parts = String(name||'').trim().split(/\s+/).filter(Boolean); return ((parts[0]?.[0]||'?') + (parts[1]?.[0]||'')).toUpperCase(); }
function createPersonnel(teamKey) { const idEl=document.getElementById(`${teamKey}-person-id`), nameEl=document.getElementById(`${teamKey}-person-name`), roleEl=document.getElementById(`${teamKey}-person-role`); const row={id:uid(), idValue:safeText(idEl?.value), name:safeText(nameEl?.value), role:safeText(roleEl?.value)}; if (!row.idValue && !row.name && !row.role) { alert('Add at least one value.'); return; } team(teamKey).personnelRows.push(row); saveState(); renderCurrentViewPreservingScroll(); }
function deletePersonnel(teamKey,id) { team(teamKey).personnelRows = team(teamKey).personnelRows.filter(x => x.id !== id); saveState(); renderCurrentViewPreservingScroll(); }

function renderOverview() {
  const totals = calculateOverviewTotals();
  const el = document.getElementById('overview'); if (!el) return;
  el.innerHTML = `${pageTitle('Overview', `Selected week: ${currentWeekLabel()}`, reportButtons('overview'))}<div class="grid two section"><div class="card"><div class="card-head"><h3>Team Comparison</h3>${refreshButton('overview')}</div><div class="chart-box wide-name-chart-box">${renderWideNameChart(totals.teamRows.map(r => ({label:r.name, value:r.taskCount})))}</div></div><div class="card"><div class="card-head"><h3>Team Summaries</h3></div>${['team1','team2','team3'].map(k => `<div class="entry"><div class="card-head"><h3>${esc(teamDisplayName(k))}</h3><button class="btn small" onclick="showView('${k}')">Open</button></div><p class="subtle">${esc(team(k).weeklySummary || '')}</p></div>`).join('')}</div></div><div class="grid two section"><div class="card"><div class="card-head"><h3>Team 1 Jira Analytics Preview</h3>${refreshButton('overviewJira')}</div><div class="chart-box">${renderJiraChart()}</div></div><div class="card"><div class="card-head"><h3>Team 2 Statistics Preview</h3>${refreshButton('overviewStats')}</div><div class="chart-box">${renderTeam2StatsChart()}</div></div></div><div class="grid two section"><div class="card"><div class="card-head"><h3>Team 3 Operations Status</h3></div>${renderOverviewTeam3Status()}</div><div class="card"><div class="card-head"><h3>System Health / Recovery</h3></div>${renderOverviewSystemHealth()}</div></div><div class="grid section"><div class="card"><div class="card-head"><h3>Absence People</h3></div>${renderOverviewAbsence()}</div></div>`;
}
function calculateOverviewTotals() { const rows = ['team1','team2','team3'].map(k => ({name:teamDisplayName(k), taskCount:taskCount(k)})); return { teamRows:rows }; }
function taskCount(k) { const t=team(k); if (k==='team1') return (t.tasksReceived.length+t.ongoingTasks.length+t.urgentTasks.length+t.jiraRecords.length); if (k==='team2') return getTableRows('team2','team2Requested').length+getTableRows('team2','team2Internal').length+t.statsRows.length+t.resultRows.length+t.systemRows.length; return t.dailyInputs.length+getTableRows('team3','team3Log').length+t.maintenanceEntries.length; }
function renderOverviewTeam3Status() { const ops=[...(team('team3').operations.group1||[]),...(team('team3').operations.group2||[])]; if (!ops.length) return '<div class="empty">No Team 3 status records.</div>'; return ops.map(o => `<div class="entry"><div class="card-head"><strong>${esc(o.name||'Status item')}</strong><span class="status-pulse ${normalizeStatus(o.status).toLowerCase()}" title="${esc(normalizeStatus(o.status))}"></span></div></div>`).join(''); }
function renderOverviewSystemHealth() { const t=team('team1'); const active=t.systemsActivity.reduce((a,b)=>a+number(b.active),0); const inactive=t.systemsActivity.reduce((a,b)=>a+number(b.inactive),0); const recovered=t.recoveredSystems.reduce((a,b)=>a+number(b.recoveredCount),0); return `<div class="grid three"><div class="mini-metric"><strong>${active}</strong><span>Machines Active</span></div><div class="mini-metric"><strong>${inactive}</strong><span>Machines Inactive</span></div><div class="mini-metric"><strong>${recovered}</strong><span>Recovered Systems</span></div></div>`; }
function renderOverviewTna() { const items=[]; ['team1','team2','team3'].forEach(k => team(k).tnaRows.forEach(row => { const text = (state.global.tables.tna || []).map(c => row.values?.[c.id]).filter(v => safeText(v)).join(' | '); if (text) items.push(text); })); if (!items.length) return '<div class="empty">No TNA updates entered.</div>'; return items.slice(0,20).map(x => `<div class="entry"><p class="subtle">${esc(x)}</p></div>`).join(''); }
function renderOverviewAbsence() { const items=[]; ['team1','team2','team3'].forEach(k => team(k).availability.forEach(a => { const status = String(a.status||'').toLowerCase(); const notes = String(a.notes||'').toLowerCase(); if (status && !status.includes('available') || /vacation|leave|off|sick|absence|unavailable/.test(status + ' ' + notes)) items.push(a); })); if (!items.length) return '<div class="empty">No absence records.</div>'; return items.map(a => `<div class="entry"><strong>${esc(a.name || 'Person')}</strong><p class="subtle">${esc(a.status || '')} | ${esc(a.from || '')} - ${esc(a.to || '')}${a.notes ? ' | ' + esc(a.notes) : ''}</p></div>`).join(''); }

function renderTasksChart() { const data=aggregateTasksByDate(); if (!data.length || data.every(d=>!d.total&&!d.recovered)) return '<div class="empty">No task values in selected range.</div>'; return renderSvgChart(data, [{key:'total',label:'Received',color:'#60a5fa'},{key:'recovered',label:'Recovered',color:'#22c55e'}]); }
function renderJiraChart() { const data=aggregateJiraByDate(); if (!data.length || data.every(d=>!d.total&&!d.recovered)) return '<div class="empty">No Jira values in selected range.</div>'; return renderSvgChart(data, [{key:'total',label:'Total',color:'#f59e0b'},{key:'recovered',label:'Recovered',color:'#38bdf8'}]); }
function dateRangeArray(from,to) { const out=[]; let s=parseISODate(from), e=parseISODate(to); if (isNaN(s)||isNaN(e)||s>e) return out; while(s<=e) { out.push(formatISODate(s)); s.setDate(s.getDate()+1); } return out; }
function aggregateTasksByDate() { const t=team('team1'); return dateRangeArray(t.jiraFrom,t.jiraTo).map(date => { let total=0,recovered=0; t.tasksReceived.forEach(r => { if (r.date===date) { total+=number(r.totalReceived); recovered+=number(r.totalRecovered); } }); return {date,total,recovered}; }); }
function aggregateJiraByDate() { const t=team('team1'); return dateRangeArray(t.jiraFrom,t.jiraTo).map(date => { let total=0,recovered=0; t.jiraRecords.forEach(r => { if (r.from && r.to && date>=r.from && date<=r.to) { total+=number(r.totalTasks); recovered+=number(r.recoveredTasks); } }); return {date,total,recovered}; }); }
function renderSvgChart(data, series) { const w=920,h=310,left=60,right=30,top=28,bottom=58,plotW=w-left-right,plotH=h-top-bottom; const maxY=Math.max(1,...data.flatMap(d=>series.map(s=>number(d[s.key])))); const gap=data.length>1 ? plotW/(data.length-1) : plotW; const x=i=>left+(data.length===1?plotW/2:i*gap); const y=v=>top+plotH-(number(v)/maxY)*plotH; const grid=[0,.25,.5,.75,1].map(t=>`<line x1="${left}" y1="${top+plotH-t*plotH}" x2="${w-right}" y2="${top+plotH-t*plotH}" stroke="rgba(255,255,255,.08)"/><text x="12" y="${top+plotH-t*plotH+4}" fill="#9aa8c4" font-size="11">${Math.round(maxY*t)}</text>`).join(''); const labels=data.map((d,i)=> (i%Math.ceil(data.length/7)===0 || i===data.length-1) ? `<text x="${x(i)}" y="${h-20}" text-anchor="middle" fill="#9aa8c4" font-size="10">${esc(String(d.date).slice(5))}</text>` : '').join(''); const bars = data.length <= 10; let body=''; if (bars) { const bw=Math.max(10,Math.min(32,plotW/Math.max(data.length,1)/(series.length+1))); body=data.map((d,i)=>series.map((s,si)=>{ const off=(si-(series.length-1)/2)*(bw+4); return `<rect x="${x(i)+off}" y="${y(d[s.key])}" width="${bw}" height="${top+plotH-y(d[s.key])}" rx="5" fill="${s.color}" opacity=".86"/>`; }).join('')).join(''); } else { body=series.map(s=>{ const path=data.map((d,i)=>`${i?'L':'M'} ${x(i).toFixed(1)} ${y(d[s.key]).toFixed(1)}`).join(' '); return `<path d="${path}" fill="none" stroke="${s.color}" stroke-width="3"/>`; }).join(''); } const legend=series.map((s,i)=>`<text x="${left+i*140}" y="15" fill="${s.color}" font-size="12">${esc(s.label)}</text>`).join(''); return `<svg viewBox="0 0 ${w} ${h}" role="img">${legend}${grid}<line x1="${left}" y1="${top+plotH}" x2="${w-right}" y2="${top+plotH}" stroke="rgba(255,255,255,.2)"/>${body}${labels}</svg>`; }
function renderTeam2StatsChart() { const rows=team('team2').statsRows; const data=rows.map(r=>({date:r.period,total:number(r.input1Received),recovered:number(r.input1Analyzed),i2r:number(r.input2Received),i2a:number(r.input2Analyzed)})); if (!data.length || data.every(d=>!d.total&&!d.recovered&&!d.i2r&&!d.i2a)) return '<div class="empty">No statistics data yet.</div>'; return renderSvgChart(data, [{key:'total',label:'Input 1 Received',color:'#60a5fa'},{key:'recovered',label:'Input 1 Analyzed',color:'#22c55e'},{key:'i2r',label:'Input 2 Received',color:'#f59e0b'},{key:'i2a',label:'Input 2 Analyzed',color:'#a78bfa'}]); }
function renderWideNameChart(rows) { const clean=rows.filter(r=>safeText(r.label) || number(r.value)); if (!clean.length) return '<div class="empty">No chart data yet.</div>'; const max=Math.max(1,...clean.map(r=>number(r.value))); return `<div class="wide-name-chart"><div class="wide-name-chart-head"><span>Name</span><span>Value</span><span>Total</span></div>${clean.map(r=>{ const pct=Math.max(2, Math.round((number(r.value)/max)*100)); return `<div class="wide-name-row"><div class="wide-name-label">${esc(r.label || 'Unnamed')}</div><div class="wide-name-track"><div class="wide-name-fill" style="width:${pct}%"></div></div><div class="wide-name-value">${number(r.value)}</div></div>`; }).join('')}</div>`; }
function openChartModal(kind) { const modal=document.getElementById('chartModal'); if (!modal) return; const title=kind==='jira'?getLabel('team1','chart.jiraTitle','Jira Total / Recovered'):getLabel('team1','chart.tasksTitle','Tasks Received / Recovered'); const chart=kind==='jira'?renderJiraChart():renderTasksChart(); modal.innerHTML=`<div class="chart-modal-panel"><div class="card-head wrap"><h3>${esc(title)}</h3><button class="btn small" onclick="closeChartModal()">Close</button></div><div class="chart-box large">${chart}</div></div>`; document.body.classList.add('modal-open'); }
function openAnyChartModal(kind) { let title='Chart', chart=''; if (kind==='team2Stats') { title=getLabel('team2','team2.statsTitle','2.3 Statistics - Graph'); chart=renderTeam2StatsChart(); } if (kind==='team2Results') { title=getLabel('team2','team2.resultsTitle','2.4 Name Results - Chart'); chart=renderWideNameChart(team('team2').resultRows.map(r=>({label:r.moduleName,value:number(r.resultValue)}))); } if (kind==='team2System') { title=getLabel('team2','team2.systemTitle','2.5 Name System - Graph'); chart=renderWideNameChart(team('team2').systemRows.map(r=>({label:r.systemName,value:number(r.count)}))); } const modal=document.getElementById('chartModal'); modal.innerHTML=`<div class="chart-modal-panel"><div class="card-head wrap"><h3>${esc(title)}</h3><button class="btn small" onclick="closeChartModal()">Close</button></div><div class="chart-box large wide-name-chart-box">${chart}</div></div>`; document.body.classList.add('modal-open'); }
function closeChartModal() { const modal=document.getElementById('chartModal'); if (modal) modal.innerHTML=''; document.body.classList.remove('modal-open'); }
function refreshGraphs() { saveState(); renderCurrentViewPreservingScroll(); }

function updateArrayItem(teamKey, arrayName, id, field, value, type) { const item=(team(teamKey)[arrayName]||[]).find(x=>x.id===id); if (!item) return; item[field]=type==='number'?number(value):value; saveState(); }
function deleteArrayItem(teamKey, arrayName, id) { team(teamKey)[arrayName] = (team(teamKey)[arrayName]||[]).filter(x=>x.id!==id); saveState(); renderCurrentViewPreservingScroll(); }

function exportJSON() { saveState(); const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'}); downloadBlob(blob, `weekly-dashboard-${exportDateStamp()}.json`); }
function importJSON(event) { const file=event.target.files && event.target.files[0]; if (!file) return; const reader=new FileReader(); reader.onload=()=>{ try { state=migrateState(JSON.parse(reader.result)); saveState(); render(); alert('Dashboard data imported successfully.'); } catch(err) { console.warn(err); alert('Import failed. Please choose a valid dashboard JSON file.'); } }; reader.readAsText(file); event.target.value=''; }
function printDashboard() {
  let header = document.getElementById('printReportHeader');
  if (!header) {
    header = document.createElement('div');
    header.id = 'printReportHeader';
    header.className = 'print-report-header';
    document.body.insertBefore(header, document.body.firstChild);
  }
  const title = currentView === 'overview' ? 'Weekly Dashboard Overview' : (currentView.indexOf('team') === 0 ? `${teamDisplayName(currentView)} Weekly Report` : 'Weekly Operations Dashboard');
  header.innerHTML = `<h1>${esc(title)}</h1><div>${esc(currentWeekLabel())}</div><div>Exported ${esc(exportDateStamp())}</div>`;
  const cleanup = () => { const el=document.getElementById('printReportHeader'); if (el) el.remove(); window.removeEventListener('afterprint', cleanup); };
  window.addEventListener('afterprint', cleanup);
  window.print();
  setTimeout(cleanup, 1500);
}
function reportClone(target) {
  const source = document.getElementById(target);
  if (!source) return null;
  const clone = source.cloneNode(true);
  clone.classList.add('report-clone');
  clone.querySelectorAll('.report-actions,.actions,.section-tools,.mini-toolbar,button,.trash-btn').forEach(el => el.remove());
  clone.querySelectorAll('.collapsed').forEach(el => el.classList.remove('collapsed'));
  clone.querySelectorAll('input,textarea,select').forEach(el => {
    let value = '';
    if (el.tagName === 'SELECT') value = el.options && el.selectedIndex >= 0 ? el.options[el.selectedIndex].text : el.value;
    else value = el.value || '';
    const span = document.createElement('div');
    span.className = 'report-value';
    span.textContent = value;
    el.replaceWith(span);
  });
  clone.querySelectorAll('.empty').forEach(el => {
    const card = el.closest('.card');
    if (card && card.querySelectorAll('table tbody tr, .entry, .status-row, .wide-name-row').length === 0) card.remove();
  });
  clone.querySelectorAll('[style*="display: none"],[hidden]').forEach(el => el.remove());
  return clone;
}
function exportWord(target) {
  const title = target === 'overview' ? 'Weekly Dashboard Overview' : `${teamDisplayName(target)} Weekly Report`;
  const body = buildReportHtml(target);
  const css = `
    @page{margin:16mm} body{font-family:Arial,sans-serif;color:#111827;font-size:10.5pt;line-height:1.35;margin:0}
    h1{font-size:20pt;margin:0 0 4pt;color:#0f172a} h2{font-size:15pt;color:#0f172a} h3{font-size:12pt;color:#0f172a;margin:8pt 0 5pt}
    .report-meta{color:#4b5563;margin:0 0 14pt}.card,.hero,.entry{border:1px solid #d1d5db;padding:9pt;margin:8pt 0;page-break-inside:avoid}
    .grid,.team-grid,.two,.three,.four{display:block!important}.page-title{display:block!important}.page-title .pill-row{display:none!important}
    table{width:100%;border-collapse:collapse;margin:6pt 0 10pt;page-break-inside:auto} thead{display:table-header-group} tr{page-break-inside:avoid;page-break-after:auto}
    th,td{border:1px solid #cbd5e1;padding:5pt;text-align:left;vertical-align:top;white-space:normal;word-break:break-word} th{background:#f1f5f9;font-weight:bold}
    .report-value{min-height:14pt;white-space:pre-wrap;word-break:break-word}.subtle,.entry-meta{color:#4b5563}.chart-box{page-break-inside:avoid;margin:8pt 0}.chart-box svg{width:100%;height:auto;max-height:360pt}
    .wide-name-row{display:table;width:100%;border-bottom:1px solid #e5e7eb;padding:4pt 0}.wide-name-label,.wide-name-value{display:table-cell}.wide-name-value{text-align:right}.wide-name-track{display:none}
    .btn,.actions,.nav,.topbar,.footer,.week-switcher,.section-tools,.mini-toolbar,.report-actions{display:none!important}
  `;
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${css}</style></head><body><h1>${esc(title)}</h1><div class="report-meta"><strong>Week:</strong> ${esc(currentWeekLabel())}<br><strong>Exported:</strong> ${esc(exportDateStamp())}</div>${body}</body></html>`;
  const blob = new Blob(['\ufeff', html], {type:'application/msword'});
  downloadBlob(blob, `${cleanFilename(title)}-${exportDateStamp()}.doc`);
}
function downloadBlob(blob, filename) {
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download=filename; a.style.display='none';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 1500);
}
function buildReportHtml(target) {
  const clone = reportClone(target);
  if (!clone) return '<p>No report data available.</p>';
  const pageTitle = clone.querySelector('.page-title');
  if (pageTitle) pageTitle.remove();
  return clone.innerHTML;
}

state = loadState();

// Expose functions for index.html inline handlers.
Object.assign(window, { showView, changeWeek, goToThisWeek, selectWeekByDate, toggleTheme, exportJSON, importJSON, printDashboard, exportWord, updateTeamName, updateLabel, toggleCollapse, autoGrow, updateTeamField, addDailyTask, updateDailyTask, deleteDailyTask, addConcern, updateConcern, deleteArrayItem, addSystemActivity, updateTeam1Array, addTaskReceived, updateTaskReceived, addSmallListItem, updateArrayItem, addSystemOutcome, addJiraRecord, updateJira, t1Set, addTeamDailyEntry, updateTeamDailyEntry, deleteTeamDailyEntry, addFlexRow, deleteFlexRow, updateFlexCell, addFlexColumn, updateFlexColumn, deleteFlexColumn, addStatsRow, updateStats, deleteStats, addResult, updateResult, deleteResult, addSystemResult, updateSystemResult, deleteSystemResult, addDailyInput, updateDailyInput, deleteDailyInput, addStatus, updateStatus, setStatus, cycleStatus, deleteStatus, addMaintenance, updateMaintenance, deleteMaintenance, addAvailability, updateAvailability, deleteAvailability, createPersonnel, deletePersonnel, openChartModal, openAnyChartModal, closeChartModal, refreshGraphs, team });

document.addEventListener('DOMContentLoaded', () => { render(); });
